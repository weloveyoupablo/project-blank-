# PNGEA build roadmap

## Product standard
Launch-ready, centralized network. No fabricated network, market, or news activity in live mode. Fixed shell + fluid center.

## Completed foundation
- Fixed PNGEA shell and protected core UI
- Search / Ask / Go intent field
- Universal object/action substrate
- Tasks, Memory, NOW, Spaces prototypes
- Model-provider-independent intelligence layer
- Centralized Fastify API
- PostgreSQL canonical social/content data
- Authentication and rotating sessions
- Social graph, posts, replies, quotes, reactions and reposts
- Privacy-aware live feed
- Conversations, DMs and read state
- Notifications
- PostgreSQL search
- Consent records and settings
- Remember records and persistent tasks
- Moderation reports + audit log
- Redis realtime event bus
- WebSocket gateway with one-use auth tickets
- S3-compatible media upload contract
- Media processing queue/worker
- Browser live-mode adapter
- Live feed / Messages / Notifications / Search / Profile / NOW wiring
- Automatic fixture suppression after live authentication
- **Real-time market/news ingest foundation**
- **Canonical market quote + external news stores**
- **Ticker relevance/freshness/diversity ranker**
- **Per-user ticker symbols/topics/category preferences**
- **Live ticker refresh events**
- **Delayed/stale/source provenance rules**
- **Provider-neutral trusted general-news ingest endpoint**

## Next engineering block
1. **Account hardening**
   - email verification
   - password reset/account recovery
   - passkeys + 2FA
   - session/device management
2. **Media production pipeline**
   - image variants
   - video/audio transcoding
   - thumbnails
   - malware/content scanning
   - CDN
3. **Feed engine v1**
   - Following candidate source
   - recommended candidate source
   - ranking + dedupe + diversity
   - pagination/cache strategy
4. **Ticker/news production hardening**
   - final consolidated US market-data license/feed
   - licensed general-news provider adapters
   - corrections/retractions and source trust registry
   - provider outage/freshness monitoring
   - exchange calendar/corporate-action handling
   - explicit watchlist/topic UI
5. **Search v1 production**
   - recency/social/location ranking
   - autocomplete
   - trends derived only from real activity
6. **Moderation + anti-abuse**
   - block/mute/restrict everywhere
   - moderator queue and appeals
   - spam/bot/rate abuse defenses
   - media safety pipeline
7. **Operations**
   - metrics, logs, traces, alerts
   - backups + restore drills
   - feature flags
   - staging/prod separation
   - load tests

## PNGEA-native systems after the core network is hardened
- Actions engine
- Intent/agent execution service
- server-backed Tasks
- Smart Memory retrieval
- NOW relevance service
- Spaces/mini-app runtime
- Commerce + Wallet
- Dating isolation zone
- adaptive center ranking

## Intelligence layer principle
PNGEA owns orchestration, memory, tools, permissions and routing. Model providers are replaceable. Self-hosted/open-weight models remain a first-class path.

### v0.38 completed
- Embedded continuous worker supervisor
- Media queue worker auto-start + restart
- Market/news stream worker auto-start + restart
- Worker health exposed through `/health`
- Permanent fix for settings permission schema runtime error


## v0.40 complete
Account/session foundation: persistent multi-account sessions, email/phone/username login, verification-provider hooks, live-only social data, and calmer ticker motion.
