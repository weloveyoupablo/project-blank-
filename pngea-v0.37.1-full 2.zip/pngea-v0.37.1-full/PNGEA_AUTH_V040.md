# PNGEA v0.40 — Accounts & Authentication

- Full-black authentication surface; no application content is visible behind sign-in.
- Sign in with email, phone number, username, or @username.
- Sign up with email and/or phone plus username/display name/password.
- Device account switcher in the sidebar via the person-plus icon.
- Add, switch, remove, and log out accounts without losing other saved accounts.
- Account-scoped HttpOnly refresh cookies support multiple signed-in accounts on one device.
- Refresh sessions use a 10-year sliding lifetime by default; normal inactivity does not log a user out.
- Email/phone verification challenge storage and delivery adapters are ready for Resend/Twilio.
- Live sidebar/profile counts come from the database; seeded counts and social activity were removed.
- Ticker crawl slowed from 36s to 108s.
