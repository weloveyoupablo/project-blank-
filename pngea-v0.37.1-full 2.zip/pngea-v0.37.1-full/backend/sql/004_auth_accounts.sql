begin;

alter table users add column if not exists phone_e164 text;
alter table users add column if not exists email_verified_at timestamptz;
alter table users add column if not exists phone_verified_at timestamptz;
alter table users add column if not exists password_changed_at timestamptz not null default now();
alter table users alter column email drop not null;

create unique index if not exists users_phone_e164_unique on users(phone_e164) where phone_e164 is not null;
create unique index if not exists users_email_lower_unique on users(lower(email)) where email is not null;

-- A PNGEA identity must remain reachable through at least one recovery/auth channel.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname='users_email_or_phone_required'
  ) then
    alter table users add constraint users_email_or_phone_required check(email is not null or phone_e164 is not null);
  end if;
end $$;

create table if not exists auth_verification_codes(
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  purpose text not null check(purpose in('verify_contact','password_reset')),
  channel text not null check(channel in('email','sms')),
  destination text not null,
  code_hash text not null,
  attempts int not null default 0,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists auth_verification_user_idx on auth_verification_codes(user_id,created_at desc);
create index if not exists auth_verification_expiry_idx on auth_verification_codes(expires_at) where consumed_at is null;

commit;
