# PNGEA backend v0.36

Centralized modular backend for PNGEA. v0.36 adds the first production-shaped **market + news intelligence path for the Home ticker**.

## Local stack

- PostgreSQL — canonical social/content + market/news state
- Redis — realtime fanout and ephemeral tickets
- MinIO — local S3-compatible media storage
- Fastify — HTTP/WebSocket API
- media worker — upload verification/processing
- market-news worker — live market/news ingest + ticker refresh events

## Start

```bash
cp .env.example .env
docker compose up -d
npm install
npm run migrate
npm run dev
```

Workers:

```bash
npm run worker:media
npm run worker:market-news
```

API: `http://localhost:8787`
Health: `GET /health`

## Ticker architecture

The client never invents live market/news data. `GET /v1/ticker` ranks real candidates from:

1. unread personal notifications
2. live PNGEA/NOW events
3. current market snapshots for the user's ticker symbols
4. fresh external news

The ranker uses freshness, magnitude/importance, user symbol/topic relevance, verification state, and category diversity. It caps same-category runs so the ticker does not become a wall of finance or headlines.

User controls live at:

- `GET /v1/ticker/preferences`
- `PATCH /v1/ticker/preferences`

Preferences include categories, followed symbols, topics, and item count.

## Market data

The included adapter uses Alpaca Market Data:

- streaming trades over WebSocket for configured symbols
- snapshot refresh for previous-close comparisons and recovery
- feed metadata stored with each quote
- `iex`, `sip`, and `delayed_sip` are supported by configuration

`iex` is real-time IEX-only coverage. `sip` is the consolidated US exchange feed when the account/plan permits it. `delayed_sip` is explicitly labeled as delayed in the PNGEA ticker.

No provider credentials = no fabricated market items.

## News

The included worker ingests Alpaca's real-time market-news stream. Articles are stored with source, timestamp, URL, symbols, inferred topics, importance, and verification state.

For broad/world/politics/entertainment news, PNGEA now has a provider-neutral trusted ingest contract:

`POST /v1/internal/news`

with header:

`x-pngea-ingest-key: <PNGEA_INGEST_SECRET>`

This is intended for licensed/newsroom/provider adapters. PNGEA should not scrape arbitrary pages into the ticker. If two distinct configured sources map to the same story key, the article can be marked corroborated; official-source adapters can mark an item official.

## Accuracy rules

- every market item stores source/feed/as-of metadata
- delayed market feeds are labeled
- old quotes are labeled as last-known rather than presented as live
- news preserves original source attribution and URL
- important/breaking ranking is separate from truth verification
- single-source, corroborated, and official are distinct states
- source trust weight is separate from story importance
- corrections/retractions can update or remove a story from ticker eligibility
- if feeds are unavailable, the ticker omits those categories instead of inserting demo values

## Realtime

The market-news worker emits `ticker.updated` through PNGEA's Redis event bus. Connected clients re-fetch ranked ticker items without page refresh.

## Production work still required before public launch

- choose/contract the final consolidated market-data plan
- connect licensed general-news providers to `/v1/internal/news`
- source-specific trust policy and corrections/retractions pipeline
- exchange holiday/calendar service and corporate-action handling
- broader asset classes if wanted (crypto/options/international)
- persistent user topic learning from explicit behavior under personalization permissions
- monitoring/SLOs for provider freshness and feed outages

## v0.40 authentication

Login identifier: email, E.164/US phone number, or handle/`@handle`.

Multi-account browser sessions use account-scoped HttpOnly refresh cookies. The client stores only account metadata + short-lived access tokens; refresh credentials remain HttpOnly.

Contact verification endpoints:
- `POST /v1/auth/verification/request` `{ "channel": "email" | "sms" }`
- `POST /v1/auth/verification/confirm` `{ "channel": "email" | "sms", "code": "123456" }`

Email delivery expects `RESEND_API_KEY` + `AUTH_EMAIL_FROM`. SMS expects `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM_NUMBER`.
