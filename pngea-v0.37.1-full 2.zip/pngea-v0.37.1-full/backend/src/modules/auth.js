import argon2 from 'argon2';
import crypto from 'node:crypto';
import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { ApiError } from '../lib/errors.js';
import { opaqueId, randomToken, sha256 } from '../lib/security.js';
import { audit } from '../lib/audit.js';
import { config } from '../config.js';

const emailSchema=z.string().email().max(320);
const phoneSchema=z.string().trim().min(7).max(32);
const signupSchema = z.object({
  email: emailSchema.optional(),
  phone: phoneSchema.optional(),
  password: z.string().min(10).max(256),
  handle: z.string().regex(/^[A-Za-z0-9_]{3,30}$/),
  displayName: z.string().trim().min(1).max(80)
}).refine(v=>v.email||v.phone,{message:'Email or phone number is required.'});
const loginSchema = z.object({
  identifier:z.string().trim().min(1).max(320).optional(),
  email:z.string().trim().min(1).max(320).optional(),
  password:z.string().min(1).max(256)
}).refine(v=>v.identifier||v.email,{message:'Email, phone number, or username is required.'});
const refreshSchema=z.object({accountKey:z.string().regex(/^[a-f0-9]{16}$/).optional()}).default({});
const verificationRequestSchema=z.object({channel:z.enum(['email','sms'])});
const verificationConfirmSchema=z.object({channel:z.enum(['email','sms']),code:z.string().regex(/^\d{6}$/)});

function normalizePhone(value) {
  if (!value) return null;
  let raw=String(value).trim();
  const hasPlus=raw.startsWith('+');
  const digits=raw.replace(/\D/g,'');
  if (!digits) throw new ApiError(400,'INVALID_PHONE','Enter a valid phone number.');
  if (hasPlus) {
    if (digits.length<8 || digits.length>15) throw new ApiError(400,'INVALID_PHONE','Enter a valid phone number.');
    return `+${digits}`;
  }
  if (digits.length===10) return `+1${digits}`;
  if (digits.length===11 && digits.startsWith('1')) return `+${digits}`;
  throw new ApiError(400,'INVALID_PHONE','Use a full international phone number, including country code.');
}

function accountKeyFor(userId) { return sha256(String(userId)).slice(0,16); }
function scopedCookieName(accountKey) { return `${config.refreshCookieName}_${accountKey}`; }
function cookieOptions() {
  return {
    path:'/v1/auth',
    httpOnly:true,
    secure:config.cookieSecure,
    sameSite:config.cookieSameSite,
    domain:config.cookieDomain,
    maxAge:config.refreshTokenDays * 24 * 60 * 60
  };
}
function setRefreshCookies(reply,userId,token) {
  const accountKey=accountKeyFor(userId);
  reply.setCookie(scopedCookieName(accountKey),token,cookieOptions());
  // Legacy cookie keeps older clients working while the multi-account client rolls out.
  reply.setCookie(config.refreshCookieName,token,cookieOptions());
  return accountKey;
}
function clearRefreshCookies(reply,userId=null,accountKey=null) {
  if (userId) reply.clearCookie(scopedCookieName(accountKeyFor(userId)),cookieOptions());
  if (accountKey) reply.clearCookie(scopedCookieName(accountKey),cookieOptions());
  reply.clearCookie(config.refreshCookieName,cookieOptions());
}

async function createSession(app, userId, meta = {}) {
  const refresh = randomToken(48);
  const sessionId = opaqueId('sess');
  await db.query(
    `insert into sessions(id,user_id,refresh_token_hash,user_agent,ip_address,expires_at)
     values($1,$2,$3,$4,$5,now()+($6||' days')::interval)`,
    [sessionId,userId,sha256(refresh),meta.userAgent||null,meta.ip||null,String(config.refreshTokenDays)]
  );
  return { accessToken:app.jwt.sign({ sub:userId,sid:sessionId }), refreshToken:refresh, sessionId, accountKey:accountKeyFor(userId) };
}

async function rotateSession(app, refreshToken) {
  if (!refreshToken) throw new ApiError(401,'REFRESH_REQUIRED','Session refresh required.');
  const hash=sha256(refreshToken);
  const {rows}=await db.query(
    `select s.id,s.user_id,u.status from sessions s join users u on u.id=s.user_id
     where s.refresh_token_hash=$1 and s.revoked_at is null and s.expires_at>now()`,[hash]
  );
  const session=rows[0];
  if (!session || session.status!=='active') throw new ApiError(401,'SESSION_EXPIRED','Session is no longer valid.');
  const next=randomToken(48);
  await db.query(
    `update sessions set refresh_token_hash=$2,expires_at=now()+($3||' days')::interval where id=$1`,
    [session.id,sha256(next),String(config.refreshTokenDays)]
  );
  return { accessToken:app.jwt.sign({ sub:session.user_id,sid:session.id }), refreshToken:next, userId:session.user_id, accountKey:accountKeyFor(session.user_id) };
}

async function findLoginUser(identifier) {
  const raw=String(identifier||'').trim();
  if (!raw) return null;
  if (raw.startsWith('@')) {
    const {rows}=await db.query(`select u.id,u.password_hash,u.status from users u join profiles p on p.user_id=u.id where p.handle=$1 limit 1`,[raw.slice(1).toLowerCase()]);
    return rows[0]||null;
  }
  if (raw.includes('@')) {
    const {rows}=await db.query(`select id,password_hash,status from users where lower(email)=lower($1) limit 1`,[raw]);
    return rows[0]||null;
  }
  let phone=null;
  try { phone=normalizePhone(raw); } catch {}
  if (phone) {
    const {rows}=await db.query(`select id,password_hash,status from users where phone_e164=$1 limit 1`,[phone]);
    if (rows[0]) return rows[0];
  }
  const {rows}=await db.query(`select u.id,u.password_hash,u.status from users u join profiles p on p.user_id=u.id where p.handle=$1 limit 1`,[raw.toLowerCase()]);
  return rows[0]||null;
}

async function sendVerificationCode({channel,destination,code}) {
  if (channel==='email') {
    if (!config.resendApiKey || !config.authEmailFrom) throw new ApiError(503,'VERIFICATION_DELIVERY_UNAVAILABLE','Email verification delivery is not configured yet.');
    const r=await fetch('https://api.resend.com/emails',{
      method:'POST',
      headers:{Authorization:`Bearer ${config.resendApiKey}`,'Content-Type':'application/json'},
      body:JSON.stringify({from:config.authEmailFrom,to:[destination],subject:'Your PNGEA verification code',html:`<p>Your PNGEA verification code is <strong>${code}</strong>.</p><p>It expires in 10 minutes.</p>`})
    });
    if(!r.ok) throw new ApiError(502,'VERIFICATION_DELIVERY_FAILED','Could not send the verification email.');
    return;
  }
  if (!config.twilioAccountSid || !config.twilioAuthToken || !config.twilioFromNumber) throw new ApiError(503,'VERIFICATION_DELIVERY_UNAVAILABLE','SMS verification delivery is not configured yet.');
  const body=new URLSearchParams({To:destination,From:config.twilioFromNumber,Body:`Your PNGEA verification code is ${code}. It expires in 10 minutes.`});
  const r=await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(config.twilioAccountSid)}/Messages.json`,{
    method:'POST',
    headers:{Authorization:`Basic ${Buffer.from(`${config.twilioAccountSid}:${config.twilioAuthToken}`).toString('base64')}`,'Content-Type':'application/x-www-form-urlencoded'},
    body
  });
  if(!r.ok) throw new ApiError(502,'VERIFICATION_DELIVERY_FAILED','Could not send the verification text message.');
}

export async function registerAuth(app) {
  app.post('/v1/auth/signup', { config:{ rateLimit:{ max:8,timeWindow:'1 minute' } } }, async (req,reply)=>{
    const body=signupSchema.parse(req.body);
    const email=body.email?.trim().toLowerCase()||null;
    const phone=body.phone?normalizePhone(body.phone):null;
    const handle=body.handle.toLowerCase();
    const passwordHash=await argon2.hash(body.password,{type:argon2.argon2id});
    const userId=opaqueId('usr');
    try {
      await tx(async client=>{
        await client.query(`insert into users(id,email,phone_e164,password_hash,status) values($1,$2,$3,$4,'active')`,[userId,email,phone,passwordHash]);
        await client.query(`insert into profiles(user_id,handle,display_name) values($1,$2,$3)`,[userId,handle,body.displayName]);
        await client.query(`insert into user_settings(user_id) values($1)`,[userId]);
      });
    } catch (e) {
      if (e.code==='23505') throw new ApiError(409,'ACCOUNT_EXISTS','That email, phone number, or username is already in use.');
      throw e;
    }
    await audit({actorUserId:userId,action:'account.created',objectType:'user',objectId:userId});
    const session=await createSession(app,userId,{userAgent:req.headers['user-agent'],ip:req.ip});
    setRefreshCookies(reply,userId,session.refreshToken);
    reply.code(201).send({userId,accountKey:session.accountKey,accessToken:session.accessToken,expiresIn:config.accessTokenTtl});
  });

  app.post('/v1/auth/login',{config:{rateLimit:{max:12,timeWindow:'1 minute'}}},async (req,reply)=>{
    const body=loginSchema.parse(req.body);
    const user=await findLoginUser(body.identifier||body.email);
    if (!user || !(await argon2.verify(user.password_hash,body.password))) throw new ApiError(401,'INVALID_CREDENTIALS','That login or password did not match an account.');
    if (user.status!=='active') throw new ApiError(403,'ACCOUNT_UNAVAILABLE','This account is not currently active.');
    await audit({actorUserId:user.id,action:'auth.login'});
    const session=await createSession(app,user.id,{userAgent:req.headers['user-agent'],ip:req.ip});
    setRefreshCookies(reply,user.id,session.refreshToken);
    return {userId:user.id,accountKey:session.accountKey,accessToken:session.accessToken,expiresIn:config.accessTokenTtl};
  });

  app.post('/v1/auth/refresh',{config:{rateLimit:{max:60,timeWindow:'1 minute'}}},async (req,reply)=>{
    const body=refreshSchema.parse(req.body||{});
    const token=body.accountKey ? req.cookies?.[scopedCookieName(body.accountKey)] : req.cookies?.[config.refreshCookieName];
    const rotated=await rotateSession(app,token);
    if(body.accountKey && rotated.accountKey!==body.accountKey) throw new ApiError(401,'SESSION_EXPIRED','Session is no longer valid.');
    setRefreshCookies(reply,rotated.userId,rotated.refreshToken);
    return {userId:rotated.userId,accountKey:rotated.accountKey,accessToken:rotated.accessToken,expiresIn:config.accessTokenTtl};
  });

  app.post('/v1/auth/logout',{preHandler:[app.authenticate]},async (req,reply)=>{
    await db.query(`update sessions set revoked_at=now() where id=$1 and user_id=$2`,[req.user.sid,req.user.sub]);
    clearRefreshCookies(reply,req.user.sub);
    await audit({actorUserId:req.user.sub,action:'auth.logout'});
    return {ok:true};
  });

  app.post('/v1/auth/device-accounts/:accountKey/remove',async (req,reply)=>{
    const accountKey=String(req.params.accountKey||'');
    if(!/^[a-f0-9]{16}$/.test(accountKey)) throw new ApiError(400,'INVALID_ACCOUNT_KEY','Invalid device account.');
    const token=req.cookies?.[scopedCookieName(accountKey)];
    if(token){
      const hash=sha256(token);
      const {rows}=await db.query(`select id,user_id from sessions where refresh_token_hash=$1 and revoked_at is null`,[hash]);
      const session=rows[0];
      if(session && accountKeyFor(session.user_id)===accountKey) await db.query(`update sessions set revoked_at=now() where id=$1`,[session.id]);
      if(req.cookies?.[config.refreshCookieName] && sha256(req.cookies[config.refreshCookieName])===hash) reply.clearCookie(config.refreshCookieName,cookieOptions());
    }
    reply.clearCookie(scopedCookieName(accountKey),cookieOptions());
    return {ok:true};
  });

  app.post('/v1/auth/verification/request',{preHandler:[app.authenticate],config:{rateLimit:{max:5,timeWindow:'10 minutes'}}},async req=>{
    const body=verificationRequestSchema.parse(req.body);
    const {rows}=await db.query(`select email,phone_e164,email_verified_at,phone_verified_at from users where id=$1`,[req.user.sub]);
    const user=rows[0];
    const destination=body.channel==='email'?user?.email:user?.phone_e164;
    if(!destination) throw new ApiError(400,'CONTACT_MISSING',`No ${body.channel==='email'?'email address':'phone number'} is attached to this account.`);
    if(body.channel==='email'&&user.email_verified_at) return {ok:true,alreadyVerified:true};
    if(body.channel==='sms'&&user.phone_verified_at) return {ok:true,alreadyVerified:true};
    const code=String(crypto.randomInt(0,1_000_000)).padStart(6,'0');
    const id=opaqueId('verify');
    await db.query(`insert into auth_verification_codes(id,user_id,purpose,channel,destination,code_hash,expires_at) values($1,$2,'verify_contact',$3,$4,$5,now()+interval '10 minutes')`,[id,req.user.sub,body.channel,destination,sha256(code)]);
    try { await sendVerificationCode({channel:body.channel,destination,code}); }
    catch(e){ await db.query(`delete from auth_verification_codes where id=$1`,[id]); throw e; }
    return {ok:true,expiresInSeconds:600};
  });

  app.post('/v1/auth/verification/confirm',{preHandler:[app.authenticate],config:{rateLimit:{max:10,timeWindow:'10 minutes'}}},async req=>{
    const body=verificationConfirmSchema.parse(req.body);
    const {rows}=await db.query(`select id,code_hash,attempts from auth_verification_codes where user_id=$1 and purpose='verify_contact' and channel=$2 and consumed_at is null and expires_at>now() order by created_at desc limit 1`,[req.user.sub,body.channel]);
    const challenge=rows[0];
    if(!challenge) throw new ApiError(400,'CODE_EXPIRED','Request a new verification code.');
    if(challenge.attempts>=5) throw new ApiError(429,'TOO_MANY_ATTEMPTS','Request a new verification code.');
    if(sha256(body.code)!==challenge.code_hash){await db.query(`update auth_verification_codes set attempts=attempts+1 where id=$1`,[challenge.id]);throw new ApiError(400,'INVALID_CODE','That verification code is not correct.');}
    await tx(async client=>{
      await client.query(`update auth_verification_codes set consumed_at=now() where id=$1`,[challenge.id]);
      if(body.channel==='email') await client.query(`update users set email_verified_at=coalesce(email_verified_at,now()),updated_at=now() where id=$1`,[req.user.sub]);
      else await client.query(`update users set phone_verified_at=coalesce(phone_verified_at,now()),updated_at=now() where id=$1`,[req.user.sub]);
    });
    await audit({actorUserId:req.user.sub,action:`auth.${body.channel}.verified`});
    return {ok:true};
  });

  app.get('/v1/me',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select u.id,u.email,u.phone_e164,u.email_verified_at,u.phone_verified_at,u.created_at,p.handle,p.display_name,p.bio,p.avatar_url,p.banner_url,
       (select count(*)::int from follows where follower_id=u.id) following,
       (select count(*)::int from follows where followee_id=u.id) followers
       from users u join profiles p on p.user_id=u.id where u.id=$1`,[req.user.sub]
    );
    if (!rows[0]) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    return {...rows[0],account_key:accountKeyFor(req.user.sub)};
  });
}
