import { startAlpacaStreams } from './providers/alpaca-stream.js';
import { startRssNewsPolling } from './providers/rss-news.js';
import { startSportsScorePolling } from './providers/sports-scores.js';

process.on('unhandledRejection',err=>{console.error(err);process.exitCode=1});
process.on('SIGTERM',()=>process.exit(0));
process.on('SIGINT',()=>process.exit(0));

await Promise.all([
  startAlpacaStreams(),
  startRssNewsPolling(),
  startSportsScorePolling()
]);
