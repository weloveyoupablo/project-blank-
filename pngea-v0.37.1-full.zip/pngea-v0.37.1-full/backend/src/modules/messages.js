import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { ApiError } from '../lib/errors.js';
import { publishToUsers } from '../lib/events.js';
import { notify } from '../lib/notify.js';

const createConversation=z.object({memberIds:z.array(z.string()).min(1).max(99),title:z.string().max(120).nullable().optional()});
const sendMessage=z.object({
  text:z.string().max(10000).default(''),
  mediaIds:z.array(z.string()).max(10).default([]),
  clientId:z.string().trim().min(8).max(120).optional()
}).refine(v=>v.text.trim()||v.mediaIds.length,'Message cannot be empty.');

// A block also closes shared groups for the affected accounts. Checking all
// active peers prevents a group invitation from bypassing a direct-message block.
const noBlockedPeer=`not exists(select 1 from conversation_members peer join blocks bl
  on ((bl.blocker_id=cm.user_id and bl.blocked_id=peer.user_id) or (bl.blocker_id=peer.user_id and bl.blocked_id=cm.user_id))
  where peer.conversation_id=c.id and peer.left_at is null)`;
const visibleSender=(viewer='$1',message='m')=>`not exists(select 1 from blocks sender_block
  where (sender_block.blocker_id=${viewer} and sender_block.blocked_id=${message}.sender_id)
     or (sender_block.blocker_id=${message}.sender_id and sender_block.blocked_id=${viewer}))`;
const mutualPeers=`c.direct_key is not null and not exists(select 1 from conversation_members peer
  where peer.conversation_id=c.id and peer.left_at is null and peer.user_id<>cm.user_id and
  (not exists(select 1 from follows f where f.follower_id=cm.user_id and f.followee_id=peer.user_id)
   or not exists(select 1 from follows f where f.follower_id=peer.user_id and f.followee_id=cm.user_id)))`;
function requestMetadata(row){
  const status=row.request_status||'accepted';
  return {request_status:status,requester_id:row.requester_id||null,viewer_can_message:status==='accepted'};
}
async function assertMember(userId,conversationId,client=db,{lock=false,allowDeclined=false}={}) {
  const {rows,rowCount}=await client.query(`select c.id,c.direct_key,c.request_status,c.requester_id,(${mutualPeers}) is_mutual
    from conversations c join conversation_members cm on cm.conversation_id=c.id
    where c.id=$1 and cm.user_id=$2 and cm.left_at is null and ${noBlockedPeer}${lock?' for update of c':''}`,[conversationId,userId]);
  if (!rowCount) throw new ApiError(404,'CONVERSATION_NOT_FOUND','Conversation unavailable.');
  const row=rows[0]||{};
  if(row.request_status==='declined'&&!allowDeclined)throw new ApiError(404,'CONVERSATION_NOT_FOUND','Conversation unavailable.');
  // Becoming mutual followers opens a fresh conversation without a request.
  // Persist the decision so a later unfollow does not interrupt an established chat.
  if(row.is_mutual&&['none','pending'].includes(row.request_status)){
    await client.query(`update conversations set request_status='accepted',updated_at=now() where id=$1 and request_status in('none','pending')`,[conversationId]);
    row.request_status='accepted';
  }
  return requestMetadata(row);
}
function assertCanMessage(state){if(!state.viewer_can_message)throw new ApiError(403,'MESSAGE_REQUEST_REQUIRED','This message request must be accepted before you can send messages.');}
async function members(conversationId){return (await db.query(`select cm.user_id from conversation_members cm join conversations c on c.id=cm.conversation_id
  where c.id=$1 and cm.left_at is null and ${noBlockedPeer}`,[conversationId])).rows.map(r=>r.user_id)}
function deliver(req,recipients,type,data){return publishToUsers(recipients,type,data).catch(err=>req.log?.warn?.(err,'Conversation realtime delivery failed'));}
const directKey=ids=>[...ids].sort().join(':');

export async function registerMessages(app) {
  app.get('/v1/conversations',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select c.id,c.title,c.direct_key,c.updated_at,
       case when c.request_status in('none','pending') and (${mutualPeers}) then 'accepted' else c.request_status end request_status,
       c.requester_id,(c.request_status='accepted' or (c.request_status in('none','pending') and (${mutualPeers}))) viewer_can_message,
       (select text from messages m where m.conversation_id=c.id and m.deleted_at is null and ${visibleSender()} order by m.created_at desc limit 1) last_message,
       (select created_at from messages m where m.conversation_id=c.id and m.deleted_at is null and ${visibleSender()} order by m.created_at desc limit 1) last_message_at,
       (select count(*)::int from messages m where m.conversation_id=c.id and m.sender_id<>$1 and m.created_at>coalesce(cm.last_read_at,'epoch') and m.deleted_at is null and ${visibleSender()}) unread,
       coalesce((select jsonb_agg(jsonb_build_object('id',p.user_id,'handle',p.handle,'displayName',p.display_name,'avatarUrl',p.avatar_url,'avatarMediaId',p.avatar_media_id,'lastReadAt',cm2.last_read_at) order by p.display_name)
         from conversation_members cm2 join profiles p on p.user_id=cm2.user_id
         where cm2.conversation_id=c.id and cm2.left_at is null and cm2.user_id<>$1),'[]'::jsonb) members
       from conversations c join conversation_members cm on cm.conversation_id=c.id
       where cm.user_id=$1 and cm.left_at is null and c.request_status<>'declined'
         and (c.request_status<>'none' or c.created_by=$1) and ${noBlockedPeer}
       order by coalesce((select max(m.created_at) from messages m where m.conversation_id=c.id and m.deleted_at is null and ${visibleSender()}),c.updated_at) desc`,[req.user.sub]
    );
    return {items:rows};
  });

  app.post('/v1/conversations',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=createConversation.parse(req.body); const memberIds=[...new Set([req.user.sub,...b.memberIds])];
    if(memberIds.length<2)throw new ApiError(400,'INVALID_MEMBERS','Choose another account to message.');
    // A title does not turn a two-person chat into an unrestricted group.
    const isDirect=memberIds.length===2;
    const key=isDirect?directKey(memberIds):null;
    let id=null,created=false;
    await tx(async c=>{
      const valid=await c.query(`select id from users where id=any($1::text[]) and status='active' and deleted_at is null`,[memberIds]);
      const blocked=await c.query(`select 1 from blocks where blocker_id=any($1::text[]) and blocked_id=any($1::text[]) limit 1`,[memberIds]);
      if(valid.rowCount!==memberIds.length||blocked.rowCount)throw new ApiError(404,'CONVERSATION_NOT_FOUND','Conversation unavailable.');
      const relationship=await c.query(`select not exists(select 1 from unnest($1::text[]) a(user_id) cross join unnest($1::text[]) b(user_id)
        where a.user_id<>b.user_id and not exists(select 1 from follows f where f.follower_id=a.user_id and f.followee_id=b.user_id)) is_mutual`,[memberIds]);
      const isMutual=!!relationship.rows[0]?.is_mutual;
      if(!isDirect&&!isMutual)throw new ApiError(403,'MESSAGE_REQUEST_REQUIRED','Group members must follow one another before starting a group chat.');
      if(key){
        const existing=await c.query(`select id,request_status from conversations where direct_key=$1 limit 1 for update`,[key]);
        if(existing.rows[0]?.request_status==='declined')throw new ApiError(404,'CONVERSATION_NOT_FOUND','Conversation unavailable.');
        if(existing.rows[0]) id=existing.rows[0].id;
      }
      if(!id){
        const candidate=opaqueId('cnv');
        if(key){
          const inserted=await c.query(`insert into conversations(id,title,created_by,direct_key,request_status) values($1,$2,$3,$4,$5) on conflict (direct_key) where direct_key is not null do nothing returning id`,[candidate,null,req.user.sub,key,isMutual?'accepted':'none']);
          id=inserted.rows[0]?.id||null;
          if(!id){const existing=(await c.query(`select id,request_status from conversations where direct_key=$1 limit 1 for update`,[key])).rows[0];if(existing?.request_status==='declined')throw new ApiError(404,'CONVERSATION_NOT_FOUND','Conversation unavailable.');id=existing?.id;}
          created=!!inserted.rows[0];
        }else{
          id=candidate;await c.query(`insert into conversations(id,title,created_by,request_status) values($1,$2,$3,'accepted')`,[id,b.title??null,req.user.sub]);created=true;
        }
      }
      if(!id) throw new ApiError(500,'CONVERSATION_CREATE_FAILED','Could not start conversation.');
      for(const uid of memberIds){
        await c.query(`insert into conversation_members(conversation_id,user_id,last_read_at,left_at) values($1,$2,case when $2=$3 then now() else null end,null)
          on conflict(conversation_id,user_id) do update set left_at=null`,[id,uid,req.user.sub]);
      }
      await c.query(`update conversations set updated_at=now() where id=$1`,[id]);
    });
    const state=await assertMember(req.user.sub,id);
    if(created&&state.viewer_can_message)await deliver(req,memberIds,'conversation.created',{conversationId:id});
    reply.code(created?201:200).send({id,reused:!created,...state});
  });

  app.post('/v1/conversations/:id/request',{preHandler:[app.authenticate]},async req=>{
    let changed=false,state;
    await tx(async c=>{
      state=await assertMember(req.user.sub,req.params.id,c,{lock:true});
      if(state.request_status!=='none')return;
      const disabled=await c.query(`select 1 from conversation_members recipient join user_settings settings on settings.user_id=recipient.user_id
        where recipient.conversation_id=$1 and recipient.user_id<>$2 and recipient.left_at is null and settings.allow_message_requests=false limit 1`,[req.params.id,req.user.sub]);
      if(disabled.rowCount)throw new ApiError(403,'REQUESTS_DISABLED','This account is not accepting message requests.');
      await c.query(`update conversations set request_status='pending',requester_id=$2,updated_at=now() where id=$1`,[req.params.id,req.user.sub]);
      state={request_status:'pending',requester_id:req.user.sub,viewer_can_message:false};changed=true;
    });
    if(changed){
      const recipients=await members(req.params.id);
      const results=await Promise.allSettled(recipients.filter(uid=>uid!==req.user.sub).map(userId=>notify({userId,actorUserId:req.user.sub,kind:'message_request',objectType:'conversation',objectId:req.params.id,payload:{conversationId:req.params.id}})));
      for(const result of results)if(result.status==='rejected')req.log?.warn?.(result.reason,'Message request notification delivery failed');
      await deliver(req,recipients,'conversation.request',{conversationId:req.params.id,...state});
    }
    return {id:req.params.id,...state};
  });

  app.post('/v1/conversations/:id/request/respond',{preHandler:[app.authenticate]},async req=>{
    const {accept}=z.object({accept:z.boolean()}).parse(req.body);
    let changed=false,state;
    await tx(async c=>{
      state=await assertMember(req.user.sub,req.params.id,c,{lock:true,allowDeclined:true});
      if(state.requester_id===req.user.sub)throw new ApiError(403,'REQUEST_RECIPIENT_REQUIRED','Only the recipient can respond to this request.');
      if(state.request_status==='accepted'&&accept)return;
      if(state.request_status==='declined'&&!accept)return;
      if(state.request_status!=='pending')throw new ApiError(409,'REQUEST_NOT_PENDING','This message request is no longer pending.');
      const status=accept?'accepted':'declined';
      await c.query(`update conversations set request_status=$2,updated_at=now() where id=$1`,[req.params.id,status]);
      await c.query(`delete from conversation_typing where conversation_id=$1`,[req.params.id]);
      state={...state,request_status:status,viewer_can_message:accept};changed=true;
    });
    if(changed)await deliver(req,await members(req.params.id),'conversation.request',{conversationId:req.params.id,...state});
    return {id:req.params.id,...state};
  });

  app.post('/v1/conversations/:id/typing',{preHandler:[app.authenticate],config:{rateLimit:{max:60,timeWindow:'1 minute'}}},async req=>{
    const {typing}=z.object({typing:z.boolean()}).parse(req.body);
    let expiresAt=null,changed=false;
    await tx(async c=>{
      assertCanMessage(await assertMember(req.user.sub,req.params.id,c,{lock:true}));
      if(typing){
        const result=await c.query(`insert into conversation_typing(conversation_id,user_id,updated_at,expires_at) values($1,$2,now(),now()+interval '6 seconds')
          on conflict(conversation_id,user_id) do update set updated_at=now(),expires_at=now()+interval '6 seconds'
          where conversation_typing.updated_at<=now()-interval '2 seconds' returning expires_at`,[req.params.id,req.user.sub]);
        expiresAt=result.rows[0]?.expires_at||null;changed=!!expiresAt;
      }else changed=!!(await c.query(`delete from conversation_typing where conversation_id=$1 and user_id=$2 returning user_id`,[req.params.id,req.user.sub])).rowCount;
    });
    if(changed)await deliver(req,(await members(req.params.id)).filter(uid=>uid!==req.user.sub),'conversation.typing',{conversationId:req.params.id,userId:req.user.sub,typing,expiresAt});
    return {ok:true,expiresAt};
  });

  app.get('/v1/conversations/:id/messages',{preHandler:[app.authenticate]},async req=>{
    const state=await assertMember(req.user.sub,req.params.id);
    if(!state.viewer_can_message)return {items:[],nextCursor:null,typing:[],...state};
    const supplied=Number(req.query?.limit??50);
    if(!Number.isInteger(supplied)||supplied<1||supplied>500)throw new ApiError(400,'INVALID_LIMIT','Message limit must be an integer from 1 to 500.');
    let beforeAt=null,beforeId=null;
    if(req.query?.before){try{const cursor=JSON.parse(Buffer.from(String(req.query.before),'base64url').toString());if(typeof cursor.id!=='string'||!cursor.id||!Number.isFinite(Date.parse(cursor.at)))throw new Error();beforeAt=cursor.at;beforeId=cursor.id}catch{throw new ApiError(400,'INVALID_CURSOR','Invalid message cursor.')}}
    const {rows}=await db.query(
      `select m.*,
       coalesce((select jsonb_agg(jsonb_build_object('id',med.id,'mimeType',med.mime_type,'status',med.status,'edit',med.edit_json) order by mm.position)
         from message_media mm join media med on med.id=mm.media_id where mm.message_id=m.id),'[]'::jsonb) media,
       coalesce((select jsonb_agg(jsonb_build_object('userId',cm.user_id,'readAt',cm.last_read_at))
         from conversation_members cm where cm.conversation_id=m.conversation_id and cm.user_id<>m.sender_id and cm.left_at is null and cm.last_read_at>=m.created_at),'[]'::jsonb) read_by
       from (select * from messages where conversation_id=$1 and deleted_at is null and ${visibleSender('$5','messages')} and ($2::timestamptz is null or (created_at,id)<($2::timestamptz,$3::text)) order by created_at desc,id desc limit $4) m order by m.created_at asc,m.id asc`,[req.params.id,beforeAt,beforeId,supplied+1,req.user.sub]
    );
    const hasMore=rows.length>supplied,items=hasMore?rows.slice(-supplied):rows;
    const typing=(await db.query(`select user_id as "userId",expires_at as "expiresAt" from conversation_typing where conversation_id=$1 and user_id<>$2 and expires_at>now()`,[req.params.id,req.user.sub])).rows;
    const first=items[0];return {items,nextCursor:hasMore&&first?Buffer.from(JSON.stringify({at:first.created_at,id:first.id})).toString('base64url'):null,typing,...state};
  });

  app.post('/v1/conversations/:id/messages',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=sendMessage.parse(req.body); let id=opaqueId('msg'),created=true;
    await tx(async c=>{
      assertCanMessage(await assertMember(req.user.sub,req.params.id,c,{lock:true}));
      if(b.clientId){
        const old=await c.query(`select id from messages where conversation_id=$1 and sender_id=$2 and client_id=$3 limit 1`,[req.params.id,req.user.sub,b.clientId]);
        if(old.rows[0]){id=old.rows[0].id;created=false;return}
      }
      const inserted=await c.query(`insert into messages(id,conversation_id,sender_id,text,client_id) values($1,$2,$3,$4,$5)
        on conflict (conversation_id,sender_id,client_id) where client_id is not null do nothing returning id`,[id,req.params.id,req.user.sub,b.text,b.clientId??null]);
      if(!inserted.rows[0]){
        const existing=await c.query(`select id from messages where conversation_id=$1 and sender_id=$2 and client_id=$3`,[req.params.id,req.user.sub,b.clientId]);
        id=existing.rows[0]?.id;if(!id)throw new ApiError(409,'MESSAGE_RETRY','Retry this message.');created=false;return;
      }
      if (b.mediaIds.length) {
        const q=await c.query(`select id from media where owner_user_id=$1 and id=any($2::text[]) and status='ready'`,[req.user.sub,b.mediaIds]);
        if(q.rowCount!==b.mediaIds.length) throw new ApiError(409,'MEDIA_NOT_READY','One or more attachments are unavailable.');
        for(let i=0;i<b.mediaIds.length;i++) await c.query(`insert into message_media(message_id,media_id,position) values($1,$2,$3)`,[id,b.mediaIds[i],i]);
      }
      await c.query(`update conversations set updated_at=now() where id=$1`,[req.params.id]);
      await c.query(`update conversation_members set last_read_at=now() where conversation_id=$1 and user_id=$2`,[req.params.id,req.user.sub]);
      await c.query(`delete from conversation_typing where conversation_id=$1 and user_id=$2`,[req.params.id,req.user.sub]);
    });
    const recipients=await members(req.params.id);
    if(created){
      void deliver(req,recipients,'message.created',{conversationId:req.params.id,messageId:id,senderId:req.user.sub});
      void deliver(req,recipients.filter(uid=>uid!==req.user.sub),'conversation.typing',{conversationId:req.params.id,userId:req.user.sub,typing:false,expiresAt:null});
    }
    reply.code(created?201:200).send({id,reused:!created});
  });

  app.post('/v1/conversations/:id/read',{preHandler:[app.authenticate]},async req=>{
    assertCanMessage(await assertMember(req.user.sub,req.params.id));
    const messageId=z.object({messageId:z.string().optional()}).parse(req.body||{}).messageId;
    const updated=await db.query(`update conversation_members cm set last_read_at=latest.at
      from (select max(created_at) at from messages where conversation_id=$1 and deleted_at is null and ($3::text is null or created_at<=(select created_at from messages where id=$3 and conversation_id=$1))) latest
      where cm.conversation_id=$1 and cm.user_id=$2 and latest.at is not null and (cm.last_read_at is null or cm.last_read_at<latest.at) returning cm.last_read_at`,[req.params.id,req.user.sub,messageId||null]);
    const at=updated.rows[0]?.last_read_at;
    if(at)await publishToUsers(await members(req.params.id),'conversation.read',{conversationId:req.params.id,userId:req.user.sub,at});
    return {ok:true,readAt:at||null};
  });
}
