import crypto from 'node:crypto';
import { z } from 'zod';
import { db } from '../lib/db.js';
import { ApiError } from '../lib/errors.js';
import { diversify,marketScore,newsScore,estimateImportance,inferTopics,newsLabel,shouldSurfaceNews,marketMoveTier } from '../lib/ticker-ranker.js';

const prefSchema=z.object({
  enabled:z.boolean().optional(),
  categories:z.array(z.enum(['you','news','markets','live'])).min(1).max(4).optional(),
  symbols:z.array(z.string().regex(/^[A-Z0-9.\/-]{1,15}$/)).max(50).optional(),
  topics:z.array(z.string().min(1).max(40)).max(30).optional(),
  maxItems:z.number().int().min(3).max(20).optional()
});
const ingestSchema=z.object({
  provider:z.string().min(1).max(80),
  providerItemId:z.union([z.string(),z.number()]).transform(String),
  sourceName:z.string().min(1).max(120),
  headline:z.string().min(3).max(500),
  summary:z.string().max(3000).optional().default(''),
  url:z.string().url().max(2000).nullable().optional(),
  author:z.string().max(200).nullable().optional(),
  symbols:z.array(z.string().max(15)).max(100).optional().default([]),
  topics:z.array(z.string().max(40)).max(50).optional().default([]),
  publishedAt:z.string().datetime(),
  updatedAt:z.string().datetime().nullable().optional(),
  importance:z.number().int().min(0).max(100).optional(),
  official:z.boolean().optional().default(false),
  sourceWeight:z.number().min(0).max(1).optional().default(.7),
  status:z.enum(['active','corrected','retracted']).optional().default('active'),
  correctionNote:z.string().max(1000).nullable().optional(),
  raw:z.record(z.any()).optional().default({})
});

const normalizeHeadline=s=>String(s).toLowerCase().replace(/https?:\/\/\S+/g,' ').replace(/[^a-z0-9\s]/g,' ').replace(/\b(update|breaking|exclusive|live)\b/g,' ').replace(/\s+/g,' ').trim();
const storyKey=s=>crypto.createHash('sha1').update(normalizeHeadline(s)).digest('hex');
const fmtPct=n=>`${Number(n)>=0?'▲':'▼'} ${Math.abs(Number(n)).toFixed(Math.abs(Number(n))>=10?1:2)}%`;
const recent=(date,ms)=>Date.now()-new Date(date).getTime()<=ms;

async function ensurePrefs(userId){
  const {rows}=await db.query(`insert into user_ticker_preferences(user_id) values($1) on conflict(user_id) do update set user_id=excluded.user_id returning *`,[userId]);
  return rows[0];
}

async function buildTicker(userId){
  const prefs=await ensurePrefs(userId);
  if(!prefs.enabled) return [];
  const categories=new Set(prefs.categories||[]),candidates=[];

  if(categories.has('you')){
    const {rows}=await db.query(`select id,kind,payload,created_at from notifications where user_id=$1 and read_at is null and created_at>now()-interval '12 hours' order by created_at desc limit 4`,[userId]);
    for(const n of rows){
      const text=n.payload?.text||n.payload?.message||n.kind.replaceAll('_',' ');
      candidates.push({key:`you:${n.id}`,kind:'you',label:'YOU',text:String(text).slice(0,180),score:1.15,asOf:n.created_at,route:'Notifications'});
    }
  }

  if(categories.has('live')){
    const {rows}=await db.query(`select id,kind,title,created_at,expires_at from now_events where (user_id=$1 or user_id is null) and expires_at>now() order by priority desc,created_at desc limit 4`,[userId]);
    for(const e of rows)candidates.push({key:`live:${e.id}`,kind:'live',label:'LIVE',text:e.title,score:.76+Math.min(0.15,Math.max(0,(Date.now()-new Date(e.created_at).getTime()<15*60_000)?.15:0)),asOf:e.created_at,route:'Now'});
  }

  if(categories.has('markets')){
    const symbols=(prefs.symbols||[]).map(x=>String(x).toUpperCase());
    const {rows}=await db.query(`select * from market_quotes where symbol=any($1::text[]) and as_of>now()-interval '36 hours' order by abs(coalesce(change_percent,0)) desc,as_of desc limit 12`,[symbols]);
    for(const q of rows){
      const fresh=recent(q.as_of,q.delayed?20*60_000:5*60_000);
      const label=q.delayed?'MARKETS · 15M':'MARKETS';
      const price=q.last_price==null?'':` · $${Number(q.last_price).toLocaleString(undefined,{maximumFractionDigits:2,minimumFractionDigits:2})}`;
      const pct=q.change_percent==null?'':` ${fmtPct(q.change_percent)}`;
      const marketTier=marketMoveTier(q);
      if(marketTier==='routine'&&!symbols.includes(String(q.symbol).toUpperCase())) continue;
      candidates.push({key:`market:${q.symbol}`,kind:'markets',label:marketTier==='extreme'?'MARKET ALERT':label,text:`${q.symbol}${pct}${price}`,score:marketScore(q,{symbols})+(fresh?.04:-.12),asOf:q.as_of,source:q.source,feed:q.feed,delayed:q.delayed,stale:!fresh,query:q.symbol,marketTier});
    }
  }

  if(categories.has('news')){
    const symbols=(prefs.symbols||[]).map(x=>String(x).toUpperCase()),topics=(prefs.topics||[]).map(x=>String(x).toLowerCase());
    const {rows}=await db.query(`
      select n.*,(select count(distinct x.source_name)::int from external_news_articles x where x.story_key=n.story_key and x.published_at>now()-interval '24 hours') corroboration_count
      from external_news_articles n
      where n.published_at>now()-interval '6 hours' and n.status<>'retracted'
        and (n.importance>=65 or n.symbols && $1::text[] or n.topics && $2::text[])
      order by n.published_at desc limit 50`,[symbols,topics]);
    for(const a of rows){
      const verification=a.verification_status==='official'?'official':Number(a.corroboration_count||0)>1?'corroborated':'single_source';
      const article={...a,verification_status:verification};
      if(!shouldSurfaceNews(article,{symbols,topics}))continue;
      const score=newsScore(article,{symbols,topics});
      if(score<.40)continue;
      candidates.push({key:`news:${a.story_key}`,kind:'news',label:newsLabel(article),text:a.headline,score,asOf:a.published_at,source:a.source_name,url:a.url,verification,importance:Number(a.importance||0),topics:a.topics||[],symbols:a.symbols||[]});
    }
  }

  return diversify(candidates,Number(prefs.max_items||8)).map(({score,...x})=>x);
}

export async function registerTicker(app){
  app.get('/v1/ticker',{preHandler:[app.authenticate]},async req=>({items:await buildTicker(req.user.sub),generatedAt:new Date().toISOString()}));

  app.get('/v1/ticker/preferences',{preHandler:[app.authenticate]},async req=>({preferences:await ensurePrefs(req.user.sub)}));

  app.patch('/v1/ticker/preferences',{preHandler:[app.authenticate]},async req=>{
    const b=prefSchema.parse(req.body||{}),old=await ensurePrefs(req.user.sub);
    const next={
      enabled:b.enabled??old.enabled,
      categories:b.categories??old.categories,
      symbols:(b.symbols??old.symbols).map(x=>x.toUpperCase()),
      topics:(b.topics??old.topics).map(x=>x.toLowerCase()),
      maxItems:b.maxItems??old.max_items
    };
    const {rows}=await db.query(`update user_ticker_preferences set enabled=$2,categories=$3,symbols=$4,topics=$5,max_items=$6,updated_at=now() where user_id=$1 returning *`,[req.user.sub,next.enabled,next.categories,next.symbols,next.topics,next.maxItems]);
    return {preferences:rows[0]};
  });

  app.post('/v1/internal/news',async req=>{
    const secret=req.headers['x-pngea-ingest-key'];
    if(!process.env.PNGEA_INGEST_SECRET||secret!==process.env.PNGEA_INGEST_SECRET) throw new ApiError(403,'FORBIDDEN','Invalid ingest credential.');
    const b=ingestSchema.parse(req.body),key=storyKey(b.headline);
    const topics=[...new Set([...(b.topics||[]).map(x=>x.toLowerCase()),...inferTopics(b.headline,b.summary)])];
    const importance=b.importance??estimateImportance(b.headline);
    const status=b.official?'official':'single_source';
    const {rows}=await db.query(`insert into external_news_articles(id,provider,provider_item_id,source_name,headline,summary,url,author,symbols,topics,story_key,importance,verification_status,source_weight,status,correction_note,published_at,updated_at,raw)
      values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19::jsonb)
      on conflict(provider,provider_item_id) do update set headline=excluded.headline,summary=excluded.summary,url=excluded.url,author=excluded.author,symbols=excluded.symbols,topics=excluded.topics,importance=excluded.importance,verification_status=case when external_news_articles.verification_status='official' then 'official' else excluded.verification_status end,source_weight=excluded.source_weight,status=excluded.status,correction_note=excluded.correction_note,updated_at=excluded.updated_at,raw=excluded.raw
      returning *`,[`news_${crypto.randomUUID()}`,b.provider,b.providerItemId,b.sourceName,b.headline,b.summary,b.url??null,b.author??null,b.symbols.map(x=>x.toUpperCase()),topics,key,importance,status,b.sourceWeight,b.status,b.correctionNote??null,b.publishedAt,b.updatedAt??null,JSON.stringify(b.raw)]);
    await db.query(`update external_news_articles set verification_status='corroborated' where story_key=$1 and verification_status<>'official' and (select count(distinct source_name) from external_news_articles where story_key=$1 and published_at>now()-interval '24 hours')>1`,[key]);
    await db.query(`insert into news_ingest_audit(provider,source_name,provider_item_id,accepted) values($1,$2,$3,true)`,[b.provider,b.sourceName,b.providerItemId]);
    return rows[0];
  });
}
