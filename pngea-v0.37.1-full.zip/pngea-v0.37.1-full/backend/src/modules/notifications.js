import { db } from '../lib/db.js';

// Keep the list and its badge on the same audience and request-state boundary.
const visibleNotification=`not exists(select 1 from blocks b where (b.blocker_id=$1 and b.blocked_id=n.actor_user_id) or (b.blocker_id=n.actor_user_id and b.blocked_id=$1))
  and (n.object_type is distinct from 'conversation' or exists(
    select 1 from conversations c join conversation_members cm on cm.conversation_id=c.id
    where c.id=n.object_id and cm.user_id=$1 and cm.left_at is null
      and (c.request_status='accepted' or (c.request_status='pending' and n.kind='message_request'))
      and not exists(select 1 from conversation_members peer join blocks b on
        (b.blocker_id=$1 and b.blocked_id=peer.user_id) or (b.blocker_id=peer.user_id and b.blocked_id=$1)
        where peer.conversation_id=c.id and peer.left_at is null)))`;

export async function registerNotifications(app){

  app.get('/v1/me/unread-counts',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select
       (select count(*)::int from notifications n where n.user_id=$1 and n.read_at is null and ${visibleNotification}) notifications,
       (select count(*)::int
          from messages m join conversation_members cm on cm.conversation_id=m.conversation_id join conversations c on c.id=m.conversation_id
          where cm.user_id=$1 and cm.left_at is null and m.sender_id<>$1
            and c.request_status='accepted'
            and not exists(select 1 from blocks sender_block where (sender_block.blocker_id=$1 and sender_block.blocked_id=m.sender_id) or (sender_block.blocker_id=m.sender_id and sender_block.blocked_id=$1))
            and not exists(select 1 from conversation_members peer join blocks b on
              (b.blocker_id=$1 and b.blocked_id=peer.user_id) or (b.blocker_id=peer.user_id and b.blocked_id=$1)
              where peer.conversation_id=m.conversation_id and peer.left_at is null)
            and m.created_at>coalesce(cm.last_read_at,'epoch') and m.deleted_at is null) messages`,
      [req.user.sub]
    );
    return rows[0]||{notifications:0,messages:0};
  });

  app.get('/v1/notifications',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select n.*,p.handle actor_handle,p.display_name actor_display_name,p.avatar_url actor_avatar_url,p.avatar_media_id actor_avatar_media_id
       from notifications n left join profiles p on p.user_id=n.actor_user_id
       where n.user_id=$1
         and ${visibleNotification}
       order by n.created_at desc limit 100`,[req.user.sub]
    );
    return {items:rows};
  });
  app.post('/v1/notifications/read-all',{preHandler:[app.authenticate]},async req=>{
    await db.query(`update notifications set read_at=coalesce(read_at,now()) where user_id=$1`,[req.user.sub]);
    return {ok:true};
  });
  app.post('/v1/notifications/:id/read',{preHandler:[app.authenticate]},async req=>{
    await db.query(`update notifications set read_at=coalesce(read_at,now()) where id=$1 and user_id=$2`,[req.params.id,req.user.sub]);
    return {ok:true};
  });
}
