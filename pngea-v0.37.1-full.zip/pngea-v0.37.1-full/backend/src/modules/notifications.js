import { db } from '../lib/db.js';

export async function registerNotifications(app){

  app.get('/v1/me/unread-counts',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select
       (select count(*)::int from notifications where user_id=$1 and read_at is null) notifications,
       (select count(*)::int
          from messages m join conversation_members cm on cm.conversation_id=m.conversation_id
          where cm.user_id=$1 and cm.left_at is null and m.sender_id<>$1
            and m.created_at>coalesce(cm.last_read_at,'epoch') and m.deleted_at is null) messages`,
      [req.user.sub]
    );
    return rows[0]||{notifications:0,messages:0};
  });

  app.get('/v1/notifications',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select n.*,p.handle actor_handle,p.display_name actor_display_name,p.avatar_url actor_avatar_url,p.avatar_media_id actor_avatar_media_id
       from notifications n left join profiles p on p.user_id=n.actor_user_id
       where n.user_id=$1 order by n.created_at desc limit 100`,[req.user.sub]
    );
    return {items:rows};
  });
  app.post('/v1/notifications/read-all',{preHandler:[app.authenticate]},async req=>{
    await db.query(`update notifications set read_at=coalesce(read_at,now()) where user_id=$1`,[req.user.sub]);
    return {ok:true};
  });
  app.post('/v1/notifications/:id/read',{preHandler:[app.authenticate]},async req=>{
    await db.query(`update notifications set read_at=coalesce(read_at,now()) where id=$1 and user_id=$2`,[req.params.id,req.user.sub]);
    return {ok:true};
  });
}
