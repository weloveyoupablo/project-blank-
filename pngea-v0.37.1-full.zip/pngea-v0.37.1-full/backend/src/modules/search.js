import { db } from '../lib/db.js';

export async function registerSearch(app){
  app.get('/v1/search',{preHandler:[app.optionalAuth]},async req=>{
    const q=String(req.query.q||'').trim();
    if(!q) return {query:q,people:[],posts:[]};
    const viewer=req.user?.sub||null;
    const people=await db.query(
      `select p.user_id as id,p.handle,p.display_name,p.bio,p.avatar_url,p.avatar_media_id,
       exists(select 1 from follows vf where vf.follower_id=$3 and vf.followee_id=p.user_id) viewer_following
       from profiles p join users u on u.id=p.user_id
       where u.status='active' and u.deleted_at is null
         and (p.search_document @@ websearch_to_tsquery('simple',$1) or p.handle ilike $2)
         and not exists(select 1 from blocks b where (b.blocker_id=$3 and b.blocked_id=p.user_id) or (b.blocker_id=p.user_id and b.blocked_id=$3))
       order by ts_rank(p.search_document,websearch_to_tsquery('simple',$1)) desc limit 20`,[q,`%${q}%`,viewer]);
    const posts=await db.query(
      `select p.id,p.text,p.created_at,p.author_id,pr.handle,pr.display_name from posts p join profiles pr on pr.user_id=p.author_id
       where p.deleted_at is null and p.visibility='public' and p.search_document @@ websearch_to_tsquery('simple',$1)
         and not exists(select 1 from blocks b where (b.blocker_id=$2 and b.blocked_id=p.author_id) or (b.blocker_id=p.author_id and b.blocked_id=$2))
       order by ts_rank(p.search_document,websearch_to_tsquery('simple',$1)) desc,p.created_at desc limit 40`,[q,viewer]);
    return {query:q,people:people.rows,posts:posts.rows};
  });
}
