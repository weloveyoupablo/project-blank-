import { z } from 'zod';
import { db } from '../lib/db.js';
import { ApiError } from '../lib/errors.js';

const historySchema=z.object({
  kind:z.string().trim().min(1).max(60),
  objectType:z.string().trim().max(60).nullable().optional(),
  objectId:z.string().trim().max(240).nullable().optional(),
  label:z.string().trim().min(1).max(240),
  metadata:z.record(z.any()).optional().default({})
});

export async function registerHistory(app){
  app.get('/v1/me/history',{preHandler:[app.authenticate]},async req=>{
    const supplied=Number(req.query.limit??100);if(!Number.isInteger(supplied)||supplied<1)throw new ApiError(400,'INVALID_LIMIT','History limit must be a positive integer.');
    const limit=Math.min(supplied,200);
    const {rows}=await db.query(
      `select id,kind,object_type,object_id,label,metadata,created_at
       from user_history where user_id=$1 order by created_at desc limit $2`,
      [req.user.sub,limit]
    );
    return {items:rows};
  });

  app.post('/v1/me/history',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=historySchema.parse(req.body||{});
    const recent=await db.query(
      `select id from user_history where user_id=$1 and kind=$2
       and coalesce(object_id,'')=coalesce($3,'') and object_type is not distinct from $4 and label=$5 and created_at>now()-interval '30 seconds'
       order by created_at desc limit 1`,
      [req.user.sub,b.kind,b.objectId??null,b.objectType??null,b.label]
    );
    if(recent.rows[0]) return {id:recent.rows[0].id,deduped:true};
    const {rows}=await db.query(
      `insert into user_history(user_id,kind,object_type,object_id,label,metadata)
       values($1,$2,$3,$4,$5,$6::jsonb) returning id,created_at`,
      [req.user.sub,b.kind,b.objectType??null,b.objectId??null,b.label,JSON.stringify(b.metadata||{})]
    );
    reply.code(201).send(rows[0]);
  });

  app.delete('/v1/me/history',{preHandler:[app.authenticate]},async req=>{
    await db.query(`delete from user_history where user_id=$1`,[req.user.sub]);
    return {ok:true};
  });
}
