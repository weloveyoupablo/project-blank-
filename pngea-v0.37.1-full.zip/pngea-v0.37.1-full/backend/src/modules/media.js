import path from 'node:path';
import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { ApiError } from '../lib/errors.js';
import { audit } from '../lib/audit.js';
import { createUploadUrl, createDownloadUrl, deleteMediaObject, headMediaObject } from '../lib/object-storage.js';
import { publishToUsers } from '../lib/events.js';

const MAX_BYTES = 2 * 1024 * 1024 * 1024;
const uploadSchema=z.object({
  mimeType:z.string().max(120).optional(),
  byteSize:z.number().int().positive().max(MAX_BYTES),
  fileName:z.string().max(255).optional()
});
const completeSchema=z.object({ sha256:z.string().regex(/^[a-f0-9]{64}$/i).optional() });
const ALLOWED_PREFIXES=['image/','video/','audio/'];


const MIME_BY_EXT=new Map([
  ['.jpg','image/jpeg'],['.jpeg','image/jpeg'],['.png','image/png'],['.gif','image/gif'],['.webp','image/webp'],['.heic','image/heic'],['.heif','image/heif'],['.avif','image/avif'],
  ['.mp4','video/mp4'],['.m4v','video/x-m4v'],['.mov','video/quicktime'],['.webm','video/webm'],['.ogv','video/ogg'],
  ['.mp3','audio/mpeg'],['.m4a','audio/mp4'],['.aac','audio/aac'],['.wav','audio/wav'],['.ogg','audio/ogg'],['.oga','audio/ogg'],['.flac','audio/flac']
]);

function normalizeMimeType(value,fileName='') {
  const supplied=String(value||'').trim().toLowerCase();
  if (supplied && supplied!=='application/octet-stream') return supplied;
  return MIME_BY_EXT.get(path.extname(String(fileName||'')).toLowerCase()) || supplied;
}

function safeExt(name='') {
  const ext=path.extname(name).toLowerCase().replace(/[^.a-z0-9]/g,'');
  return ext.slice(0,12);
}

async function canAccessMedia(userId,mediaId) {
  const { rows }=await db.query(
    `select m.id,m.owner_user_id,m.object_key,m.mime_type,m.byte_size,m.width,m.height,m.duration_ms,m.status,
      exists(select 1 from message_media mm join messages msg on msg.id=mm.message_id
             join conversation_members cm on cm.conversation_id=msg.conversation_id
             where mm.media_id=m.id and cm.user_id=$2 and cm.left_at is null) as message_access,
      exists(select 1 from posts p where p.id=m.post_id and p.deleted_at is null and (
        p.author_id=$2 or p.visibility='public' or
        (p.visibility='followers' and exists(select 1 from follows f where f.follower_id=$2 and f.followee_id=p.author_id)) or
        (p.visibility='close_friends' and exists(select 1 from close_friends cf where cf.user_id=p.author_id and cf.friend_user_id=$2))
      )) as post_access
     from media m where m.id=$1`,[mediaId,userId]
  );
  const m=rows[0];
  if (!m) throw new ApiError(404,'MEDIA_NOT_FOUND','Media not found.');
  if (m.owner_user_id!==userId && !m.message_access && !m.post_access) throw new ApiError(403,'MEDIA_FORBIDDEN','You do not have access to this media.');
  return m;
}

export async function registerMedia(app) {
  app.post('/v1/media/uploads',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=uploadSchema.parse(req.body);
    const mimeType=normalizeMimeType(b.mimeType,b.fileName);
    if (!ALLOWED_PREFIXES.some(p=>mimeType.startsWith(p))) throw new ApiError(415,'MEDIA_TYPE_UNSUPPORTED','Only image, video, and audio uploads are supported.');
    const id=opaqueId('med');
    const date=new Date();
    const objectKey=`users/${req.user.sub}/${date.getUTCFullYear()}/${String(date.getUTCMonth()+1).padStart(2,'0')}/${id}/original${safeExt(b.fileName)}`;
    await db.query(
      `insert into media(id,owner_user_id,object_key,mime_type,byte_size,status,original_filename)
       values($1,$2,$3,$4,$5,'uploading',$6)`,
      [id,req.user.sub,objectKey,mimeType,b.byteSize,b.fileName||null]
    );
    const expiresIn=mimeType.startsWith('video/')?3600:1800;
    const uploadUrl=await createUploadUrl({objectKey,mimeType,expiresIn});
    await audit({actorUserId:req.user.sub,action:'media.upload.created',objectType:'media',objectId:id,metadata:{mimeType,byteSize:b.byteSize}});
    reply.code(201).send({ mediaId:id, uploadUrl, method:'PUT', headers:{'Content-Type':mimeType}, expiresIn });
  });

  app.post('/v1/media/:id/complete',{preHandler:[app.authenticate]},async (req)=>{
    const b=completeSchema.parse(req.body||{});
    const {rows}=await db.query(`select * from media where id=$1 and owner_user_id=$2`,[req.params.id,req.user.sub]);
    const media=rows[0];
    if (!media) throw new ApiError(404,'MEDIA_NOT_FOUND','Media not found.');
    if (!['uploading','pending','failed'].includes(media.status)) return {id:media.id,status:media.status};
    let head;
    try { head=await headMediaObject(media.object_key); }
    catch { throw new ApiError(409,'UPLOAD_NOT_FOUND','Uploaded object could not be verified.'); }
    if (Number(head.ContentLength||0)!==Number(media.byte_size)) throw new ApiError(409,'UPLOAD_SIZE_MISMATCH','Uploaded byte size does not match the declared size.');
    await tx(async c=>{
      await c.query(`update media set status='processing',sha256=coalesce($2,sha256),updated_at=now() where id=$1`,[media.id,b.sha256||null]);
      await c.query(`insert into media_jobs(media_id,kind,status) values($1,'inspect','queued')`,[media.id]);
    });
    await publishToUsers([req.user.sub],'media.processing',{mediaId:media.id});
    return {id:media.id,status:'processing'};
  });

  app.get('/v1/media/:id',{preHandler:[app.authenticate]},async req=>{
    const m=await canAccessMedia(req.user.sub,req.params.id);
    const variants=(await db.query(`select id,kind,mime_type,byte_size,width,height,bitrate from media_variants where media_id=$1 order by kind`,[m.id])).rows;
    return {...m,variants};
  });

  app.get('/v1/media/:id/access',{preHandler:[app.authenticate]},async req=>{
    const m=await canAccessMedia(req.user.sub,req.params.id);
    if (m.status!=='ready') throw new ApiError(409,'MEDIA_NOT_READY','Media is still processing.');
    const variant=String(req.query.variant||'original');
    const {rows}=await db.query(`select object_key,mime_type from media_variants where media_id=$1 and kind=$2`,[m.id,variant]);
    const chosen=rows[0]||{object_key:m.object_key,mime_type:m.mime_type};
    const expiresIn=String(chosen.mime_type||'').startsWith('video/')?3600:900;
    return { url:await createDownloadUrl({objectKey:chosen.object_key,expiresIn}), expiresIn, mimeType:chosen.mime_type };
  });

  app.delete('/v1/media/:id',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(`delete from media where id=$1 and owner_user_id=$2 returning object_key`,[req.params.id,req.user.sub]);
    if (!rows[0]) throw new ApiError(404,'MEDIA_NOT_FOUND','Media not found.');
    deleteMediaObject(rows[0].object_key).catch(()=>{});
    await audit({actorUserId:req.user.sub,action:'media.deleted',objectType:'media',objectId:req.params.id});
    return {ok:true};
  });
}
