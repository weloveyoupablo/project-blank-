import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { ApiError } from '../lib/errors.js';
import { publishGlobal, publishToUsers } from '../lib/events.js';

const communityCreate=z.object({name:z.string().trim().min(2).max(80),description:z.string().trim().max(300).default('')});
const communityPost=z.object({text:z.string().max(10000).default(''),mediaIds:z.array(z.string()).max(10).default([])}).refine(v=>v.text.trim()||v.mediaIds.length,'Post cannot be empty.');
const slugify=s=>String(s).toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,54)||'community';

const postFields=(viewerParam='$1')=>`
  p.id,p.author_id,p.text,p.visibility,p.reply_to_id,p.quote_post_id,p.created_at,p.edited_at,
  pr.handle,pr.display_name,pr.avatar_url,pr.avatar_media_id,
  exists(select 1 from post_reactions vr where vr.post_id=p.id and vr.user_id=${viewerParam} and vr.reaction='like') viewer_liked,
  exists(select 1 from reposts vrp where vrp.post_id=p.id and vrp.user_id=${viewerParam}) viewer_reposted,
  exists(select 1 from bookmarks bm where bm.post_id=p.id and bm.user_id=${viewerParam}) viewer_saved,
  (select count(*)::int from post_reactions r where r.post_id=p.id and r.reaction='like') likes,
  (select count(*)::int from reposts rp where rp.post_id=p.id) reposts,
  (select count(*)::int from posts rr where rr.reply_to_id=p.id and rr.deleted_at is null) replies,
  coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'mimeType',m.mime_type,'width',m.width,'height',m.height,'durationMs',m.duration_ms,'status',m.status,'edit',m.edit_json) order by m.created_at)
    from media m where m.post_id=p.id and m.status='ready'),'[]'::jsonb) media`;

function visibility(viewer=' $1') { return `(
  p.author_id=${viewer} or p.visibility='public' or
  (p.visibility='followers' and exists(select 1 from follows f where f.follower_id=${viewer} and f.followee_id=p.author_id)) or
  (p.visibility='close_friends' and exists(select 1 from close_friends cf where cf.user_id=p.author_id and cf.friend_user_id=${viewer}))
)`; }

export async function registerSocial(app){
  app.put('/v1/posts/:id/bookmark',{preHandler:[app.authenticate]},async req=>{
    const ok=await db.query(`select 1 from posts where id=$1 and deleted_at is null`,[req.params.id]);if(!ok.rowCount)throw new ApiError(404,'POST_NOT_FOUND','Post not found.');
    await db.query(`insert into bookmarks(user_id,post_id) values($1,$2) on conflict do nothing`,[req.user.sub,req.params.id]);return {saved:true};
  });
  app.delete('/v1/posts/:id/bookmark',{preHandler:[app.authenticate]},async req=>{await db.query(`delete from bookmarks where user_id=$1 and post_id=$2`,[req.user.sub,req.params.id]);return {saved:false}});

  app.get('/v1/me/library',{preHandler:[app.authenticate]},async req=>{
    const tab=String(req.query.tab||'saved');const allowed=new Set(['saved','videos','articles','likes']);if(!allowed.has(tab))throw new ApiError(400,'INVALID_TAB','Invalid library tab.');
    let where='',order='p.created_at desc';
    if(tab==='saved'){where=`exists(select 1 from bookmarks b where b.user_id=$1 and b.post_id=p.id)`;order=`(select b.created_at from bookmarks b where b.user_id=$1 and b.post_id=p.id) desc`}
    if(tab==='videos')where=`exists(select 1 from media mv where mv.post_id=p.id and mv.status='ready' and mv.mime_type like 'video/%')`;
    if(tab==='articles')where=`(p.text ~* 'https?://' or length(p.text)>800)`;
    if(tab==='likes'){where=`exists(select 1 from post_reactions lr where lr.user_id=$1 and lr.post_id=p.id and lr.reaction='like')`;order=`(select lr.created_at from post_reactions lr where lr.user_id=$1 and lr.post_id=p.id and lr.reaction='like') desc`}
    const {rows}=await db.query(`select ${postFields('$1')} from posts p join profiles pr on pr.user_id=p.author_id where p.deleted_at is null and ${where} and ${visibility('$1')} order by ${order} limit 200`,[req.user.sub]);
    return {tab,items:rows};
  });

  app.get('/v1/users/:handle/followers',{preHandler:[app.optionalAuth]},async req=>{
    const h=String(req.params.handle).toLowerCase(),viewer=req.user?.sub||null;
    const target=await db.query(`select user_id from profiles where handle=$1 union all select user_id from profile_handle_aliases where handle=$1 limit 1`,[h]);if(!target.rows[0])throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    const {rows}=await db.query(`select p.user_id id,p.handle,p.display_name,p.bio,p.avatar_url,p.avatar_media_id,case when $2::text is null then false else exists(select 1 from follows vf where vf.follower_id=$2 and vf.followee_id=p.user_id) end viewer_following from follows f join profiles p on p.user_id=f.follower_id where f.followee_id=$1 order by f.created_at desc limit 500`,[target.rows[0].user_id,viewer]);return {items:rows};
  });
  app.get('/v1/users/:handle/following',{preHandler:[app.optionalAuth]},async req=>{
    const h=String(req.params.handle).toLowerCase(),viewer=req.user?.sub||null;
    const target=await db.query(`select user_id from profiles where handle=$1 union all select user_id from profile_handle_aliases where handle=$1 limit 1`,[h]);if(!target.rows[0])throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    const {rows}=await db.query(`select p.user_id id,p.handle,p.display_name,p.bio,p.avatar_url,p.avatar_media_id,case when $2::text is null then false else exists(select 1 from follows vf where vf.follower_id=$2 and vf.followee_id=p.user_id) end viewer_following from follows f join profiles p on p.user_id=f.followee_id where f.follower_id=$1 order by f.created_at desc limit 500`,[target.rows[0].user_id,viewer]);return {items:rows};
  });

  app.get('/v1/me/close-friends',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(`select p.user_id id,p.handle,p.display_name,p.bio,p.avatar_url,p.avatar_media_id,cf.created_at from close_friends cf join profiles p on p.user_id=cf.friend_user_id where cf.user_id=$1 order by cf.created_at desc`,[req.user.sub]);return {items:rows};
  });
  app.put('/v1/me/close-friends/:userId',{preHandler:[app.authenticate]},async req=>{
    if(req.params.userId===req.user.sub)throw new ApiError(400,'SELF_CLOSE_FRIEND','You cannot add yourself.');
    const ok=await db.query(`select 1 from users where id=$1 and status='active'`,[req.params.userId]);if(!ok.rowCount)throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    await db.query(`insert into close_friends(user_id,friend_user_id) values($1,$2) on conflict do nothing`,[req.user.sub,req.params.userId]);return {closeFriend:true};
  });
  app.delete('/v1/me/close-friends/:userId',{preHandler:[app.authenticate]},async req=>{await db.query(`delete from close_friends where user_id=$1 and friend_user_id=$2`,[req.user.sub,req.params.userId]);return {closeFriend:false}});
  app.get('/v1/feed/close-friends',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(`
      with activity as (
        select p.id, p.created_at activity_at, cf.friend_user_id activity_user_id, false is_repost
        from close_friends cf join posts p on p.author_id=cf.friend_user_id
        where cf.user_id=$1 and p.deleted_at is null
        union all
        select rp.post_id id, rp.created_at activity_at, cf.friend_user_id activity_user_id, true is_repost
        from close_friends cf join reposts rp on rp.user_id=cf.friend_user_id
        where cf.user_id=$1
      )
      select ${postFields('$1')},a.activity_at,a.is_repost,rep.handle reposted_by_handle,rep.display_name reposted_by_display_name
      from activity a join posts p on p.id=a.id join profiles pr on pr.user_id=p.author_id join profiles rep on rep.user_id=a.activity_user_id
      where p.deleted_at is null and ${visibility('$1')}
      order by a.activity_at desc limit 150`,[req.user.sub]);
    return {items:rows};
  });

  app.get('/v1/communities',{preHandler:[app.authenticate]},async req=>{
    const scope=String(req.query.scope||'home'),q=String(req.query.q||'').trim();
    const params=[req.user.sub,`%${q}%`];
    const memberClause=scope==='discover'?'':'and exists(select 1 from community_members mine where mine.community_id=c.id and mine.user_id=$1)';
    const {rows}=await db.query(`select c.*,count(cm.user_id)::int members,exists(select 1 from community_members mine where mine.community_id=c.id and mine.user_id=$1) viewer_member from communities c left join community_members cm on cm.community_id=c.id where ($2='%%' or c.name ilike $2 or c.description ilike $2) ${memberClause} group by c.id order by c.updated_at desc limit 100`,params);
    return {items:rows};
  });
  app.post('/v1/communities',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=communityCreate.parse(req.body||{}),id=opaqueId('com');let slug=slugify(b.name);for(let i=0;i<5;i++){const x=await db.query(`select 1 from communities where slug=$1`,[slug]);if(!x.rowCount)break;slug=`${slugify(b.name)}-${Math.random().toString(36).slice(2,6)}`}
    await tx(async c=>{await c.query(`insert into communities(id,slug,name,description,owner_user_id) values($1,$2,$3,$4,$5)`,[id,slug,b.name,b.description,req.user.sub]);await c.query(`insert into community_members(community_id,user_id,role) values($1,$2,'owner')`,[id,req.user.sub])});
    reply.code(201).send({id,slug});
  });
  app.put('/v1/communities/:id/join',{preHandler:[app.authenticate]},async req=>{const ok=await db.query(`select 1 from communities where id=$1`,[req.params.id]);if(!ok.rowCount)throw new ApiError(404,'COMMUNITY_NOT_FOUND','Community not found.');await db.query(`insert into community_members(community_id,user_id) values($1,$2) on conflict do nothing`,[req.params.id,req.user.sub]);return {member:true}});
  app.delete('/v1/communities/:id/join',{preHandler:[app.authenticate]},async req=>{const own=await db.query(`select 1 from communities where id=$1 and owner_user_id=$2`,[req.params.id,req.user.sub]);if(own.rowCount)throw new ApiError(409,'OWNER_CANNOT_LEAVE','Transfer ownership before leaving.');await db.query(`delete from community_members where community_id=$1 and user_id=$2`,[req.params.id,req.user.sub]);return {member:false}});
  app.get('/v1/communities/:id/feed',{preHandler:[app.authenticate]},async req=>{
    const member=await db.query(`select 1 from community_members where community_id=$1 and user_id=$2`,[req.params.id,req.user.sub]);if(!member.rowCount)throw new ApiError(403,'COMMUNITY_MEMBERS_ONLY','Join this community to view its timeline.');
    const {rows}=await db.query(`select ${postFields('$1')} from community_posts cp join posts p on p.id=cp.post_id join profiles pr on pr.user_id=p.author_id where cp.community_id=$2 and p.deleted_at is null order by cp.created_at desc limit 150`,[req.user.sub,req.params.id]);return {items:rows};
  });
  app.post('/v1/communities/:id/posts',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=communityPost.parse(req.body||{}),member=await db.query(`select 1 from community_members where community_id=$1 and user_id=$2`,[req.params.id,req.user.sub]);if(!member.rowCount)throw new ApiError(403,'COMMUNITY_MEMBERS_ONLY','Join this community to post.');
    const id=opaqueId('pst');await tx(async c=>{await c.query(`insert into posts(id,author_id,text,visibility) values($1,$2,$3,'public')`,[id,req.user.sub,b.text]);if(b.mediaIds.length){const attached=await c.query(`update media set post_id=$1,updated_at=now() where owner_user_id=$2 and id=any($3::text[]) and status='ready' and post_id is null returning id`,[id,req.user.sub,b.mediaIds]);if(attached.rowCount!==b.mediaIds.length)throw new ApiError(409,'MEDIA_NOT_READY','One or more media objects are unavailable.')}await c.query(`insert into community_posts(community_id,post_id) values($1,$2)`,[req.params.id,id]);await c.query(`update communities set updated_at=now() where id=$1`,[req.params.id])});
    await publishGlobal('post.created',{postId:id,authorId:req.user.sub,communityId:req.params.id});reply.code(201).send({id});
  });
}
