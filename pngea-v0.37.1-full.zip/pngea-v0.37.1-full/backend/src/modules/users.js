import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { ApiError } from '../lib/errors.js';
import { audit } from '../lib/audit.js';
import { notify } from '../lib/notify.js';
import { publishToUsers } from '../lib/events.js';

const websiteField=z.string().trim().transform(value=>{
  if(!value)return '';
  const candidate=/^[a-z][a-z\d+.-]*:/i.test(value)?value:`https://${value}`;
  try{return new URL(candidate).href}catch{return candidate}
}).refine(value=>{
  if(!value)return true;
  try{const url=new URL(value);return value.length<=2048&&['http:','https:'].includes(url.protocol)&&!!url.hostname&&!url.username&&!url.password}catch{return false}
},'Use a valid HTTP or HTTPS website link.');
const updateProfile=z.object({handle:z.string().trim().regex(/^[A-Za-z0-9_]{3,30}$/).optional(),displayName:z.string().trim().min(1).max(80).optional(),bio:z.string().max(300).optional(),location:z.string().trim().max(120).optional(),website:websiteField.optional(),avatarUrl:z.string().url().nullable().optional(),bannerUrl:z.string().url().nullable().optional(),avatarMediaId:z.string().nullable().optional(),bannerMediaId:z.string().nullable().optional()});
const postNotificationPreference=z.object({mode:z.enum(['none','posts','posts_replies'])}).strict();

async function requireAvailableUser(target,viewer,{allowBlocked=false}={}) {
  const found=await db.query(`select 1 from users u where u.id=$1 and u.status='active' and u.deleted_at is null
    ${allowBlocked?'':`and not exists(select 1 from blocks b where (b.blocker_id=$2 and b.blocked_id=u.id) or (b.blocker_id=u.id and b.blocked_id=$2))`}`,
    allowBlocked?[target]:[target,viewer]);
  if(!found.rowCount) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
}

async function canonicalFollowState(actor,target,fallback){
  const {rows}=await db.query(`select u.id as "userId",
    (select count(*)::int from follows f where f.followee_id=u.id) followers,
    (select count(*)::int from follows f where f.follower_id=u.id) following,
    exists(select 1 from follows f where f.follower_id=$1 and f.followee_id=$2) viewer_following
    from users u where u.id=any($3::text[]) order by u.id`,[actor,target,[actor,target]]);
  return {following:rows[0]?.viewer_following??fallback,counts:rows.map(({viewer_following,...counts})=>counts)};
}

export async function registerUsers(app) {
  app.get('/v1/users/:handle',{preHandler:[app.optionalAuth]},async req=>{
    const {rows}=await db.query(
      `select p.user_id id,p.handle,p.display_name,p.bio,p.location,p.website,u.created_at,u.created_at joined_at,p.avatar_url,p.banner_url,p.avatar_media_id,p.banner_media_id,
       (select count(*)::int from posts po where po.author_id=p.user_id and po.deleted_at is null and po.reply_to_id is null and
         (po.visibility='public' or po.author_id=$2 or
          (po.visibility='followers' and exists(select 1 from follows f where f.follower_id=$2 and f.followee_id=po.author_id)) or
          (po.visibility='close_friends' and exists(select 1 from close_friends cf where cf.user_id=po.author_id and cf.friend_user_id=$2)))) posts_count,
       (select count(*)::int from follows where followee_id=p.user_id) followers,
       (select count(*)::int from follows where follower_id=p.user_id) following,
       exists(select 1 from follows f where f.follower_id=$2 and f.followee_id=p.user_id) viewer_following,
       exists(select 1 from follows f where f.follower_id=p.user_id and f.followee_id=$2) follows_viewer,
       exists(select 1 from user_mutes m where m.user_id=$2 and m.muted_user_id=p.user_id) viewer_muted,
       coalesce((select pn.mode from user_post_notifications pn where pn.user_id=$2 and pn.author_user_id=p.user_id),'none') viewer_post_notifications
       from profiles p join users u on u.id=p.user_id
       where u.status='active' and u.deleted_at is null
         and p.user_id=coalesce((select user_id from profiles where handle=$1),(select user_id from profile_handle_aliases where handle=$1 limit 1))
         and not exists(select 1 from blocks b where (b.blocker_id=$2 and b.blocked_id=p.user_id) or (b.blocker_id=p.user_id and b.blocked_id=$2))`,[String(req.params.handle).toLowerCase(),req.user?.sub||null]
    );
    if (!rows[0]) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    return rows[0];
  });

  app.patch('/v1/me/profile',{preHandler:[app.authenticate]},async req=>{
    const b=updateProfile.parse(req.body);
    if('avatarMediaId' in b&&!('avatarUrl' in b))b.avatarUrl=null;else if('avatarUrl' in b&&!('avatarMediaId' in b))b.avatarMediaId=null;
    if('bannerMediaId' in b&&!('bannerUrl' in b))b.bannerUrl=null;else if('bannerUrl' in b&&!('bannerMediaId' in b))b.bannerMediaId=null;
    const handle=b.handle?.toLowerCase()??null;
    for(const [field,id] of [['avatarMediaId',b.avatarMediaId],['bannerMediaId',b.bannerMediaId]]){
      if(field in b && id){
        const ok=await db.query(`select 1 from media where id=$1 and owner_user_id=$2 and status='ready' and mime_type like 'image/%'`,[id,req.user.sub]);
        if(!ok.rowCount) throw new ApiError(409,'MEDIA_NOT_READY','That profile image is unavailable or still processing.');
      }
    }
    const previous=(await db.query(`select handle from profiles where user_id=$1`,[req.user.sub])).rows[0]?.handle||null;
    if(handle && previous && handle!==previous){
      const aliasTaken=await db.query(`select 1 from profile_handle_aliases where handle=$1 and user_id<>$2`,[handle,req.user.sub]);
      if(aliasTaken.rowCount) throw new ApiError(409,'HANDLE_TAKEN','That username is already in use.');
    }
    let rows;
    try {
      ({rows}=await db.query(
        `update profiles set handle=coalesce($2,handle),display_name=coalesce($3,display_name),bio=coalesce($4,bio),
         avatar_url=case when $5::boolean then $6 else avatar_url end,banner_url=case when $7::boolean then $8 else banner_url end,
         avatar_media_id=case when $9::boolean then $10 else avatar_media_id end,
         banner_media_id=case when $11::boolean then $12 else banner_media_id end,
         location=coalesce($13,location),website=coalesce($14,website),updated_at=now()
         where user_id=$1 returning *`,
        [req.user.sub,handle,b.displayName??null,b.bio??null,'avatarUrl' in b,b.avatarUrl??null,'bannerUrl' in b,b.bannerUrl??null,
         'avatarMediaId' in b,b.avatarMediaId??null,'bannerMediaId' in b,b.bannerMediaId??null,b.location??null,b.website??null]
      ));
    } catch (e) {
      if (e.code==='23505') throw new ApiError(409,'HANDLE_TAKEN','That username is already in use.');
      throw e;
    }
    if (!rows[0]) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    if(handle && previous && handle!==previous){
      await db.query(`insert into profile_handle_aliases(handle,user_id) values($1,$2) on conflict(handle) do update set user_id=excluded.user_id`,[previous,req.user.sub]);
      await db.query(`delete from profile_handle_aliases where handle=$1 and user_id=$2`,[handle,req.user.sub]);
    }
    await audit({actorUserId:req.user.sub,action:'profile.updated',objectType:'user',objectId:req.user.sub,metadata:{handle:rows[0].handle}});
    await publishToUsers([req.user.sub],'profile.updated',{userId:req.user.sub,handle:rows[0].handle});
    return rows[0];
  });

  app.post('/v1/users/:userId/follow',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId);
    if(target===req.user.sub) throw new ApiError(400,'SELF_FOLLOW','You cannot follow yourself.');
    await requireAvailableUser(target,req.user.sub);
    const inserted=await db.query(`insert into follows(follower_id,followee_id) values($1,$2) on conflict do nothing returning followee_id`,[req.user.sub,target]);
    if(inserted.rowCount) await notify({userId:target,actorUserId:req.user.sub,kind:'follow',objectType:'user',objectId:req.user.sub});
    await audit({actorUserId:req.user.sub,action:'follow.created',objectType:'user',objectId:target});
    const state=await canonicalFollowState(req.user.sub,target,true);
    if(inserted.rowCount)await publishToUsers([req.user.sub,target],'social.updated',{actorUserId:req.user.sub,userId:target,...state});
    return state;
  });

  app.delete('/v1/users/:userId/follow',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId);
    await requireAvailableUser(target,req.user.sub);
    const removed=await db.query(`delete from follows where follower_id=$1 and followee_id=$2 returning followee_id`,[req.user.sub,target]);
    const state=await canonicalFollowState(req.user.sub,target,false);
    if(removed.rowCount)await publishToUsers([req.user.sub,target],'social.updated',{actorUserId:req.user.sub,userId:target,...state});
    return state;
  });

  app.put('/v1/users/:userId/mute',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId);
    if(target===req.user.sub) throw new ApiError(400,'SELF_MUTE','You cannot mute yourself.');
    await requireAvailableUser(target,req.user.sub);
    await db.query(`insert into user_mutes(user_id,muted_user_id) values($1,$2) on conflict do nothing`,[req.user.sub,target]);
    await publishToUsers([req.user.sub],'social.updated',{userId:target,muted:true});
    return {muted:true};
  });
  app.delete('/v1/users/:userId/mute',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId);
    await db.query(`delete from user_mutes where user_id=$1 and muted_user_id=$2`,[req.user.sub,target]);
    await publishToUsers([req.user.sub],'social.updated',{userId:target,muted:false});
    return {muted:false};
  });

  app.put('/v1/users/:userId/post-notifications',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId),{mode}=postNotificationPreference.parse(req.body||{});
    if(target===req.user.sub) throw new ApiError(400,'SELF_NOTIFICATIONS','Choose another account.');
    await requireAvailableUser(target,req.user.sub);
    if(mode==='none') await db.query(`delete from user_post_notifications where user_id=$1 and author_user_id=$2`,[req.user.sub,target]);
    else await db.query(`insert into user_post_notifications(user_id,author_user_id,mode) values($1,$2,$3)
      on conflict(user_id,author_user_id) do update set mode=excluded.mode,updated_at=now()`,[req.user.sub,target,mode]);
    return {mode};
  });

  app.put('/v1/users/:userId/block',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId);
    if(target===req.user.sub) throw new ApiError(400,'SELF_BLOCK','You cannot block yourself.');
    await requireAvailableUser(target,req.user.sub,{allowBlocked:true});
    await tx(async c=>{
      await c.query(`insert into blocks(blocker_id,blocked_id) values($1,$2) on conflict do nothing`,[req.user.sub,target]);
      await c.query(`delete from follows where (follower_id=$1 and followee_id=$2) or (follower_id=$2 and followee_id=$1)`,[req.user.sub,target]);
      await c.query(`delete from close_friends where (user_id=$1 and friend_user_id=$2) or (user_id=$2 and friend_user_id=$1)`,[req.user.sub,target]);
      await c.query(`delete from user_post_notifications where (user_id=$1 and author_user_id=$2) or (user_id=$2 and author_user_id=$1)`,[req.user.sub,target]);
      await c.query(`delete from notifications where (user_id=$1 and actor_user_id=$2) or (user_id=$2 and actor_user_id=$1)`,[req.user.sub,target]);
    });
    await publishToUsers([req.user.sub,target],'social.updated',{userId:target,actorUserId:req.user.sub,blocked:true});
    return {blocked:true};
  });
  app.delete('/v1/users/:userId/block',{preHandler:[app.authenticate]},async req=>{
    await db.query(`delete from blocks where blocker_id=$1 and blocked_id=$2`,[req.user.sub,String(req.params.userId)]);
    return {blocked:false};
  });
}
