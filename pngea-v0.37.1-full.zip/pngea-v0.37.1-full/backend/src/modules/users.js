import { z } from 'zod';
import { db } from '../lib/db.js';
import { ApiError } from '../lib/errors.js';
import { audit } from '../lib/audit.js';
import { notify } from '../lib/notify.js';
import { publishToUsers } from '../lib/events.js';

const updateProfile=z.object({handle:z.string().trim().regex(/^[A-Za-z0-9_]{3,30}$/).optional(),displayName:z.string().trim().min(1).max(80).optional(),bio:z.string().max(300).optional(),avatarUrl:z.string().url().nullable().optional(),bannerUrl:z.string().url().nullable().optional(),avatarMediaId:z.string().nullable().optional(),bannerMediaId:z.string().nullable().optional()});

export async function registerUsers(app) {
  app.get('/v1/users/:handle',{preHandler:[app.optionalAuth]},async req=>{
    const {rows}=await db.query(
      `select p.user_id id,p.handle,p.display_name,p.bio,p.avatar_url,p.banner_url,p.avatar_media_id,p.banner_media_id,
       (select count(*)::int from posts po where po.author_id=p.user_id and po.deleted_at is null and po.reply_to_id is null and
         (po.visibility='public' or po.author_id=$2 or
          (po.visibility='followers' and exists(select 1 from follows f where f.follower_id=$2 and f.followee_id=po.author_id)) or
          (po.visibility='close_friends' and exists(select 1 from close_friends cf where cf.user_id=po.author_id and cf.friend_user_id=$2)))) posts_count,
       (select count(*)::int from follows where followee_id=p.user_id) followers,
       (select count(*)::int from follows where follower_id=p.user_id) following,
       case when $2::text is null then false else exists(select 1 from follows f where f.follower_id=$2 and f.followee_id=p.user_id) end viewer_following
       from profiles p where p.user_id=coalesce((select user_id from profiles where handle=$1),(select user_id from profile_handle_aliases where handle=$1 limit 1))`,[String(req.params.handle).toLowerCase(),req.user?.sub||null]
    );
    if (!rows[0]) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    return rows[0];
  });

  app.patch('/v1/me/profile',{preHandler:[app.authenticate]},async req=>{
    const b=updateProfile.parse(req.body);
    if('avatarMediaId' in b&&!('avatarUrl' in b))b.avatarUrl=null;else if('avatarUrl' in b&&!('avatarMediaId' in b))b.avatarMediaId=null;
    if('bannerMediaId' in b&&!('bannerUrl' in b))b.bannerUrl=null;else if('bannerUrl' in b&&!('bannerMediaId' in b))b.bannerMediaId=null;
    const handle=b.handle?.toLowerCase()??null;
    for(const [field,id] of [['avatarMediaId',b.avatarMediaId],['bannerMediaId',b.bannerMediaId]]){
      if(field in b && id){
        const ok=await db.query(`select 1 from media where id=$1 and owner_user_id=$2 and status='ready' and mime_type like 'image/%'`,[id,req.user.sub]);
        if(!ok.rowCount) throw new ApiError(409,'MEDIA_NOT_READY','That profile image is unavailable or still processing.');
      }
    }
    const previous=(await db.query(`select handle from profiles where user_id=$1`,[req.user.sub])).rows[0]?.handle||null;
    if(handle && previous && handle!==previous){
      const aliasTaken=await db.query(`select 1 from profile_handle_aliases where handle=$1 and user_id<>$2`,[handle,req.user.sub]);
      if(aliasTaken.rowCount) throw new ApiError(409,'HANDLE_TAKEN','That username is already in use.');
    }
    let rows;
    try {
      ({rows}=await db.query(
        `update profiles set handle=coalesce($2,handle),display_name=coalesce($3,display_name),bio=coalesce($4,bio),
         avatar_url=case when $5::boolean then $6 else avatar_url end,banner_url=case when $7::boolean then $8 else banner_url end,
         avatar_media_id=case when $9::boolean then $10 else avatar_media_id end,
         banner_media_id=case when $11::boolean then $12 else banner_media_id end,updated_at=now()
         where user_id=$1 returning *`,
        [req.user.sub,handle,b.displayName??null,b.bio??null,'avatarUrl' in b,b.avatarUrl??null,'bannerUrl' in b,b.bannerUrl??null,
         'avatarMediaId' in b,b.avatarMediaId??null,'bannerMediaId' in b,b.bannerMediaId??null]
      ));
    } catch (e) {
      if (e.code==='23505') throw new ApiError(409,'HANDLE_TAKEN','That username is already in use.');
      throw e;
    }
    if (!rows[0]) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    if(handle && previous && handle!==previous){
      await db.query(`insert into profile_handle_aliases(handle,user_id) values($1,$2) on conflict(handle) do update set user_id=excluded.user_id`,[previous,req.user.sub]);
      await db.query(`delete from profile_handle_aliases where handle=$1 and user_id=$2`,[handle,req.user.sub]);
    }
    await audit({actorUserId:req.user.sub,action:'profile.updated',objectType:'user',objectId:req.user.sub,metadata:{handle:rows[0].handle}});
    await publishToUsers([req.user.sub],'profile.updated',{userId:req.user.sub,handle:rows[0].handle});
    return rows[0];
  });

  app.post('/v1/users/:userId/follow',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId);
    if(target===req.user.sub) throw new ApiError(400,'SELF_FOLLOW','You cannot follow yourself.');
    const exists=await db.query(`select 1 from users where id=$1 and status='active'`,[target]);
    if(!exists.rowCount) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    const inserted=await db.query(`insert into follows(follower_id,followee_id) values($1,$2) on conflict do nothing returning followee_id`,[req.user.sub,target]);
    if(inserted.rowCount) await notify({userId:target,actorUserId:req.user.sub,kind:'follow',objectType:'user',objectId:req.user.sub});
    await audit({actorUserId:req.user.sub,action:'follow.created',objectType:'user',objectId:target});
    return {following:true};
  });

  app.delete('/v1/users/:userId/follow',{preHandler:[app.authenticate]},async req=>{
    await db.query(`delete from follows where follower_id=$1 and followee_id=$2`,[req.user.sub,String(req.params.userId)]);
    return {following:false};
  });
}
