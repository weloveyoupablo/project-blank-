import { z } from 'zod';
import { db } from '../lib/db.js';
import { audit } from '../lib/audit.js';

const permissionsSchema=z.object({smart_memory:z.boolean().optional(),memory_training:z.boolean().optional(),commercial_sharing:z.boolean().optional(),personalization:z.boolean().optional()}).partial();
const settingsSchema=z.object({
  privateAccount:z.boolean().optional(),
  allowMessageRequests:z.boolean().optional(),
  showActivityStatus:z.boolean().optional(),
  feedOrder:z.enum(['recommended','latest','following']).optional(),
  reducedMotion:z.boolean().optional()
});

export async function registerSettings(app){
  app.get('/v1/me/settings',{preHandler:[app.authenticate]},async req=>{
    const settings=(await db.query(`select * from user_settings where user_id=$1`,[req.user.sub])).rows[0]||{};
    const permissions=(await db.query(`select permission_key,value,policy_version,updated_at from user_permissions where user_id=$1`,[req.user.sub])).rows;
    return {settings,permissions};
  });
  app.patch('/v1/me/settings',{preHandler:[app.authenticate]},async req=>{
    const b=settingsSchema.parse(req.body);
    const {rows}=await db.query(
      `update user_settings set
       private_account=coalesce($2,private_account),
       allow_message_requests=coalesce($3,allow_message_requests),
       show_activity_status=coalesce($4,show_activity_status),
       feed_order=coalesce($5,feed_order),
       reduced_motion=coalesce($6,reduced_motion),updated_at=now()
       where user_id=$1 returning *`,
      [req.user.sub,b.privateAccount??null,b.allowMessageRequests??null,b.showActivityStatus??null,b.feedOrder??null,b.reducedMotion??null]
    );
    await audit({actorUserId:req.user.sub,action:'settings.changed',objectType:'settings',objectId:req.user.sub,metadata:b});
    return rows[0];
  });
  app.patch('/v1/me/permissions',{preHandler:[app.authenticate]},async req=>{
    const body=permissionsSchema.parse(req.body);
    for(const [key,value] of Object.entries(body)){
      await db.query(`insert into user_permissions(user_id,permission_key,value,policy_version) values($1,$2,$3,'1')
        on conflict(user_id,permission_key) do update set value=excluded.value,policy_version=excluded.policy_version,updated_at=now()`,[req.user.sub,key,value]);
      await audit({actorUserId:req.user.sub,action:'permission.changed',objectType:'permission',objectId:key,metadata:{value}});
    }
    return {ok:true};
  });
}
