import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import jwt from '@fastify/jwt';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import websocket from '@fastify/websocket';
import { ZodError } from 'zod';
import { config } from './config.js';
import { db } from './lib/db.js';
import { ApiError } from './lib/errors.js';
import { ensureMediaBucket } from './lib/object-storage.js';
import { startEventBus, realtimeStats } from './lib/events.js';
import { registerAuth } from './modules/auth.js';
import { registerUsers } from './modules/users.js';
import { registerPosts } from './modules/posts.js';
import { registerFeed } from './modules/feed.js';
import { registerMessages } from './modules/messages.js';
import { registerNotifications } from './modules/notifications.js';
import { registerSearch } from './modules/search.js';
import { registerSettings } from './modules/settings.js';
import { registerMemory } from './modules/memory.js';
import { registerTasks } from './modules/tasks.js';
import { registerNow } from './modules/now.js';
import { registerModeration } from './modules/moderation.js';
import { registerMedia } from './modules/media.js';
import { registerRealtime } from './modules/realtime.js';
import { registerTicker } from './modules/ticker.js';
import { createWorkerSupervisor } from './lib/worker-supervisor.js';

const app = Fastify({ logger: true, trustProxy: true, bodyLimit: 2_000_000 });
const workerSupervisor = createWorkerSupervisor(app.log);
await app.register(cors, { origin: config.corsOrigin, credentials: true });
await app.register(helmet, { contentSecurityPolicy: false });
await app.register(cookie);
await app.register(rateLimit, { max: 300, timeWindow: '1 minute' });
await app.register(jwt, { secret: config.jwtSecret, sign: { expiresIn: config.accessTokenTtl } });
await app.register(websocket);

app.decorate('authenticate', async function(req){
  try { await req.jwtVerify(); } catch { throw new ApiError(401,'AUTH_REQUIRED','Authentication required.'); }
});
app.decorate('optionalAuth', async function(req){ try { await req.jwtVerify(); } catch {} });

await startEventBus(app.log);
try { await ensureMediaBucket(); app.log.info('PNGEA media bucket ready'); }
catch (error) { app.log.warn({ error },'Object storage unavailable; media routes will fail until storage is online'); }

app.get('/health', async () => {
  await db.query('select 1');
  return {
    ok:true,
    service:'pngea-api',
    instance:config.instanceId,
    realtime:realtimeStats(),
    workers:workerSupervisor.stats(),
    time:new Date().toISOString()
  };
});

await registerAuth(app);
await registerUsers(app);
await registerPosts(app);
await registerFeed(app);
await registerMessages(app);
await registerNotifications(app);
await registerSearch(app);
await registerSettings(app);
await registerMemory(app);
await registerTasks(app);
await registerNow(app);
await registerModeration(app);
await registerMedia(app);
await registerRealtime(app);
await registerTicker(app);

app.setErrorHandler((err, req, reply) => {
  if (err instanceof ZodError) return reply.code(400).send({ error:{ code:'VALIDATION_ERROR', message:'Invalid request.', details:err.flatten() } });
  if (err instanceof ApiError) return reply.code(err.statusCode).send({ error:{ code:err.code, message:err.message, details:err.details } });
  req.log.error(err);
  reply.code(500).send({ error:{ code:'INTERNAL_ERROR', message:'Something went wrong.' } });
});

app.addHook('onClose', async () => { await workerSupervisor.stop(); });

try {
  await app.listen({ port:config.port, host:'0.0.0.0' });
  if (config.embeddedWorkers) {
    workerSupervisor.start('media','../media-worker.js');
    if (process.env.ALPACA_API_KEY_ID && process.env.ALPACA_API_SECRET_KEY) {
      workerSupervisor.start('market-news','../market-news-worker.js');
    } else {
      app.log.info('PNGEA market/news worker waiting for Alpaca credentials');
    }
    app.log.info('PNGEA embedded workers enabled');
  } else {
    app.log.info('PNGEA embedded workers disabled');
  }
} catch (err) {
  app.log.error(err);
  process.exit(1);
}

