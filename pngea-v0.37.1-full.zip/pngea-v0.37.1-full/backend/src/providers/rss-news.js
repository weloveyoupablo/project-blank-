import crypto from 'node:crypto';
import { db } from '../lib/db.js';
import { config } from '../config.js';
import { publishGlobal } from '../lib/events.js';
import { estimateImportance,inferTopics,sourceTrustFor } from '../lib/ticker-ranker.js';

const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const decodeXml=s=>String(s||'')
  .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1')
  .replace(/&quot;/g,'"').replace(/&#34;/g,'"').replace(/&apos;/g,"'")
  .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
  .replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
const tag=(xml,name)=>{
  const m=String(xml).match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`,'i'));
  return m?decodeXml(m[1]):'';
};
const normalized=s=>String(s).toLowerCase().replace(/https?:\/\/\S+/g,' ').replace(/[^a-z0-9\s]/g,' ').replace(/\b(update|breaking|exclusive|live)\b/g,' ').replace(/\s+/g,' ').trim();
const storyKey=s=>crypto.createHash('sha1').update(normalized(s)).digest('hex');
const itemId=(source,guid,link,headline)=>crypto.createHash('sha1').update(`${source}|${guid||link||headline}`).digest('hex');
function feeds(){
  return String(config.newsRssFeeds||'').split(';').map(x=>x.trim()).filter(Boolean).map(entry=>{
    const i=entry.indexOf('|');return i<0?null:{name:entry.slice(0,i).trim(),url:entry.slice(i+1).trim()};
  }).filter(x=>x?.name&&/^https:\/\//i.test(x.url));
}
async function ingestFeed(feed){
  const res=await fetch(feed.url,{headers:{'User-Agent':'PNGEA/0.51.3 (+news ticker)'}});
  if(!res.ok)throw new Error(`${feed.name} RSS ${res.status}`);
  const xml=await res.text(),items=[...xml.matchAll(/<item(?:\s[^>]*)?>([\s\S]*?)<\/item>/gi)].slice(0,40);
  let accepted=0;
  for(const [,chunk] of items){
    const headline=tag(chunk,'title'),link=tag(chunk,'link'),guid=tag(chunk,'guid'),summary=tag(chunk,'description');
    if(!headline)continue;
    const rawDate=tag(chunk,'pubDate')||tag(chunk,'dc:date')||tag(chunk,'date');
    const d=new Date(rawDate||Date.now());if(!Number.isFinite(d.getTime()))continue;
    if(Date.now()-d.getTime()>24*60*60*1000)continue;
    const provider=`rss:${feed.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`,providerItemId=itemId(feed.name,guid,link,headline);
    const key=storyKey(headline),topics=inferTopics(headline,summary),importance=estimateImportance(headline);
    await db.query(`insert into external_news_articles(id,provider,provider_item_id,source_name,headline,summary,url,author,symbols,topics,story_key,importance,verification_status,source_weight,status,published_at,updated_at,raw)
      values($1,$2,$3,$4,$5,$6,$7,null,'{}'::text[],$8,$9,$10,'single_source',$11,'active',$12,null,$13::jsonb)
      on conflict(provider,provider_item_id) do update set headline=excluded.headline,summary=excluded.summary,url=excluded.url,topics=excluded.topics,importance=excluded.importance,source_weight=excluded.source_weight,status='active',updated_at=now(),raw=excluded.raw`,
      [`rss_${providerItemId}`,provider,providerItemId,feed.name,headline,summary,link||null,topics,key,importance,sourceTrustFor(feed.name),d.toISOString(),JSON.stringify({feed:feed.url,guid})]);
    accepted++;
  }
  if(accepted)await publishGlobal('ticker.updated',{source:feed.name,at:new Date().toISOString()}).catch(()=>{});
  return accepted;
}
export async function pollRssFeeds(){
  for(const feed of feeds()){
    try{const n=await ingestFeed(feed);console.log(`[rss-news] ${feed.name}: ${n} items`)}
    catch(err){console.error(`[rss-news] ${feed.name}:`,err.message)}
  }
}
export async function startRssNewsPolling(){
  await pollRssFeeds();
  for(;;){await sleep(5*60_000);await pollRssFeeds()}
}
