import crypto from 'node:crypto';
import { db } from '../lib/db.js';
import { config } from '../config.js';
import { publishGlobal } from '../lib/events.js';
import { estimateImportance,inferTopics,sourceTrustFor } from '../lib/ticker-ranker.js';
import { configuredNewsFeeds,publisherMatches,approvedArticleUrl } from '../lib/news-sources.js';

const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const decodeXml=s=>String(s||'')
  .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1')
  .replace(/&quot;/g,'"').replace(/&#34;/g,'"').replace(/&apos;/g,"'")
  .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
  .replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
const tag=(xml,name)=>{
  const m=String(xml).match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`,'i'));
  return m?decodeXml(m[1]):'';
};
const normalized=s=>String(s).toLowerCase().replace(/https?:\/\/\S+/g,' ').replace(/[^a-z0-9\s]/g,' ').replace(/\b(update|breaking|exclusive|live)\b/g,' ').replace(/\s+/g,' ').trim();
const storyKey=s=>crypto.createHash('sha1').update(normalized(s)).digest('hex');
const itemId=(source,guid,link,headline)=>crypto.createHash('sha1').update(`${source}|${guid||link||headline}`).digest('hex');
const resolvedLinks=new Map();
export async function resolveArticleUrl(link,feed,fetcher=fetch){
  const direct=approvedArticleUrl(link,feed);if(direct)return direct;
  let url;try{url=new URL(link);if(url.protocol!=='https:'||url.hostname!=='news.google.com'||!/^\/(?:rss\/)?articles\//.test(url.pathname))return null}catch{return null}
  const key=`${feed.name}:${url.href}`,cached=resolvedLinks.get(key);if(cached&&cached.until>Date.now())return cached.url;
  const id=url.pathname.split('/').pop();let result=null;
  try{
    const embedded=Buffer.from(id,'base64url').toString('utf8').match(/https?:\/\/[^\s\x00-\x20"'<>\uFFFD]+/g)||[];
    result=embedded.map(value=>approvedArticleUrl(value,feed)).find(Boolean)||null;
    if(!result){
      const response=await fetcher(url.href,{signal:AbortSignal.timeout(3500),redirect:'follow',headers:{'User-Agent':'PNGEA news links'}});
      result=approvedArticleUrl(response.url,feed);
      if(!result&&response.ok){
        const html=(await response.text()).slice(0,500000);
        const links=[...html.matchAll(/(?:href|data-n-au|content)=["'](https?:[^"']+)["']/gi)].map(match=>decodeXml(match[1]));
        result=links.map(value=>approvedArticleUrl(value,feed)).find(Boolean)||null;
        const signature=html.match(/data-n-a-sg=["']([^"']+)/)?.[1],timestamp=html.match(/data-n-a-ts=["'](\d+)/)?.[1];
        if(!result&&signature&&timestamp){
          const args=['garturlreq',[['X','X',['X','X'],null,null,1,1,'US:en',null,1,null,null,null,null,null,0,1],'X','X',1,[1,1,1],1,1,null,0,0,null,0],id,Number(timestamp),signature];
          const body=new URLSearchParams({'f.req':JSON.stringify([[['Fbv4je',JSON.stringify(args),null,'generic']]])});
          const decoded=await fetcher('https://news.google.com/_/DotsSplashUi/data/batchexecute?rpcids=Fbv4je',{method:'POST',body,signal:AbortSignal.timeout(3500)});
          const visit=value=>{if(!Array.isArray(value))return null;if(value[0]==='garturlres')return approvedArticleUrl(value[1],feed);for(const entry of value){let parsed=entry;if(typeof entry==='string'&&entry.startsWith('[')){try{parsed=JSON.parse(entry)}catch{}}const found=Array.isArray(parsed)?visit(parsed):null;if(found)return found}return null};
          if(decoded.ok)for(const line of (await decoded.text()).split('\n')){if(!line.startsWith('['))continue;try{result=visit(JSON.parse(line));if(result)break}catch{}}
        }
      }
    }
  }catch{}
  if(resolvedLinks.size>=1000)resolvedLinks.delete(resolvedLinks.keys().next().value);
  resolvedLinks.set(key,{url:result,until:Date.now()+(result?24*3600000:15*60000)});
  return result;
}
function feeds(){
  return configuredNewsFeeds(config.newsRssFeeds);
}
async function ingestFeed(feed){
  const res=await fetch(feed.url,{headers:{'User-Agent':'PNGEA (+news ticker)'},signal:AbortSignal.timeout(8000)});
  if(!res.ok)throw new Error(`${feed.name} RSS ${res.status}`);
  const xml=await res.text(),items=[...xml.matchAll(/<item(?:\s[^>]*)?>([\s\S]*?)<\/item>/gi)].slice(0,40);
  let accepted=0;const deadline=Date.now()+25000;
  for(const [,chunk] of items){
    if(accepted>=8||Date.now()>deadline)break;
    if(feed.aggregated){
      const publisher=chunk.match(/<source\b[^>]*\burl=["']([^"']+)["'][^>]*>([\s\S]*?)<\/source>/i);
      if(!publisher||!publisherMatches(feed,decodeXml(publisher[2]),decodeXml(publisher[1])))continue;
    }
    const headline=tag(chunk,'title'),link=tag(chunk,'link'),guid=tag(chunk,'guid'),summary=tag(chunk,'description');
    if(!headline)continue;
    const rawDate=tag(chunk,'pubDate')||tag(chunk,'dc:date')||tag(chunk,'date');
    if(!rawDate)continue;
    const d=new Date(rawDate);if(!Number.isFinite(d.getTime()))continue;
    if(Date.now()-d.getTime()>24*60*60*1000||d.getTime()-Date.now()>5*60_000)continue;
    const articleUrl=await resolveArticleUrl(link,feed);if(!articleUrl)continue;
    const provider=`rss:${feed.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`,providerItemId=itemId(feed.name,guid,link,headline);
    const key=storyKey(headline),topics=[...new Set([...inferTopics(headline,summary),...(feed.sports?['sports']:[])])],importance=estimateImportance(headline);
    await db.query(`insert into external_news_articles(id,provider,provider_item_id,source_name,headline,summary,url,author,symbols,topics,story_key,importance,verification_status,source_weight,status,published_at,updated_at,raw)
      values($1,$2,$3,$4,$5,$6,$7,null,'{}'::text[],$8,$9,$10,$14,$11,'active',$12,null,$13::jsonb)
      on conflict(provider,provider_item_id) do update set headline=excluded.headline,summary=excluded.summary,url=excluded.url,topics=excluded.topics,importance=excluded.importance,source_weight=excluded.source_weight,status='active',updated_at=now(),raw=excluded.raw`,
      [`rss_${providerItemId}`,provider,providerItemId,feed.name,headline,summary,articleUrl,topics,key,importance,sourceTrustFor(feed.name),d.toISOString(),JSON.stringify({feed:feed.url,guid}),feed.official?'official':'single_source']);
    await db.query(`update external_news_articles set verification_status='corroborated' where story_key=$1 and verification_status<>'official' and (select count(distinct source_name) from external_news_articles where story_key=$1 and published_at>now()-interval '24 hours')>1`,[key]);
    accepted++;
  }
  if(accepted)await publishGlobal('ticker.updated',{source:feed.name,at:new Date().toISOString()}).catch(()=>{});
  return accepted;
}
export async function pollRssFeeds(){
  const pending=feeds();let next=0;
  const worker=async()=>{while(next<pending.length){const feed=pending[next++];
    let accepted=0;
    try{accepted=await ingestFeed(feed);console.log(`[rss-news] ${feed.name}: ${accepted} items`)}
    catch(err){console.error(`[rss-news] ${feed.name}:`,err.message)}
    if(!accepted&&!feed.aggregated){
      try{const n=await ingestFeed({...feed,url:feed.fallbackUrl,aggregated:true});console.log(`[rss-news] ${feed.name} verified publisher feed: ${n} items`)}
      catch(err){console.error(`[rss-news] ${feed.name} publisher feed:`,err.message)}
    }
  }};await Promise.all([worker(),worker()]);
}
export async function startRssNewsPolling(){
  await pollRssFeeds();
  for(;;){await sleep(2*60*60_000);await pollRssFeeds()}
}
