import crypto from 'node:crypto';
import { db } from '../lib/db.js';
import { config } from '../config.js';
import { publishGlobal } from '../lib/events.js';
import { estimateImportance,inferTopics,sourceTrustFor } from '../lib/ticker-ranker.js';
import { configuredNewsFeeds,publisherMatches } from '../lib/news-sources.js';

const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const decodeXml=s=>String(s||'')
  .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1')
  .replace(/&quot;/g,'"').replace(/&#34;/g,'"').replace(/&apos;/g,"'")
  .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
  .replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
const tag=(xml,name)=>{
  const m=String(xml).match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`,'i'));
  return m?decodeXml(m[1]):'';
};
const normalized=s=>String(s).toLowerCase().replace(/https?:\/\/\S+/g,' ').replace(/[^a-z0-9\s]/g,' ').replace(/\b(update|breaking|exclusive|live)\b/g,' ').replace(/\s+/g,' ').trim();
const storyKey=s=>crypto.createHash('sha1').update(normalized(s)).digest('hex');
const itemId=(source,guid,link,headline)=>crypto.createHash('sha1').update(`${source}|${guid||link||headline}`).digest('hex');
function feeds(){
  return configuredNewsFeeds(config.newsRssFeeds);
}
async function ingestFeed(feed){
  const res=await fetch(feed.url,{headers:{'User-Agent':'PNGEA (+news ticker)'},signal:AbortSignal.timeout(8000)});
  if(!res.ok)throw new Error(`${feed.name} RSS ${res.status}`);
  const xml=await res.text(),items=[...xml.matchAll(/<item(?:\s[^>]*)?>([\s\S]*?)<\/item>/gi)].slice(0,40);
  let accepted=0;
  for(const [,chunk] of items){
    if(feed.aggregated){
      const publisher=chunk.match(/<source\b[^>]*\burl=["']([^"']+)["'][^>]*>([\s\S]*?)<\/source>/i);
      if(!publisher||!publisherMatches(feed,decodeXml(publisher[2]),decodeXml(publisher[1])))continue;
    }
    const headline=tag(chunk,'title'),link=tag(chunk,'link'),guid=tag(chunk,'guid'),summary=tag(chunk,'description');
    if(!headline)continue;
    const rawDate=tag(chunk,'pubDate')||tag(chunk,'dc:date')||tag(chunk,'date');
    if(!rawDate)continue;
    const d=new Date(rawDate);if(!Number.isFinite(d.getTime()))continue;
    if(Date.now()-d.getTime()>24*60*60*1000||d.getTime()-Date.now()>5*60_000)continue;
    const provider=`rss:${feed.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`,providerItemId=itemId(feed.name,guid,link,headline);
    const key=storyKey(headline),topics=inferTopics(headline,summary),importance=estimateImportance(headline);
    await db.query(`insert into external_news_articles(id,provider,provider_item_id,source_name,headline,summary,url,author,symbols,topics,story_key,importance,verification_status,source_weight,status,published_at,updated_at,raw)
      values($1,$2,$3,$4,$5,$6,$7,null,'{}'::text[],$8,$9,$10,'single_source',$11,'active',$12,null,$13::jsonb)
      on conflict(provider,provider_item_id) do update set headline=excluded.headline,summary=excluded.summary,url=excluded.url,topics=excluded.topics,importance=excluded.importance,source_weight=excluded.source_weight,status='active',updated_at=now(),raw=excluded.raw`,
      [`rss_${providerItemId}`,provider,providerItemId,feed.name,headline,summary,link||null,topics,key,importance,sourceTrustFor(feed.name),d.toISOString(),JSON.stringify({feed:feed.url,guid})]);
    await db.query(`update external_news_articles set verification_status='corroborated' where story_key=$1 and verification_status<>'official' and (select count(distinct source_name) from external_news_articles where story_key=$1 and published_at>now()-interval '24 hours')>1`,[key]);
    accepted++;
  }
  if(accepted)await publishGlobal('ticker.updated',{source:feed.name,at:new Date().toISOString()}).catch(()=>{});
  return accepted;
}
export async function pollRssFeeds(){
  for(const feed of feeds()){
    let accepted=0;
    try{accepted=await ingestFeed(feed);console.log(`[rss-news] ${feed.name}: ${accepted} items`)}
    catch(err){console.error(`[rss-news] ${feed.name}:`,err.message)}
    if(!accepted&&!feed.aggregated){
      try{const n=await ingestFeed({...feed,url:feed.fallbackUrl,aggregated:true});console.log(`[rss-news] ${feed.name} verified publisher feed: ${n} items`)}
      catch(err){console.error(`[rss-news] ${feed.name} publisher feed:`,err.message)}
    }
  }
}
export async function startRssNewsPolling(){
  await pollRssFeeds();
  for(;;){await sleep(2*60*60_000);await pollRssFeeds()}
}
