import { db } from '../lib/db.js';
import { publishGlobal } from '../lib/events.js';

export const SCOREBOARD_LEAGUES=[
  ['nfl','NFL','football/nfl'],['ncaaf','NCAA Football','football/college-football'],
  ['ncaam','NCAA Basketball','basketball/mens-college-basketball'],['ncaaw','NCAA Women’s Basketball','basketball/womens-college-basketball'],['nba','NBA','basketball/nba'],
  ['nhl','NHL','hockey/nhl'],['mlb','MLB','baseball/mlb']
].map(([id,name,path])=>({id,name,url:`https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard`}));

export function scoreboardItems(payload,league,now=Date.now()){
  const out=[];
  for(const event of (Array.isArray(payload?.events)?payload.events:[]).slice(0,100)){
    const competition=event.competitions?.[0],type=competition?.status?.type||event.status?.type||{};
    const scheduled=Date.parse(event.date),age=now-scheduled;
    if(!event.id||!Number.isFinite(scheduled)||age>24*3600000||age< -24*3600000)continue;
    if(/postpon|cancel|suspend/i.test(`${type.name||''} ${type.description||''}`))continue;
    const home=competition?.competitors?.find(x=>x.homeAway==='home'),away=competition?.competitors?.find(x=>x.homeAway==='away');
    const name=team=>String(team?.team?.abbreviation||team?.team?.shortDisplayName||'').trim().slice(0,50);
    if(!name(home)||!name(away))continue;
    const score=team=>/^\d{1,3}$/.test(String(team?.score??''))?Number(team.score):null;
    const state=type.completed?'final':type.state==='in'?'live':type.state==='pre'?'scheduled':null;
    if(!state||(state==='scheduled'&&age>2*3600000)||(state!=='scheduled'&&(score(home)===null||score(away)===null)))continue;
    const link=(event.links||[]).find(x=>{try{const u=new URL(x.href);return u.protocol==='https:'&&!u.username&&!u.password&&(u.hostname==='espn.com'||u.hostname.endsWith('.espn.com'))}catch{return false}})?.href;
    if(!link)continue;
    out.push({id:`espn:${league.id}:${String(event.id).slice(0,80)}`,league:league.name,homeTeam:name(home),awayTeam:name(away),
      homeScore:state==='scheduled'?null:score(home),awayScore:state==='scheduled'?null:score(away),state,
      statusText:String(type.shortDetail||type.detail||type.description||state).slice(0,100),scheduledAt:new Date(scheduled).toISOString(),
      observedAt:new Date(now).toISOString(),expiresAt:new Date(state==='live'?now+3*60000:Math.min(scheduled+24*3600000,now+2*3600000)).toISOString(),url:link});
  }
  return out;
}

export async function pollSportsScores(){
  let next=0,accepted=0;
  const worker=async()=>{while(next<SCOREBOARD_LEAGUES.length){const league=SCOREBOARD_LEAGUES[next++];try{
    const response=await fetch(league.url,{signal:AbortSignal.timeout(7000),headers:{'User-Agent':'PNGEA sports ticker'}});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    const serverDate=Date.parse(response.headers.get('date')||'');
    if(Number.isFinite(serverDate)&&Math.abs(Date.now()-serverDate)>3*60000)throw new Error('Stale scoreboard response');
    const items=scoreboardItems(await response.json(),league);
    for(const item of items){await db.query(`insert into sports_scores(id,league,home_team,away_team,home_score,away_score,state,status_text,scheduled_at,observed_at,expires_at,url,raw)
      values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb)
      on conflict(id) do update set home_team=excluded.home_team,away_team=excluded.away_team,home_score=excluded.home_score,away_score=excluded.away_score,
        state=excluded.state,status_text=excluded.status_text,scheduled_at=excluded.scheduled_at,observed_at=excluded.observed_at,expires_at=excluded.expires_at,url=excluded.url,raw=excluded.raw`,
      [item.id,item.league,item.homeTeam,item.awayTeam,item.homeScore,item.awayScore,item.state,item.statusText,item.scheduledAt,item.observedAt,item.expiresAt,item.url,JSON.stringify(item)]);accepted++;}
  }catch(error){console.error(`[sports-scores] ${league.name}: ${error.message}`)}}};
  await Promise.all([worker(),worker()]);
  await db.query(`delete from sports_scores where expires_at<now()-interval '2 days'`);
  if(accepted)await publishGlobal('ticker.updated',{source:'ESPN scores',at:new Date().toISOString()}).catch(()=>{});
  return accepted;
}
export async function startSportsScorePolling(){for(;;){await pollSportsScores();await new Promise(resolve=>setTimeout(resolve,60000))}}
