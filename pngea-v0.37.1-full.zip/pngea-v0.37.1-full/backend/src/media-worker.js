import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { db, tx } from './lib/db.js';
import { headMediaObject, createDownloadUrl } from './lib/object-storage.js';
import { opaqueId } from './lib/security.js';
import { publishToUsers, startEventBus } from './lib/events.js';

const sleep=ms=>new Promise(r=>setTimeout(r,ms));

// ffprobe is optional on the free native runtime. Client metadata provides the
// initial layout; when a probe is available, real file headers replace it.
export async function probeMedia(source) {
  try{
    const info=await new Promise((resolve,reject)=>execFile('ffprobe',['-v','error','-rw_timeout','15000000','-show_streams','-show_format','-of','json',source],{timeout:20_000,maxBuffer:256*1024},(error,stdout)=>{
      if(error)return reject(error);
      try{resolve(JSON.parse(stdout))}catch(error){reject(error)}
    }));
    const visual=info.streams?.find(s=>s.codec_type==='video'&&Number(s.width)>0&&Number(s.height)>0);
    let width=visual?Number(visual.width):null,height=visual?Number(visual.height):null;
    const rotation=Number(visual?.side_data_list?.find(s=>Number.isFinite(Number(s.rotation)))?.rotation??visual?.tags?.rotate??0);
    if(Math.abs(rotation)%180===90)[width,height]=[height,width];
    if(!(width>0&&width<=16384&&height>0&&height<=16384))width=height=null;
    const seconds=Number(info.format?.duration||info.streams?.find(s=>Number(s.duration)>0)?.duration);
    const durationMs=Number.isFinite(seconds)&&seconds>0&&seconds<=86400?Math.round(seconds*1000):null;
    return {width,height,durationMs};
  }catch{
    // An unavailable codec/tool must not strand a verified original forever.
    // Do not log signed storage URLs contained in external-tool error output.
    return null;
  }
}

export async function claimJob() {
  return tx(async c=>{
    const {rows}=await c.query(
      `select j.id,j.media_id,j.kind,j.attempts,m.owner_user_id,m.object_key,m.mime_type,m.byte_size,m.status media_status
       from media_jobs j join media m on m.id=j.media_id
       where (j.status='queued' and j.available_at<=now())
          or (j.status='running' and j.started_at<now()-interval '2 minutes')
       order by j.id for update of j skip locked limit 1`
    );
    const job=rows[0];
    if (!job) return null;
    if(Number(job.attempts)>=5){
      await c.query(`update media_jobs set status='failed',last_error='Media inspection lease expired after five attempts.',completed_at=now() where id=$1`,[job.id]);
      await c.query(`update media set status='failed',updated_at=now() where id=$1 and status not in('ready','blocked')`,[job.media_id]);
      return null;
    }
    await c.query(`update media_jobs set status='running',attempts=attempts+1,started_at=now() where id=$1`,[job.id]);
    return {...job,attempts:Number(job.attempts||0)+1};
  });
}

export async function processJob(job) {
  try {
    if (job.kind!=='inspect') throw new Error('Unsupported media processing job.');
    const head=await headMediaObject(job.object_key);
    if (Number(head.ContentLength||0)!==Number(job.byte_size)) throw new Error('Uploaded object size changed.');
    const metadata=await createDownloadUrl({objectKey:job.object_key,expiresIn:120}).then(probeMedia).catch(()=>null);
    let ready=false;
    await tx(async c=>{
      const media=(await c.query(`select status from media where id=$1 for update`,[job.media_id])).rows[0];
      if(!media||media.status==='blocked'){
        await c.query(`update media_jobs set status='completed',completed_at=now() where id=$1`,[job.id]);return;
      }
      await c.query(
        `insert into media_variants(id,media_id,kind,object_key,mime_type,byte_size,width,height)
         values($1,$2,'original',$3,$4,$5,$6,$7)
         on conflict(media_id,kind) do update set object_key=excluded.object_key,mime_type=excluded.mime_type,byte_size=excluded.byte_size,
           width=coalesce(excluded.width,media_variants.width),height=coalesce(excluded.height,media_variants.height)`,
        [opaqueId('var'),job.media_id,job.object_key,job.mime_type,job.byte_size,metadata?.width||null,metadata?.height||null]
      );
      await c.query(`update media set status='ready',width=coalesce($2,width),height=coalesce($3,height),duration_ms=coalesce($4,duration_ms),updated_at=now() where id=$1`,[job.media_id,metadata?.width||null,metadata?.height||null,metadata?.durationMs||null]);
      await c.query(`update media_jobs set status='completed',last_error=null,completed_at=now() where id=$1`,[job.id]);
      ready=true;
    });
    if(ready)await publishToUsers([job.owner_user_id],'media.ready',{mediaId:job.media_id,...metadata}).catch(()=>{});
  } catch (error) {
    const retry=job.attempts<5;
    await db.query(
      `update media_jobs set status=$2,last_error=$3,available_at=case when $2='queued' then now()+interval '15 seconds' else available_at end,
       completed_at=case when $2='failed' then now() else completed_at end where id=$1`,
      [job.id,retry?'queued':'failed',String(error.message||'Media inspection failed.').slice(0,1000)]
    );
    if (!retry) {
      const changed=await db.query(`update media set status='failed',updated_at=now() where id=$1 and status not in('ready','blocked') returning id`,[job.media_id]);
      if(changed.rowCount)await publishToUsers([job.owner_user_id],'media.failed',{mediaId:job.media_id}).catch(()=>{});
    }
  }
}

export async function runMediaWorker() {
  let stopping=false;
  process.once('SIGTERM',()=>{stopping=true});process.once('SIGINT',()=>{stopping=true});
  await startEventBus(console);
  console.log('PNGEA media worker online');
  while(!stopping){
    try{
      const job=await claimJob();
      if (!job) { await sleep(750); continue; }
      await processJob(job);
    }catch{
      console.error('PNGEA media queue unavailable; retrying.');
      await sleep(1500);
    }
  }
  await db.end();
}

if(process.argv[1]&&fileURLToPath(import.meta.url)===process.argv[1])await runMediaWorker();
