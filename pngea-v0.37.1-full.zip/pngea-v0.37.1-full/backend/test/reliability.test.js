import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Route unit tests isolate DB/event adapters. Real PostgreSQL integration remains
// a separate staging check. The schema stub is used only for valid test bodies.
const schema = new Proxy({}, {get:(_,key)=>key==='parse'?body=>body:()=>schema});
const z = new Proxy({}, {get:()=>()=>schema});
class ApiError extends Error {constructor(statusCode,code,message){super(message);Object.assign(this,{statusCode,code})}}
const here=path.dirname(fileURLToPath(import.meta.url));
function routesFor(file,deps={}){
  const source=fs.readFileSync(path.resolve(here,'../src/modules',file),'utf8');
  const name=source.match(/export async function (\w+)/)[1];
  const routes=new Map();
  const app={authenticate(){},optionalAuth(){}};
  for(const method of ['get','post','put','delete','patch'])app[method]=(url,opts,handler)=>routes.set(`${method} ${url}`,handler);
  const context={z,ApiError,opaqueId:()=>`msg_${Math.random()}`,audit:async()=>{},notify:async()=>{},publishToUsers:async()=>{},publishGlobal:async()=>{},createDownloadUrl:async()=> 'https://media.test/image',...deps};
  const factory=new Function(...Object.keys(context),source.replace(/^import .*?;\n/gm,'').replace(/export /g,'')+`;return ${name};`);
  return Promise.resolve(factory(...Object.values(context))(app)).then(()=>routes);
}
function reply(){return {status:200,body:null,code(n){this.status=n;return this},send(b){this.body=b;return this}}}

test('concurrent mobile retries return one message and publish once',async()=>{
  const messages=new Map(),events=[];
  const query=async(sql,args)=>{
    if(sql.includes('select id from messages')){const m=messages.get(args.slice(0,3).join(':'));return {rows:m?[{id:m.id}]:[]}}
    if(sql.includes('insert into messages')){
      const key=args.slice(1,3).concat(args[4]).join(':');
      if(messages.has(key)){if(!sql.includes('on conflict'))throw Object.assign(new Error('duplicate key'),{code:'23505'});return {rows:[],rowCount:0}}
      messages.set(key,{id:args[0]});return {rows:[{id:args[0]}],rowCount:1};
    }
    return {rows:[{user_id:'usr_other'}],rowCount:1};
  };
  const routes=await routesFor('messages.js',{db:{query},tx:fn=>fn({query}),publishToUsers:async(...args)=>events.push(args)});
  const request={user:{sub:'usr_self'},params:{id:'cnv_a'},body:{text:'Mobile retry',mediaIds:[],clientId:'stable_client_id'}};
  const a=reply(),b=reply();await Promise.all([routes.get('post /v1/conversations/:id/messages')(request,a),routes.get('post /v1/conversations/:id/messages')(request,b)]);
  assert.equal(messages.size,1);assert.equal(a.body.id,b.body.id);assert.deepEqual([a.status,b.status].sort(),[200,201]);assert.equal(events.filter(e=>e[1]==='message.created').length,1);
});

test('long conversation initially returns latest messages in chronological order',async()=>{
  const all=Array.from({length:700},(_,i)=>({id:`msg_${String(i).padStart(4,'0')}`,created_at:new Date(1700000000000+i*1000).toISOString()}));
  const query=async sql=>({rowCount:1,rows:sql.includes('select m.*')?(sql.includes('order by created_at desc')?all.slice(-501):all.slice(0,500)):[{}]});
  const routes=await routesFor('messages.js',{db:{query}});
  const result=await routes.get('get /v1/conversations/:id/messages')({user:{sub:'usr_self'},params:{id:'cnv_a'},query:{limit:500}});
  assert.equal(result.items.length,500);assert.equal(result.items.at(-1).id,'msg_0699');assert.ok(result.nextCursor);
});

test('other users can access ready media referenced by a public profile',async()=>{
  const query=async sql=>({rows:sql.includes('from media m where')?[{id:'med_avatar',owner_user_id:'usr_other',object_key:'image',mime_type:'image/png',status:'ready',message_access:false,post_access:false,profile_access:sql.includes('as profile_access')}]:[]});
  const routes=await routesFor('media.js',{db:{query}});
  const result=await routes.get('get /v1/media/:id/access')({user:{sub:'usr_self'},params:{id:'med_avatar'},query:{}});
  assert.equal(result.url,'https://media.test/image');
});

test('reaction creation respects canonical post visibility',async()=>{
  let inserted=false;
  const query=async sql=>{if(sql.includes('insert into post_reactions'))inserted=true;return {rows:sql.includes('select author_id')?[{author_id:'usr_other'}]:[],rowCount:1}};
  const routes=await routesFor('posts.js',{db:{query}});
  await assert.rejects(()=>routes.get('put /v1/posts/:id/like')({user:{sub:'usr_self'},params:{id:'private_post'}}),e=>e.statusCode===404);
  assert.equal(inserted,false);
});

test('invalid History limit is rejected before querying',async()=>{
  let queried=false;
  const routes=await routesFor('history.js',{db:{query:async()=>{queried=true;return {rows:[]}}}});
  await assert.rejects(()=>routes.get('get /v1/me/history')({user:{sub:'usr_self'},query:{limit:'not-a-number'}}),e=>e.statusCode===400);
  assert.equal(queried,false);
});

test('Fastify rate limits preserve HTTP 429 for clients',()=>{
  const source=fs.readFileSync(path.resolve(here,'../src/server.js'),'utf8');
  const body=source.split('app.setErrorHandler((err, req, reply) => {')[1].split('\n});')[0];
  const response=reply();
  new Function('ZodError','ApiError','err','req','reply',body)(class extends Error{},ApiError,Object.assign(new Error('Rate limit exceeded'),{statusCode:429}),{log:{error(){}}},response);
  assert.equal(response.status,429);assert.equal(response.body.error.code,'RATE_LIMITED');
});

test('unchanged read boundary does not publish a receipt',async()=>{
  let published=0;
  const routes=await routesFor('messages.js',{db:{query:async sql=>({rowCount:1,rows:sql.includes('update conversation_members')?[]:[{}]})},publishToUsers:async()=>{published++}});
  const result=await routes.get('post /v1/conversations/:id/read')({user:{sub:'usr_self'},params:{id:'cnv_a'},body:{messageId:'msg_seen'}});
  assert.equal(result.ok,true);assert.equal(published,0);
});

test('initial thread defaults to a small recent page',async()=>{
  let limit;
  const routes=await routesFor('messages.js',{db:{query:async(sql,args)=>{if(sql.includes('select m.*'))limit=args[3];return {rowCount:1,rows:[]}}}});
  await routes.get('get /v1/conversations/:id/messages')({user:{sub:'usr_self'},params:{id:'cnv_a'},query:{}});
  assert.equal(limit,51);
});

test('home feed requires a follow relationship independently of public visibility',async()=>{
  let selection;
  const routes=await routesFor('feed.js',{db:{query:async(sql,args)=>{selection={sql,args};return {rows:[]}}}});
  await routes.get('get /v1/feed')({user:{sub:'usr_viewer'},query:{}});
  assert.match(selection.sql,/and exists\(select 1 from follows timeline_follow where timeline_follow.follower_id=\$1 and timeline_follow.followee_id=p.author_id\)/);
  assert.match(selection.sql,/bookmarks bm.*viewer_saved/);
  assert.match(selection.sql,/not exists\(select 1 from blocks/);
  assert.equal(selection.args[0],'usr_viewer');
});

test('post mentions deduplicate handles and reply author notifications',async()=>{
  let resolved;
  const notifications=[];
  const query=async(sql,args)=>{
    if(sql.includes('select author_id from posts'))return {rows:[{author_id:'usr_parent'}]};
    if(sql.includes('from users u join profiles pr')){resolved={sql,args};return {rows:[{id:'usr_parent'},{id:'usr_other'}]}}
    return {rows:[],rowCount:1};
  };
  const routes=await routesFor('posts.js',{db:{query},tx:fn=>fn({query}),notify:async payload=>notifications.push(payload)});
  const response=reply();
  await routes.get('post /v1/posts')({user:{sub:'usr_self'},body:{text:'@Other @OTHER @parent email@example.com',title:'',visibility:'followers',mediaIds:[],replyToId:'pst_parent'}},response);
  assert.deepEqual(resolved.args[0],['other','parent']);
  assert.deepEqual(resolved.args.slice(1),['usr_self','followers','pst_parent','usr_parent']);
  assert.match(resolved.sql,/u.status='active' and u.deleted_at is null/);
  assert.match(resolved.sql,/bl.blocker_id=u.id and bl.blocked_id=\$2/);
  assert.match(resolved.sql,/\$3='followers'.*f.follower_id=u.id/);
  assert.match(resolved.sql,/parent.visibility='followers'/);
  assert.deepEqual(notifications.map(n=>[n.userId,n.kind]),[['usr_parent','reply'],['usr_other','mention']]);
  assert.equal(response.status,201);
});

test('mention resolution is bounded and notification failure preserves saved post success',async()=>{
  let handles;
  const query=async(sql,args)=>{if(sql.includes('from users u join profiles pr')){handles=args[0];return {rows:[{id:'usr_other'}]}}return {rows:[],rowCount:1}};
  const routes=await routesFor('posts.js',{db:{query},tx:fn=>fn({query}),notify:async()=>{throw new Error('notification unavailable')}});
  const response=reply();
  await routes.get('post /v1/posts')({user:{sub:'usr_self'},body:{text:Array.from({length:40},(_,i)=>`@user_${i}`).join(' '),visibility:'public',mediaIds:[]}},response);
  assert.equal(handles.length,20);assert.equal(response.status,201);assert.ok(response.body.id);
});
