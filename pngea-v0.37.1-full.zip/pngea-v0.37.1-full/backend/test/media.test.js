import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {execFile} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const fixture=path.resolve(root,'../tests/fixtures/reel.mp4');
const mediaSource=fs.readFileSync(path.join(root,'src/modules/media.js'),'utf8');
const workerSource=fs.readFileSync(path.join(root,'src/media-worker.js'),'utf8').replace(/^if\(process\.argv.*$/m,'');
const strip=source=>source.replace(/^import .*?;\n/gm,'').replace(/export /g,'');
class ApiError extends Error{constructor(statusCode,code,message){super(message);Object.assign(this,{statusCode,code})}}
const reply=()=>({status:200,body:null,code(n){this.status=n;return this},send(body){this.body=body;return this}});
function worker(deps={}){const context={execFile,db:{},tx:()=>{},opaqueId:()=>'',headMediaObject:async()=>{},createDownloadUrl:async()=>'',publishToUsers:async()=>{},startEventBus:async()=>{},...deps};return new Function(...Object.keys(context),strip(workerSource)+';return {probeMedia,claimJob,processJob};')(...Object.values(context));}
async function routes(deps={}){
  const schema=new Proxy({}, {get:(_,key)=>key==='parse'?body=>body:()=>schema});const z=new Proxy({}, {get:()=>()=>schema});
  const context={z,path,ApiError,db:{query:async()=>({rows:[]})},tx:()=>{},opaqueId:()=>'',audit:async()=>{},headMediaObject:async()=>{},createUploadUrl:async()=>'',createDownloadUrl:async()=>'',deleteMediaObject:async()=>{},publishToUsers:async()=>{},...deps};
  const handlers=new Map(),app={authenticate(){}};for(const method of ['get','post','patch','delete'])app[method]=(url,opts,handler)=>handlers.set(`${method} ${url}`,handler);
  await new Function(...Object.keys(context),strip(mediaSource)+';return registerMedia;')(...Object.values(context))(app);return handlers;
}

test('real MP4 probe reads portrait dimensions and short-video duration',async()=>{
  assert.deepEqual(await worker().probeMedia(fixture),{width:180,height:320,durationMs:2000});
});

test('missing probe binary gracefully preserves client metadata fallback',async()=>{
  const probe=worker({execFile:(binary,args,options,callback)=>callback(Object.assign(new Error('unavailable'),{code:'ENOENT'}))});
  assert.equal(await probe.probeMedia(fixture),null);
});

test('upload completion rejects missing or mismatched objects before publishing ready',async()=>{
  let mutations=0;
  const db={query:async()=>({rows:[{id:'med_a',owner_user_id:'me',object_key:'file',byte_size:100,status:'uploading'}]})};
  const handlers=await routes({db,tx:async()=>{mutations++},headMediaObject:async()=>({ContentLength:50}),publishToUsers:async()=>{mutations++}});
  await assert.rejects(()=>handlers.get('post /v1/media/:id/complete')({user:{sub:'me'},params:{id:'med_a'},body:{}}),e=>e.code==='UPLOAD_SIZE_MISMATCH');
  assert.equal(mutations,0);
});

test('media authorization denies access when no visible profile, post, or accepted chat references it',async()=>{
  const handlers=await routes({db:{query:async()=>({rows:[{id:'med_a',owner_user_id:'other',status:'ready',profile_access:false,post_access:false,message_access:false}]})}});
  await assert.rejects(()=>handlers.get('get /v1/media/:id/access')({user:{sub:'me'},params:{id:'med_a'},query:{}}),e=>e.code==='MEDIA_FORBIDDEN');
});

test('upload, publish, probe, recovery, and media privacy in PostgreSQL',{skip:!process.env.PNGEA_TEST_MODULE_ROOT},async t=>{
  const deps=process.env.PNGEA_TEST_MODULE_ROOT;
  const {PGlite}=await import(`${deps}/@electric-sql/pglite/dist/index.js`);
  const {pgcrypto}=await import(`${deps}/@electric-sql/pglite/dist/contrib/pgcrypto.js`);
  const {z}=await import(`${deps}/zod/index.js`);
  const pg=new PGlite({extensions:{pgcrypto}}),objects=new Map(),events=[];let seq=0;
  const adapt=result=>({...result,rowCount:result.rows.length||result.affectedRows||0});
  const db={query:async(sql,args)=>adapt(await pg.query(sql,args))};
  const tx=fn=>pg.transaction(async c=>fn({query:async(sql,args)=>adapt(await c.query(sql,args))}));
  const server=http.createServer(async(req,res)=>{
    const key=decodeURI(new URL(req.url,'http://localhost').pathname.slice(1));
    if(req.method==='PUT'){
      const chunks=[];for await(const chunk of req)chunks.push(chunk);objects.set(key,Buffer.concat(chunks));res.writeHead(200);res.end();return;
    }
    const data=objects.get(key);if(!data){res.writeHead(404);res.end();return;}
    const match=/bytes=(\d+)-(\d*)/.exec(req.headers.range||'');
    const start=match?Number(match[1]):0,end=match&&match[2]?Math.min(Number(match[2]),data.length-1):data.length-1;
    res.writeHead(match?206:200,{'Content-Type':'video/mp4','Content-Length':end-start+1,'Accept-Ranges':'bytes',...(match?{'Content-Range':`bytes ${start}-${end}/${data.length}`}:{})});
    res.end(req.method==='HEAD'?undefined:data.subarray(start,end+1));
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base=`http://127.0.0.1:${server.address().port}`;
  const headMediaObject=async key=>{const response=await fetch(`${base}/${key}`,{method:'HEAD'});if(!response.ok)throw new Error('Object unavailable.');return {ContentLength:Number(response.headers.get('content-length'))}};
  const createDownloadUrl=async({objectKey})=>`${base}/${objectKey}`;
  const handlers=await routes({z,db,tx,headMediaObject,createDownloadUrl,createUploadUrl:createDownloadUrl,opaqueId:()=>`media_test_${++seq}`,publishToUsers:async(...args)=>events.push(args)});
  const processor=worker({db,tx,headMediaObject,createDownloadUrl,opaqueId:()=>`variant_test_${++seq}`,publishToUsers:async(...args)=>events.push(args)});
  const call=async(name,user,id,body)=>{const response=reply(),result=await handlers.get(name)({user:{sub:user},params:{id},body,query:{},log:{warn(){}}},response);return response.body||result};
  const upload=async name=>{
    const bytes=fs.readFileSync(fixture),slot=await call('post /v1/media/uploads','me',null,{mimeType:'application/octet-stream',fileName:name,byteSize:bytes.length});
    assert.equal(slot.headers['Content-Type'],'video/mp4');
    assert.equal((await fetch(slot.uploadUrl,{method:'PUT',body:bytes})).status,200);return slot.mediaId;
  };
  try{
    for(const file of fs.readdirSync(path.join(root,'sql')).filter(f=>f.endsWith('.sql')).sort())await pg.exec(fs.readFileSync(path.join(root,'sql',file),'utf8'));
    await pg.exec(`insert into users(id,email,password_hash) values('me','me@example.test','test'),('other','other@example.test','test');insert into profiles(user_id,handle,display_name) values('me','tester','Tester'),('other','other','Other');`);
    let mediaId;
    await t.test('verified video publishes immediately with no worker and complete retries queue once',async()=>{
      mediaId=await upload('video.mp4');
      const completed=await call('post /v1/media/:id/complete','me',mediaId,{width:999,height:999,durationMs:999});
      assert.equal(completed.status,'ready');
      await call('post /v1/media/:id/complete','me',mediaId,{});
      assert.equal((await db.query(`select count(*)::int n from media_jobs where media_id=$1`,[mediaId])).rows[0].n,1);
      assert.equal(events.filter(e=>e[1]==='media.ready').length,1);
      await pg.exec(`insert into posts(id,author_id,text,content_kind) values('video_post','me','Caption','gallery')`);
      assert.equal((await db.query(`update media set post_id='video_post' where id=$1 and status='ready' returning id`,[mediaId])).rowCount,1);
      assert.ok((await call('get /v1/media/:id/access','other',mediaId)).url);
    });
    await t.test('real probe replaces initial hints with trusted MP4 metadata',async()=>{
      const job=await processor.claimJob();assert.equal(job.media_id,mediaId);await processor.processJob(job);
      const media=await call('get /v1/media/:id','me',mediaId);
      assert.equal(media.width,180);assert.equal(media.height,320);assert.equal(media.duration_ms,2000);
      assert.equal((await db.query(`select status from media_jobs where media_id=$1`,[mediaId])).rows[0].status,'completed');
    });
    await t.test('jobs abandoned during a cold restart are reclaimed and completed',async()=>{
      const legacy=await upload('restart.mp4');
      await db.query(`update media set status='processing' where id=$1`,[legacy]);
      await db.query(`insert into media_jobs(media_id,kind,status,attempts,started_at) values($1,'inspect','running',1,now()-interval '3 minutes')`,[legacy]);
      const job=await processor.claimJob();assert.equal(job.media_id,legacy);assert.equal(job.attempts,2);
      await processor.processJob(job);assert.equal((await call('get /v1/media/:id','me',legacy)).status,'ready');
    });
    await t.test('missing probe capability does not hold an original in processing',async()=>{
      const id=await upload('no-probe.mp4');await call('post /v1/media/:id/complete','me',id,{width:180,height:320,durationMs:2000});
      const noProbe=worker({db,tx,headMediaObject,createDownloadUrl,opaqueId:()=>`variant_test_${++seq}`,execFile:(binary,args,options,callback)=>callback(new Error('No probe available.'))});
      await noProbe.processJob(await noProbe.claimJob());assert.equal((await call('get /v1/media/:id','me',id)).status,'ready');
    });
    await t.test('retries are bounded and terminal failures are visible',async()=>{
      const id=await upload('broken.mp4');await db.query(`update media set status='processing' where id=$1`,[id]);
      await db.query(`insert into media_jobs(media_id,kind,status,attempts) values($1,'inspect','queued',4)`,[id]);
      const job=await processor.claimJob();objects.delete(job.object_key);await processor.processJob(job);
      assert.equal((await call('get /v1/media/:id','me',id)).status,'failed');
      assert.equal((await db.query(`select status from media_jobs where media_id=$1`,[id])).rows[0].status,'failed');
      assert.equal(await processor.claimJob(),null);
    });
    await t.test('optional inspection failures preserve a ready published original',async()=>{
      await db.query(`insert into media_jobs(media_id,kind,status,attempts) values($1,'inspect','queued',4)`,[mediaId]);
      const unavailable=worker({db,tx,headMediaObject:async()=>{throw new Error('Temporary storage outage.')},createDownloadUrl});
      await unavailable.processJob(await unavailable.claimJob());
      assert.equal((await call('get /v1/media/:id','me',mediaId)).status,'ready');
      await db.query(`insert into media_jobs(media_id,kind,status,attempts,started_at) values($1,'inspect','running',5,now()-interval '3 minutes')`,[mediaId]);
      assert.equal(await processor.claimJob(),null);
      assert.equal((await call('get /v1/media/:id','me',mediaId)).status,'ready');
      assert.equal((await db.query(`select count(*)::int n from media_jobs where media_id=$1 and status='failed'`,[mediaId])).rows[0].n,2);
    });
    await t.test('chat attachments require accepted membership and respect reciprocal blocks',async()=>{
      const id=await upload('private.mp4');await call('post /v1/media/:id/complete','me',id,{});
      await pg.exec(`insert into conversations(id,created_by,direct_key,request_status) values('chat','me','me:other','pending');insert into conversation_members(conversation_id,user_id) values('chat','me'),('chat','other');insert into messages(id,conversation_id,sender_id,text) values('attachment','chat','me','');`);
      await db.query(`insert into message_media(message_id,media_id) values('attachment',$1)`,[id]);
      await assert.rejects(()=>call('get /v1/media/:id/access','other',id),e=>e.code==='MEDIA_FORBIDDEN');
      await pg.exec(`update conversations set request_status='accepted' where id='chat'`);
      assert.ok((await call('get /v1/media/:id/access','other',id)).url);
      await pg.exec(`insert into blocks(blocker_id,blocked_id) values('me','other')`);
      await pg.exec(`update conversation_members set left_at=now() where conversation_id='chat' and user_id='me'`);
      await assert.rejects(()=>call('get /v1/media/:id/access','other',id),e=>e.statusCode===404);
      await assert.rejects(()=>call('get /v1/media/:id/access','other',mediaId),e=>e.statusCode===404);
    });
  }finally{await new Promise(resolve=>server.close(resolve));await pg.close()}
});
