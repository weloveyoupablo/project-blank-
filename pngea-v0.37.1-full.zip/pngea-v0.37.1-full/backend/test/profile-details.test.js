import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const deps=process.env.PNGEA_TEST_MODULE_ROOT;
class ApiError extends Error {constructor(statusCode,code,message){super(message);Object.assign(this,{statusCode,code})}}

test('profile details, follow snapshots and Unicode post limits in PostgreSQL',{skip:!deps},async t=>{
  const {PGlite}=await import(`${deps}/@electric-sql/pglite/dist/index.js`);
  const {pgcrypto}=await import(`${deps}/@electric-sql/pglite/dist/contrib/pgcrypto.js`);
  const {z}=createRequire(path.resolve(deps,'../package.json'))('zod');
  const pg=new PGlite({extensions:{pgcrypto}}),events=[];
  const adapt=r=>({...r,rowCount:r.rows.length||r.affectedRows||0});
  const db={query:async(sql,args)=>adapt(await pg.query(sql,args))};
  const tx=fn=>pg.transaction(c=>fn({query:async(sql,args)=>adapt(await c.query(sql,args))}));
  let sequence=0;
  async function routesFor(file){
    const source=fs.readFileSync(path.join(root,'backend/src/modules',file),'utf8'),name=source.match(/export async function (\w+)/)[1],routes=new Map(),app={authenticate(){},optionalAuth(){}};
    for(const method of ['get','post','put','delete','patch'])app[method]=(url,opts,handler)=>routes.set(`${method} ${url}`,handler);
    const context={z,db,tx,crypto,argon2:{},config:{},ApiError,opaqueId:()=>`pst_profile_${++sequence}`,sha256:value=>crypto.createHash('sha256').update(value).digest('hex'),audit:async()=>{},notify:async()=>{},publishGlobal:async()=>{},publishToUsers:async(...args)=>events.push(args)};
    await new Function(...Object.keys(context),source.replace(/^import .*?;\n/gm,'').replace(/export \{[^}]+\};/g,'').replace(/export /g,'')+`;return ${name};`)(...Object.values(context))(app);
    return routes;
  }
  const req=(user='owner',target='owner',body={})=>({user:{sub:user},params:{handle:target,userId:target,id:target},body,query:{}});
  try{
    const migrations=fs.readdirSync(path.join(root,'backend/sql')).filter(f=>f.endsWith('.sql')).sort();
    for(const file of migrations.filter(f=>f!=='010_profile_details.sql'))await pg.exec(fs.readFileSync(path.join(root,'backend/sql',file),'utf8'));
    await pg.exec(`insert into users(id,email,password_hash,created_at) values('owner','owner@example.test','test','2020-04-15T10:30:00Z'),('viewer','viewer@example.test','test','2021-02-03T00:00:00Z');
      insert into profiles(user_id,handle,display_name,bio) values('owner','owner','Owner','Original bio'),('viewer','viewer','Viewer','');`);
    const migration=fs.readFileSync(path.join(root,'backend/sql/010_profile_details.sql'),'utf8');
    await pg.exec(migration);await pg.exec(migration);
    const users=await routesFor('users.js'),auth=await routesFor('auth.js'),posts=await routesFor('posts.js');
    const profile=()=>users.get('get /v1/users/:handle')(req('viewer'));
    const me=()=>auth.get('get /v1/me')(req('owner'));
    const patch=body=>users.get('patch /v1/me/profile')(req('owner','owner',body));
    const create=async body=>{const reply={code(n){this.status=n;return this},send(value){this.body=value;return this}};await posts.get('post /v1/posts')({user:{sub:'owner'},body:{text:'Example',mediaIds:[],...body}},reply);assert.equal(reply.status,201);return reply.body.id};
    const read=id=>posts.get('get /v1/posts/:id')(req('owner',id));
    const validation=e=>e instanceof z.ZodError;

    await t.test('migration preserves profile data and real account join dates',async()=>{
      for(const p of [await profile(),await me()]){
        assert.equal(p.bio,'Original bio');assert.equal(p.location,'');assert.equal(p.website,'');
        assert.equal(new Date(p.created_at).toISOString(),'2020-04-15T10:30:00.000Z');
        assert.equal(new Date(p.joined_at).toISOString(),'2020-04-15T10:30:00.000Z');
      }
    });
    await t.test('location and safe website persist, can be cleared, and survive unrelated edits',async()=>{
      await patch({location:'  New York, NY  ',website:' example.com/about '});
      await patch({bio:'Updated bio'});
      for(const p of [await profile(),await me()]){
        assert.equal(p.location,'New York, NY');assert.equal(p.website,'https://example.com/about');assert.equal(p.bio,'Updated bio');
        assert.equal(new Date(p.joined_at).toISOString(),'2020-04-15T10:30:00.000Z');
      }
      for(const website of ['javascript:alert(1)','data:text/html,hello','https://name:password@example.com/','not a valid hostname','https://example.com/'+ 'a'.repeat(2048)])await assert.rejects(()=>patch({website}),validation);
      await assert.rejects(()=>patch({location:'x'.repeat(121)}),validation);
      assert.equal((await profile()).website,'https://example.com/about');
      await patch({location:'',website:''});assert.equal((await me()).location,'');assert.equal((await me()).website,'');
    });
    await t.test('follow and unfollow return and broadcast current counts without duplicate events',async()=>{
      events.length=0;
      const follow=()=>users.get('post /v1/users/:userId/follow')(req('viewer'));
      const first=await follow();
      assert.equal(first.following,true);
      assert.deepEqual(first.counts,[{userId:'owner',followers:1,following:0},{userId:'viewer',followers:0,following:1}]);
      assert.equal((await profile()).followers,1);
      await follow();assert.equal(events.length,1);assert.equal(events[0][1],'social.updated');
      assert.deepEqual(new Set(events[0][0]),new Set(['owner','viewer']));assert.deepEqual(events[0][2].counts,first.counts);
      const removed=await users.get('delete /v1/users/:userId/follow')(req('viewer'));
      assert.equal(removed.following,false);assert.deepEqual(removed.counts,[{userId:'owner',followers:0,following:0},{userId:'viewer',followers:0,following:0}]);
      assert.equal(events.length,2);assert.equal((await profile()).followers,0);
      await users.get('delete /v1/users/:userId/follow')(req('viewer'));assert.equal(events.length,2);
      await pg.exec(`insert into blocks(blocker_id,blocked_id) values('viewer','owner');`);
      await assert.rejects(()=>follow(),e=>e.statusCode===404);
      await assert.rejects(()=>users.get('delete /v1/users/:userId/follow')(req('viewer')),e=>e.statusCode===404);
      await pg.exec('delete from blocks');
    });
    await t.test('280 counts Unicode code points and applies to text posts, replies and attached images',async()=>{
      const exact=await create({text:'😀'.repeat(280)});assert.equal((await read(exact)).text,'😀'.repeat(280));
      await create({text:'a'.repeat(280)});
      const before=(await db.query('select count(*)::int n from posts')).rows[0].n;
      for(const text of ['a'.repeat(281),'😀'.repeat(281)])await assert.rejects(()=>create({text}),validation);
      await assert.rejects(()=>create({text:'a'.repeat(281),replyToId:exact}),validation);
      await pg.exec(`insert into media(id,owner_user_id,object_key,mime_type,byte_size,status) values('text_image','owner','text/image','image/jpeg',100,'ready');`);
      await assert.rejects(()=>create({text:'a'.repeat(281),mediaIds:['text_image']}),validation);
      assert.equal((await db.query(`select post_id from media where id='text_image'`)).rows[0].post_id,null);
      assert.equal((await db.query('select count(*)::int n from posts')).rows[0].n,before);
      await assert.rejects(()=>posts.get('patch /v1/posts/:id')(req('owner',exact,{text:'Edit bubble'})),e=>e.code==='CAPTION_NOT_EDITABLE');
    });
    await t.test('gallery and long-form text remain exempt and historical longer text remains readable',async()=>{
      const caption='caption '.repeat(500),article='article '.repeat(5000);
      const gallery=await create({contentKind:'gallery',text:caption}),long=await create({contentKind:'longform',title:'Long article',text:article});
      assert.equal((await read(gallery)).text,caption);assert.equal((await read(long)).text,article);
      await pg.exec(`insert into media(id,owner_user_id,post_id,object_key,mime_type,byte_size,status) values('gallery_image','owner','${gallery}','gallery/image','image/jpeg',100,'ready');`);
      await db.query(`update posts set created_at='2010-01-01' where id=$1`,[gallery]);
      assert.equal((await posts.get('patch /v1/posts/:id')(req('owner',gallery,{text:caption+'Edited'}))).text,caption+'Edited');
      await db.query(`insert into posts(id,author_id,text) values('historical_long_text','owner',$1)`,['Historical '.repeat(100)]);
      assert.equal((await read('historical_long_text')).text,'Historical '.repeat(100));
    });
  }finally{await pg.close()}
});
