import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function clock(){
  const html=fs.readFileSync(new URL('../../index.html',import.meta.url),'utf8');
  const source=html.slice(html.indexOf('const clockZones='),html.indexOf('\ndocument.addEventListener(\'click\'',html.indexOf('const clockZones=')));
  const nodes=[{textContent:'',dataset:{}},{textContent:'',dataset:{}}],state={elapsed:0},window={};
  const context=vm.createContext({window,Intl,Date,performance:{now:()=>state.elapsed},document:{querySelectorAll:()=>nodes,addEventListener(){}},setInterval(){}});
  vm.runInContext(source,context);
  return {window,nodes,state,paint:()=>vm.runInContext('tick()',context)};
}

test('clock begins in Eastern and handles winter and summer with IANA rules',()=>{
  const c=clock();c.window.PNGEA_CLOCK.sync('2026-01-14T12:00:00Z');
  assert.equal(c.nodes[0].dataset.timeZone,'America/New_York');assert.match(c.nodes[0].textContent,/7:00 AM EST/);
  c.window.PNGEA_CLOCK.sync('2026-07-14T12:00:00Z');assert.match(c.nodes[0].textContent,/8:00 AM EDT/);assert.equal(c.nodes[0].textContent,c.nodes[1].textContent);
});

test('clock rotates US zones without changing the underlying instant',()=>{
  const c=clock();c.window.PNGEA_CLOCK.sync('2026-07-14T12:00:00Z');c.state.elapsed=15000;c.paint();
  assert.equal(c.nodes[0].dataset.timeZone,'America/Chicago');assert.match(c.nodes[0].textContent,/7:00 AM CDT/);
  c.state.elapsed=75000;c.paint();assert.equal(c.nodes[0].dataset.timeZone,'Pacific/Honolulu');assert.match(c.nodes[0].textContent,/2:01 AM HST/);
});

test('clock uses server time and rejects invalid slow synchronization',()=>{
  const c=clock();c.window.PNGEA_CLOCK.sync('2026-07-14T12:00:00Z',200);const value=c.window.PNGEA_CLOCK.now();
  assert.equal(value,Date.parse('2026-07-14T12:00:00Z')+100);
  c.window.PNGEA_CLOCK.sync('not-a-date');c.window.PNGEA_CLOCK.sync('2030-01-01T00:00:00Z',10001);assert.equal(c.window.PNGEA_CLOCK.now(),value);
});
