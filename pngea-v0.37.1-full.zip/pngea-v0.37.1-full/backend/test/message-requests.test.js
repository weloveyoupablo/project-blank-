import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const source=fs.readFileSync(path.join(root,'src/modules/messages.js'),'utf8');
const reply=()=>({status:200,body:null,code(n){this.status=n;return this},send(body){this.body=body;return this}});
class ApiError extends Error{constructor(statusCode,code,message){super(message);Object.assign(this,{statusCode,code})}}

test('every conversation operation authorizes membership and blocks before reading or changing data',async()=>{
  const schema=new Proxy({}, {get:(_,key)=>key==='parse'?body=>body:()=>schema});
  const z=new Proxy({}, {get:()=>()=>schema});
  const routes=new Map(),query=async()=>({rows:[],rowCount:0});
  const app={authenticate(){}};for(const method of ['get','post'])app[method]=(url,opts,handler)=>routes.set(`${method} ${url}`,handler);
  const deps={z,db:{query},tx:fn=>fn({query}),ApiError,opaqueId:()=>'',notify:async()=>{},publishToUsers:async()=>{throw new Error('Must not publish unauthorized data')}};
  await new Function(...Object.keys(deps),source.replace(/^import .*?;\n/gm,'').replace(/export /g,'')+';return registerMessages;')(...Object.values(deps))(app);
  for(const name of ['get /v1/conversations/:id/messages','post /v1/conversations/:id/messages','post /v1/conversations/:id/read','post /v1/conversations/:id/request','post /v1/conversations/:id/request/respond','post /v1/conversations/:id/typing']){
    await assert.rejects(()=>routes.get(name)({user:{sub:'usr_viewer'},params:{id:'cnv_secret'},body:{text:'No access',mediaIds:[],typing:true,accept:true}},reply()),e=>e.statusCode===404,name);
  }
});

// This integration check runs against PostgreSQL compiled to WebAssembly. It
// needs no database service or production credentials. Install its dependencies
// in a temporary directory and set PNGEA_TEST_MODULE_ROOT to that node_modules.
test('message request, typing, block, and retry behavior in PostgreSQL',{skip:!process.env.PNGEA_TEST_MODULE_ROOT},async t=>{
  const deps=process.env.PNGEA_TEST_MODULE_ROOT;
  const {PGlite}=await import(`${deps}/@electric-sql/pglite/dist/index.js`);
  const {pgcrypto}=await import(`${deps}/@electric-sql/pglite/dist/contrib/pgcrypto.js`);
  const {z}=createRequire(path.resolve(deps,'../package.json'))('zod');
  const pg=new PGlite({extensions:{pgcrypto}});
  const adapt=result=>({...result,rowCount:result.rows.length||result.affectedRows||0});
  const db={query:async(sql,args)=>adapt(await pg.query(sql,args))};
  const tx=fn=>pg.transaction(async c=>fn({query:async(sql,args)=>adapt(await c.query(sql,args))}));
  const routes=new Map(),events=[],notifications=[];let seq=0;
  const app={authenticate(){}};for(const method of ['get','post'])app[method]=(url,opts,handler)=>routes.set(`${method} ${url}`,handler);
  const context={z,db,tx,ApiError,opaqueId:()=>`test_${++seq}`,publishToUsers:async(...args)=>events.push(args),notify:async body=>notifications.push(body)};
  await new Function(...Object.keys(context),source.replace(/^import .*?;\n/gm,'').replace(/export /g,'')+';return registerMessages;')(...Object.values(context))(app);
  const call=async(method,user,id,body,query)=>{
    const response=reply();
    const result=await routes.get(method)({user:{sub:user},params:{id},body,query,log:{warn(){}}},response);
    return response.body||result;
  };
  const create=(user,other,title)=>call('post /v1/conversations',user,null,{memberIds:Array.isArray(other)?other:[other],title});
  const list=user=>call('get /v1/conversations',user);
  const messages=(user,id)=>call('get /v1/conversations/:id/messages',user,id,undefined,{});
  const request=(user,id)=>call('post /v1/conversations/:id/request',user,id,{});
  const respond=(user,id,accept)=>call('post /v1/conversations/:id/request/respond',user,id,{accept});
  const typing=(user,id,value)=>call('post /v1/conversations/:id/typing',user,id,{typing:value});
  const send=(user,id,clientId)=>call('post /v1/conversations/:id/messages',user,id,{text:'A real message',mediaIds:[],clientId});
  try{
    const migrations=fs.readdirSync(path.join(root,'sql')).filter(f=>f.endsWith('.sql')).sort();
    for(const file of migrations.filter(f=>f<'009_message_requests.sql'))await pg.exec(fs.readFileSync(path.join(root,'sql',file),'utf8'));
    for(const id of 'abcdefghijkl')await db.query(`insert into users(id,email,password_hash) values($1,$2,'test');`,[id,`${id}@example.test`]);
    for(const id of 'abcdefghijkl')await db.query(`insert into profiles(user_id,handle,display_name) values($1,$2,$1)`,[id,`test_${id}`]);
    await pg.exec(`insert into conversations(id,created_by,direct_key) values('historical','h','h:i');insert into conversation_members(conversation_id,user_id) values('historical','h'),('historical','i');`);
    const migration=fs.readFileSync(path.join(root,'sql/009_message_requests.sql'),'utf8');await pg.exec(migration);await pg.exec(migration);

    await t.test('migration preserves historical chats and can be rerun',async()=>{
      assert.equal((await messages('h','historical')).viewer_can_message,true);
      await send('h','historical','historical-client');
      assert.equal((await messages('i','historical')).items.length,1);
    });

    await t.test('nonmutual requests require recipient consent and notify once',async()=>{
      const conversation=await create('a','b');
      assert.equal(conversation.request_status,'none');assert.equal(conversation.viewer_can_message,false);
      assert.equal((await create('b','a')).id,conversation.id);
      assert.equal((await list('b')).items.length,0);
      assert.equal((await messages('b',conversation.id)).request_status,'none');
      await assert.rejects(()=>send('a',conversation.id,'blocked-before-request'),e=>e.code==='MESSAGE_REQUEST_REQUIRED');
      await assert.rejects(()=>typing('a',conversation.id,true),e=>e.code==='MESSAGE_REQUEST_REQUIRED');
      await request('a',conversation.id);await request('a',conversation.id);
      assert.equal(notifications.length,1);assert.equal(notifications[0].userId,'b');assert.equal(notifications[0].objectId,conversation.id);
      assert.equal((await list('b')).items[0].request_status,'pending');
      await assert.rejects(()=>respond('a',conversation.id,true),e=>e.code==='REQUEST_RECIPIENT_REQUIRED');
      assert.equal((await respond('b',conversation.id,true)).viewer_can_message,true);
      assert.equal((await respond('b',conversation.id,true)).request_status,'accepted');
    });

    await t.test('typing is leased, throttled, excludes self, and is cleared on send',async()=>{
      const conversation=await create('a','b'),id=conversation.id;
      events.length=0;
      const lease=await typing('a',id,true);assert.ok(Date.parse(lease.expiresAt)>Date.now());
      await typing('a',id,true);
      assert.equal(events.filter(e=>e[1]==='conversation.typing').length,1);
      assert.deepEqual(events[0][0],['b']);
      assert.equal((await messages('b',id)).typing[0].userId,'a');
      assert.equal((await messages('a',id)).typing.length,0);
      await send('a',id,'stable-retry-client');await send('a',id,'stable-retry-client');
      assert.equal((await messages('b',id)).items.length,1);
      assert.equal((await messages('b',id)).typing.length,0);
      assert.equal(events.filter(e=>e[1]==='message.created').length,1);
      assert.equal(events.filter(e=>e[1]==='conversation.typing'&&!e[2].typing).length,1);
      await typing('b',id,true);
      await db.query(`update conversation_typing set expires_at=now()-interval '1 second' where conversation_id=$1`,[id]);
      assert.equal((await messages('a',id)).typing.length,0);
    });

    await t.test('a block closes existing conversations and all interaction routes',async()=>{
      const {id}=await create('a','b');await pg.exec(`insert into blocks(blocker_id,blocked_id) values('b','a')`);
      assert.equal((await list('a')).items.length,0);assert.equal((await list('b')).items.length,0);
      for(const [user,other] of [['a','b'],['b','a']]){
        await assert.rejects(()=>create(user,other),e=>e.statusCode===404);
        for(const action of [()=>messages(user,id),()=>send(user,id,'blocked-known-id'),()=>typing(user,id,true),()=>request(user,id),()=>respond(user,id,true),()=>call('post /v1/conversations/:id/read',user,id,{})])await assert.rejects(action,e=>e.statusCode===404);
      }
    });

    await t.test('decline is idempotent, hides the request, and prevents reopening',async()=>{
      const {id}=await create('c','d');await request('c',id);
      assert.equal((await respond('d',id,false)).request_status,'declined');
      assert.equal((await respond('d',id,false)).request_status,'declined');
      assert.equal((await list('c')).items.length,0);assert.equal((await list('d')).items.length,0);
      await assert.rejects(()=>messages('c',id),e=>e.statusCode===404);
      await assert.rejects(()=>create('c','d'),e=>e.statusCode===404);
      await assert.rejects(()=>respond('d',id,true),e=>e.code==='REQUEST_NOT_PENDING');
    });

    await t.test('mutual followers open directly and a title cannot bypass the gate',async()=>{
      const gated=await create('e','f','A named chat');assert.equal(gated.request_status,'none');
      await pg.exec(`insert into follows(follower_id,followee_id) values('e','f'),('f','e')`);
      assert.equal((await messages('e',gated.id)).request_status,'accepted');
      await pg.exec(`delete from follows where follower_id in('e','f')`);
      assert.equal((await messages('e',gated.id)).viewer_can_message,true);
      const fresh=await create('j','k');assert.equal(fresh.request_status,'none');
      await pg.exec(`insert into follows(follower_id,followee_id) values('j','k'),('k','j')`);
      assert.equal((await create('k','j')).viewer_can_message,true);
    });

    await t.test('disabled message requests prevent notification but preserve mutual and accepted chats',async()=>{
      const {id}=await create('e','f');
      // This previously accepted pair remains open when requests are disabled.
      await db.query(`insert into user_settings(user_id,allow_message_requests) values('f',false) on conflict(user_id) do update set allow_message_requests=false`);
      assert.equal((await messages('e',id)).viewer_can_message,true);
      const fresh=await create('j','f');notifications.length=0;
      await assert.rejects(()=>request('j',fresh.id),e=>e.statusCode===403&&e.code==='REQUESTS_DISABLED');
      assert.equal(notifications.length,0);assert.equal((await messages('j',fresh.id)).request_status,'none');
      await pg.exec(`insert into follows(follower_id,followee_id) values('j','f'),('f','j')`);
      assert.equal((await request('j',fresh.id)).viewer_can_message,true);
    });

    await t.test('groups cannot bypass requests or blocks',async()=>{
      await assert.rejects(()=>create('g',['h','l'],'Group'),e=>e.code==='MESSAGE_REQUEST_REQUIRED');
      await pg.exec(`insert into follows(follower_id,followee_id) select a,b from unnest(array['g','h','l']) a cross join unnest(array['g','h','l']) b where a<>b;`);
      const {id}=await create('g',['h','l'],'Group');assert.equal((await messages('g',id)).viewer_can_message,true);
      await pg.exec(`insert into blocks(blocker_id,blocked_id) values('g','h')`);
      await assert.rejects(()=>messages('g',id),e=>e.statusCode===404);
      await assert.rejects(()=>messages('h',id),e=>e.statusCode===404);
      events.length=0;await send('l',id,'group-after-block');
      assert.deepEqual(events.find(e=>e[1]==='message.created')[0],['l']);
      await assert.rejects(()=>create('g',['h','l'],'Other group'),e=>e.statusCode===404);
    });

    await t.test('a departed blocked group sender is hidden in history, previews and unread counts',async()=>{
      await pg.exec(`insert into conversations(id,title,request_status) values('historical_group','Historical group','accepted');
        insert into conversation_members(conversation_id,user_id,left_at) values('historical_group','g',null),('historical_group','l',null),('historical_group','h',now());
        insert into messages(id,conversation_id,sender_id,text,created_at) values
          ('visible_history','historical_group','l','Visible message',now()-interval '2 seconds'),
          ('blocked_history','historical_group','h','Blocked historical message',now()-interval '1 second');`);
      const result=await messages('g','historical_group');
      assert.deepEqual(result.items.map(m=>m.id),['visible_history']);
      const conversation=(await list('g')).items.find(c=>c.id==='historical_group');
      assert.equal(conversation.last_message,'Visible message');assert.equal(conversation.unread,1);
      assert.equal((await messages('l','historical_group')).items.length,2);
    });

    await t.test('inbox metadata identifies attachment-only history and a single deterministic latest message',async()=>{
      await pg.exec(`insert into conversations(id,title,request_status) values('media_history','Media history','accepted'),('empty_history','Empty history','accepted');
        insert into conversation_members(conversation_id,user_id) values('media_history','g'),('media_history','l'),('media_history','h'),('empty_history','g'),('empty_history','l');
        insert into messages(id,conversation_id,sender_id,text,created_at) values
          ('preview_a','media_history','l','Earlier text',now()-interval '2 seconds'),
          ('preview_b','media_history','g','',now()-interval '2 seconds'),
          ('preview_blocked','media_history','h','Blocked latest',now()-interval '1 second');
        update conversation_members set left_at=now() where conversation_id='media_history' and user_id='h';
        insert into media(id,owner_user_id,object_key,mime_type,byte_size,status) values('inbox_photo','g','inbox/photo','image/jpeg',100,'ready'),('inbox_voice','g','inbox/voice','audio/webm',100,'ready');
        insert into message_media(message_id,media_id,position) values('preview_b','inbox_voice',1),('preview_b','inbox_photo',0);`);
      const rows=(await list('g')).items;
      const media=rows.find(c=>c.id==='media_history');
      assert.equal(media.last_message_id,'preview_b');assert.equal(media.last_message_sender_id,'g');assert.equal(media.last_message,'');assert.ok(media.last_message_at);
      assert.deepEqual(media.last_message_media.map(m=>m.mimeType),['image/jpeg','audio/webm']);
      const empty=rows.find(c=>c.id==='empty_history');
      assert.equal(empty.last_message_id,null);assert.equal(empty.last_message_at,null);assert.deepEqual(empty.last_message_media,[]);
    });
  }finally{await pg.close()}
});
