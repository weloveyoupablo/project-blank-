import test from 'node:test';
import assert from 'node:assert/strict';
import { diversify,estimateImportance,inferTopics,marketMoveTier,marketScore,newsLabel,newsScore,shouldSurfaceNews,sourceTrustFor } from '../src/lib/ticker-ranker.js';

test('diversify avoids long same-kind runs',()=>{
  const out=diversify([
    {key:'n1',kind:'news',score:1,label:'NEWS'},{key:'n2',kind:'news',score:.9,label:'NEWS'},{key:'n3',kind:'news',score:.8,label:'NEWS'},
    {key:'m1',kind:'markets',score:.7,marketTier:'notable'},{key:'l1',kind:'live',score:.6,fresh:true}
  ],5);
  assert.equal(out.length,5);
  assert.notEqual(out.slice(0,3).every(x=>x.kind==='news'),true);
});

test('verified breaking news outranks routine items',()=>{
  const out=diversify([
    {key:'m',kind:'markets',score:1.2,marketTier:'notable'},
    {key:'n',kind:'news',score:.72,label:'BREAKING'}
  ],2);
  assert.equal(out[0].key,'n');
});

test('single-source high-importance story is developing, not breaking',()=>{
  assert.equal(newsLabel({importance:92,verification_status:'single_source'}),'DEVELOPING');
  assert.equal(newsLabel({importance:92,verification_status:'corroborated'}),'BREAKING');
});

test('important macro headlines outrank routine headlines',()=>{
  assert.ok(estimateImportance('Federal Reserve announces emergency rate cut')>estimateImportance('Company opens a new office'));
});

test('routine analyst headlines are downweighted',()=>{
  assert.ok(estimateImportance('Broker raises price target on Example Corp')<50);
});

test('topic inference catches economy technology defense and China',()=>{
  const t=inferTopics('China AI chip export rules hit defense suppliers','Federal Reserve rates remain unchanged');
  assert.ok(t.includes('technology'));
  assert.ok(t.includes('economy'));
  assert.ok(t.includes('defense'));
  assert.ok(t.includes('china'));
});

test('watched fresh market quote gets a useful score',()=>{
  const score=marketScore({symbol:'SPY',change_percent:1.2,as_of:new Date().toISOString()},{symbols:['SPY']});
  assert.ok(score>.5);
});

test('market move tiers use tighter thresholds for broad indexes',()=>{
  assert.equal(marketMoveTier({symbol:'SPY',change_percent:2}),'major');
  assert.equal(marketMoveTier({symbol:'AAPL',change_percent:2}),'notable');
});

test('personal relevance lifts news',()=>{
  const a={headline:'Apple update',importance:55,published_at:new Date().toISOString(),verification_status:'single_source',source_weight:.7,symbols:['AAPL'],topics:[]};
  assert.ok(newsScore(a,{symbols:['AAPL']})>newsScore(a,{symbols:['MSFT']}));
});

test('routine irrelevant news can be suppressed while relevant news surfaces',()=>{
  const a={importance:50,published_at:new Date().toISOString(),status:'active',symbols:['AAPL'],topics:['technology']};
  assert.equal(shouldSurfaceNews(a,{symbols:['MSFT'],topics:[]}),false);
  assert.equal(shouldSurfaceNews(a,{symbols:['AAPL'],topics:[]}),true);
});

test('source trust recognizes top wire services',()=>{
  assert.ok(sourceTrustFor('Reuters')>sourceTrustFor('Unknown Wire'));
});
