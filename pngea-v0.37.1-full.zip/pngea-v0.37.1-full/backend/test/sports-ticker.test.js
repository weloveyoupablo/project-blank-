import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {configuredNewsFeeds,configuredNewsSources,publisherMatches,approvedArticleUrl,approvedNewsSource} from '../src/lib/news-sources.js';
import {estimateImportance,inferTopics,sourceTrustFor,diversify,marketScore,newsScore,newsLabel,shouldSurfaceNews,marketMoveTier,selectMarketQuotes} from '../src/lib/ticker-ranker.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const strip=source=>source.replace(/^import .*?;\n/gm,'').replace(/export /g,'');
function load(file,deps,names){return new Function(...Object.keys(deps),strip(fs.readFileSync(path.join(root,'src/providers',file),'utf8'))+`;return {${names}};`)(...Object.values(deps));}
const {scoreboardItems,SCOREBOARD_LEAGUES}=load('sports-scores.js',{db:{},publishGlobal:async()=>{}},'scoreboardItems,SCOREBOARD_LEAGUES');
const news=deps=>load('rss-news.js',{crypto,db:{query:async()=>({rows:[]})},config:{},publishGlobal:async()=>{},estimateImportance,inferTopics,sourceTrustFor,configuredNewsFeeds,publisherMatches,approvedArticleUrl,...deps},'resolveArticleUrl,pollRssFeeds');
const now=Date.now(),league=SCOREBOARD_LEAGUES[0];
const game=(type={state:'in',shortDetail:'Q3 4:20'})=>({id:'40100001',date:new Date(now-3600000).toISOString(),status:{type},links:[{href:'https://www.espn.com/nfl/game/_/gameId/40100001'}],competitions:[{competitors:[{homeAway:'home',team:{abbreviation:'KC'},score:'21'},{homeAway:'away',team:{abbreviation:'BUF'},score:'17'}]}]});

test('scoreboards preserve real scores, state, source link, and short live expiry',()=>{
  const rows=scoreboardItems({events:[game()]},league,now);
  assert.equal(rows.length,1);assert.equal(rows[0].homeScore,21);assert.equal(rows[0].awayScore,17);
  assert.equal(rows[0].state,'live');assert.equal(Date.parse(rows[0].expiresAt),now+180000);
  assert.equal(rows[0].url,'https://www.espn.com/nfl/game/_/gameId/40100001');
  assert.equal(SCOREBOARD_LEAGUES.length,7);
});
test('scheduled games never invent zero scores',()=>{
  const scheduled=game({state:'pre',description:'Scheduled'});scheduled.date=new Date(now+3600000).toISOString();
  const item=scoreboardItems({events:[scheduled]},league,now)[0];assert.equal(item.state,'scheduled');assert.equal(item.homeScore,null);assert.equal(item.awayScore,null);
});
test('stale, canceled, invalid, and unapproved-link scores are omitted',()=>{
  const stale=game();stale.date=new Date(now-25*3600000).toISOString();
  const invalid=game();invalid.competitions[0].competitors[0].score='unknown';
  const foreign=game();foreign.links=[{href:'https://espn.com.evil.example/game'}];
  assert.deepEqual(scoreboardItems({events:[stale,invalid,foreign,game({state:'pre',name:'STATUS_POSTPONED'})]},league,now),[]);
});
test('publisher links resolve before rendering and are cached without delaying a user click',async()=>{
  const provider=news(),feed=configuredNewsFeeds().find(x=>x.name==='Reuters');let requests=0;
  const fetcher=async()=>{requests++;return {ok:true,url:'https://www.reuters.com/world/example-article',text:async()=>''}};
  const link='https://news.google.com/rss/articles/test-redirect-unique';
  assert.equal(await provider.resolveArticleUrl(link,feed,fetcher),'https://www.reuters.com/world/example-article');
  await provider.resolveArticleUrl(link,feed,fetcher);assert.equal(requests,1);
  assert.equal(await provider.resolveArticleUrl('javascript:alert(1)',feed,fetcher),null);
  assert.equal(await provider.resolveArticleUrl('https://unapproved.example/article',feed,fetcher),null);
});
test('unresolved Google redirects and wrong publisher URLs never become click targets',async()=>{
  const provider=news(),feed=configuredNewsFeeds().find(x=>x.name==='AP');
  const result=await provider.resolveArticleUrl('https://news.google.com/rss/articles/unresolved-case',feed,async()=>({ok:true,url:'https://news.google.com/rss/articles/unresolved-case',text:async()=>'<a href="https://unapproved.example/story">Story</a>'}));
  assert.equal(result,null);
});
test('RSS ingestion accepts only fresh approved article links and marks sports topics',async()=>{
  const inserts=[],feed=configuredNewsFeeds().find(source=>source.name==='ESPN');
  const item=(url,date)=>`<item><title>Team wins football game</title><link>${url}</link><pubDate>${new Date(date).toUTCString()}</pubDate></item>`;
  const xml=`<rss><channel>${item('https://www.espn.com/nfl/story/valid',Date.now())}${item('https://unapproved.example/story',Date.now())}${item('https://www.espn.com/nfl/story/old',Date.now()-25*3600000)}</channel></rss>`;
  const provider=news({console:{log(){},error(){}},db:{query:async(sql,args)=>{if(sql.startsWith('insert into external_news_articles'))inserts.push(args);return {rows:[]}}},
    fetch:async url=>({ok:true,url,text:async()=>url===feed.url?xml:'<rss><channel></channel></rss>'})});
  await provider.pollRssFeeds();assert.equal(inserts.length,1);assert.equal(inserts[0][3],'ESPN');assert.ok(inserts[0][7].includes('sports'));assert.equal(inserts[0][6],'https://www.espn.com/nfl/story/valid');
});
test('stale scoreboard HTTP responses never renew live score leases',async()=>{
  let writes=0;
  const provider=load('sports-scores.js',{console:{error(){}},db:{query:async sql=>{if(sql.startsWith('insert into sports_scores'))writes++;return {rows:[]}}},publishGlobal:async()=>{},
    fetch:async()=>({ok:true,headers:{get:()=>new Date(Date.now()-10*60000).toUTCString()},json:async()=>({events:[game()]})})},'pollSportsScores');
  assert.equal(await provider.pollSportsScores(),0);assert.equal(writes,0);
});

test('PostgreSQL ticker selects fresh real scores and approved headlines ahead of excess markets',{skip:!process.env.PNGEA_TEST_MODULE_ROOT},async()=>{
  const deps=process.env.PNGEA_TEST_MODULE_ROOT;
  const {PGlite}=await import(`${deps}/@electric-sql/pglite/dist/index.js`),{pgcrypto}=await import(`${deps}/@electric-sql/pglite/dist/contrib/pgcrypto.js`),{z}=await import(`${deps}/zod/index.js`);
  const pg=new PGlite({extensions:{pgcrypto}});
  const db={query:async(sql,args)=>{const result=await pg.query(sql,args);return {...result,rowCount:result.rows.length||result.affectedRows||0}}};
  try{
    for(const file of fs.readdirSync(path.join(root,'sql')).filter(file=>file.endsWith('.sql')).sort())await pg.exec(fs.readFileSync(path.join(root,'sql',file),'utf8'));
    await pg.exec(`insert into users(id,email,password_hash) values('ticker_user','ticker@example.test','test');insert into user_ticker_preferences(user_id,max_items) values('ticker_user',20);insert into notifications(user_id,kind,payload) values('ticker_user','mention','{"text":"Someone mentioned you"}');`);
    for(let i=0;i<24;i++)await db.query(`insert into market_quotes(symbol,last_price,change_percent,feed,source,as_of) values($1,100,8,'iex','test',now())`,[`T${i}`]);
    const publishers=[['CNN','https://www.cnn.com/world/example'],['NPR','https://www.npr.org/example'],['NBC News','https://www.nbcnews.com/example'],['MS NOW','https://www.ms.now/example'],['ESPN','https://www.espn.com/nfl/story/example'],['CBS Sports','https://www.cbssports.com/nfl/news/example'],['Yahoo Sports','https://sports.yahoo.com/example']];
    for(let i=0;i<21;i++){const [name,url]=publishers[i%publishers.length];await db.query(`insert into external_news_articles(id,provider,provider_item_id,source_name,headline,url,story_key,published_at) values($1,'test',$1,$2,$3,$4,$1,now())`,[`article${i}`,name,`Real fixture headline ${i}`,`${url}${i}`]);}
    await db.query(`insert into external_news_articles(id,provider,provider_item_id,source_name,headline,url,story_key,published_at) values('rejected','test','rejected','Reuters','Wrong publisher link','https://unapproved.example','rejected',now())`);
    for(const [id,observed,expiry] of [['live','now()','now()+interval \'3 minutes\''],['stale','now()-interval \'5 minutes\'','now()+interval \'3 minutes\''],['expired','now()','now()-interval \'1 minute\'']])await pg.exec(`insert into sports_scores(id,league,home_team,away_team,home_score,away_score,state,status_text,scheduled_at,observed_at,expires_at,url) values('${id}','NFL','KC','BUF',21,17,'live','Q3 4:20',now()-interval '1 hour',${observed},${expiry},'https://www.espn.com/nfl/game/_/gameId/40100001')`);
    class ApiError extends Error{}
    const context={crypto,z,db,ApiError,config:{marketSymbols:['SPY'],newsRssFeeds:''},configuredNewsSources,approvedNewsSource,approvedArticleUrl,diversify,marketScore,newsScore,estimateImportance,inferTopics,newsLabel,shouldSurfaceNews,marketMoveTier,selectMarketQuotes};
    const handlers=new Map(),app={authenticate(){}};for(const method of ['get','post','patch'])app[method]=(url,opts,handler)=>handlers.set(`${method} ${url}`,typeof opts==='function'?opts:handler);
    await new Function(...Object.keys(context),strip(fs.readFileSync(path.join(root,'src/modules/ticker.js'),'utf8'))+';return registerTicker;')(...Object.values(context))(app);
    const response=await handlers.get('get /v1/ticker')({user:{sub:'ticker_user'}}),rows=response.items;
    assert.equal(rows.length,20);assert.ok(rows.filter(row=>row.kind==='markets').length<=4);
    assert.ok(rows.filter(row=>row.kind==='news'||row.kind==='sports').length>=14);
    assert.ok(rows.some(row=>row.key==='sports:live'&&row.text.includes('KC 21')));
    assert.ok(!rows.some(row=>['sports:stale','sports:expired','news:rejected'].includes(row.key)));
    assert.ok(rows.some(row=>row.kind==='you'));
  }finally{await pg.close()}
});
