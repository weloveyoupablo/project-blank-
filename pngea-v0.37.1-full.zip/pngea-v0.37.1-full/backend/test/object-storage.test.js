import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const deps=process.env.PNGEA_TEST_MODULE_ROOT;

// Exercise the production storage factory with the real SDK. No S3 requests
// occur: signing uses dummy local credentials and the nonempty video fixture.
test('browser video upload URL does not require an empty-body checksum',{skip:!deps},async()=>{
  const sdk=await import(`${deps}/@aws-sdk/client-s3/dist-cjs/index.js`);
  const {getSignedUrl}=await import(`${deps}/@aws-sdk/s3-request-presigner/dist-cjs/index.js`);
  const source=fs.readFileSync(path.join(root,'src/lib/object-storage.js'),'utf8');
  const config={objectStorageRegion:'us-east-1',objectStorageEndpoint:'http://127.0.0.1:9000',objectStorageForcePathStyle:true,
    objectStorageAccessKey:'local-test-key',objectStorageSecretKey:'local-test-secret',objectStorageBucket:'pngea-media',objectStoragePublicBaseUrl:''};
  const names=['S3Client','CreateBucketCommand','HeadBucketCommand','HeadObjectCommand','DeleteObjectCommand','GetObjectCommand','PutObjectCommand'];
  const context=Object.fromEntries(names.map(name=>[name,sdk[name]]));Object.assign(context,{getSignedUrl,config});
  const storage=new Function(...Object.keys(context),source.replace(/^import[\s\S]*?;\n/gm,'').replace(/export /g,'')+';return {objectStorage,createUploadUrl};')(...Object.values(context));
  try{
    const bytes=fs.readFileSync(path.resolve(root,'../tests/fixtures/reel.mp4'));assert.ok(bytes.length>0);
    const url=new URL(await storage.createUploadUrl({objectKey:'users/local/video/original.mp4',mimeType:'video/mp4',expiresIn:3600}));
    assert.equal(url.searchParams.get('x-amz-checksum-crc32'),null,'A bodyless presigner must not require the CRC32 of an empty body for a nonempty browser File.');
    assert.equal(url.searchParams.get('x-amz-sdk-checksum-algorithm'),null);
    assert.ok(url.searchParams.get('X-Amz-Signature'));assert.equal(url.searchParams.get('X-Amz-Expires'),'3600');
  }finally{storage.objectStorage.destroy()}
});
