import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const deps=process.env.PNGEA_TEST_MODULE_ROOT;
class ApiError extends Error {constructor(statusCode,code,message){super(message);Object.assign(this,{statusCode,code})}}
const response=()=>({code(n){this.status=n;return this},send(body){this.body=body;return this}});

test('social controls use an additive migration and no caption edit time window',()=>{
  const sql=fs.readFileSync(path.join(root,'backend/sql/008_social_controls.sql'),'utf8');
  assert.doesNotMatch(sql,/^\s*(drop|truncate|delete)\b/im);
  const source=fs.readFileSync(path.join(root,'backend/src/modules/posts.js'),'utf8');
  const route=source.split("app.patch('/v1/posts/:id'")[1].split("app.delete('/v1/posts/:id'")[0];
  assert.doesNotMatch(route,/interval|created_at\s*[<>]/);
});

test('real PostgreSQL social privacy, caption permissions and subscription delivery',{skip:!deps},async t=>{
  const {PGlite}=await import(`${deps}/@electric-sql/pglite/dist/index.js`);
  const {pgcrypto}=await import(`${deps}/@electric-sql/pglite/dist/contrib/pgcrypto.js`);
  const {z}=await import(`${deps}/zod/index.js`);
  const pg=new PGlite({extensions:{pgcrypto}}),notifications=[],events=[];
  const adapt=async(c,sql,args)=>{const r=await c.query(sql,args);return {...r,rowCount:r.affectedRows||r.rows.length}};
  const db={query:(sql,args)=>adapt(pg,sql,args)};
  const tx=fn=>pg.transaction(c=>fn({query:(sql,args)=>adapt(c,sql,args)}));
  let sequence=0,posts;
  async function routesFor(file){
    const source=fs.readFileSync(path.join(root,'backend/src/modules',file),'utf8'),name=source.match(/export async function (\w+)/)[1],routes=new Map(),app={authenticate(){},optionalAuth(){}};
    for(const method of ['get','post','put','delete','patch']) app[method]=(url,opts,handler)=>routes.set(`${method} ${url}`,handler);
    const context={z,db,tx,ApiError,config:{marketSymbols:[]},diversify:(items,limit)=>items.slice(0,limit),opaqueId:()=>`pst_test_${++sequence}`,audit:async()=>{},notify:async n=>notifications.push(n),publishGlobal:async(...a)=>events.push(a),publishToUsers:async(...a)=>events.push(a),fetchVisiblePost:(id,viewer)=>posts.get('get /v1/posts/:id')({params:{id},user:{sub:viewer}})};
    await new Function(...Object.keys(context),source.replace(/^import .*?;\n/gm,'').replace(/export \{[^}]+\};/g,'').replace(/export /g,'')+`;return ${name};`)(...Object.values(context))(app);
    return routes;
  }
  const user=(sub='owner')=>({sub});
  const request=(sub,id,body={})=>({user:user(sub),params:{id,userId:id,handle:id},body,query:{}});
  const deny404=e=>e.statusCode===404;
  try {
    for(const file of fs.readdirSync(path.join(root,'backend/sql')).filter(f=>f.endsWith('.sql')).sort()) await pg.exec(fs.readFileSync(path.join(root,'backend/sql',file),'utf8'));
    await pg.exec(fs.readFileSync(path.join(root,'backend/sql/008_social_controls.sql'),'utf8'));
    for(const id of ['owner','viewer','blocked','other','outsider']){
      await pg.query(`insert into users(id,email,password_hash) values($1,$2,'test')`,[id,`${id}@example.test`]);
      await pg.query(`insert into profiles(user_id,handle,display_name) values($1,$1,$1)`,[id]);
    }
    posts=await routesFor('posts.js');
    const users=await routesFor('users.js'),feed=await routesFor('feed.js'),social=await routesFor('social.js'),search=await routesFor('search.js');
    const make=async(body={},author='owner')=>{const r=response();await posts.get('post /v1/posts')({user:user(author),body:{text:'Example',visibility:'public',mediaIds:[],...body}},r);assert.equal(r.status,201);return r.body.id};
    const attach=async(id,mime)=>{await pg.query(`insert into media(id,owner_user_id,post_id,object_key,mime_type,byte_size,status) values($1,'owner',$2,$1,$3,100,'ready')`,[`med_${id}`,id,mime])};
    const profile=()=>users.get('get /v1/users/:handle')(request('viewer','owner'));

    await t.test('only bottom media captions are editable, without an age cutoff',async()=>{
      const gallery=await make({contentKind:'gallery'});await attach(gallery,'image/jpeg');
      await pg.query(`update posts set created_at=now()-interval '5 years' where id=$1`,[gallery]);
      const updated=await posts.get('patch /v1/posts/:id')(request('owner',gallery,{text:'Updated forever'}));
      assert.equal(updated.text,'Updated forever');assert.ok(updated.edited_at);assert.equal(updated.media.length,1);
      assert.ok(events.some(a=>a[0]==='post.updated'&&a[1].postId===gallery));
      await assert.rejects(()=>posts.get('patch /v1/posts/:id')(request('viewer',gallery,{text:'Stolen'})),deny404);
      await assert.rejects(()=>posts.get('patch /v1/posts/:id')(request('owner',gallery,{text:'No swaps',mediaIds:['other']})),e=>e instanceof z.ZodError);
      const video=await make();await attach(video,'video/mp4');
      assert.equal((await posts.get('patch /v1/posts/:id')(request('owner',video,{text:'Video caption'}))).text,'Video caption');
      for(const [body,mime] of [[{},'image/jpeg'],[{contentKind:'gallery'},'audio/webm'],[{contentKind:'longform',title:'An article'},'video/mp4']]){
        const id=await make(body);await attach(id,mime);
        await assert.rejects(()=>posts.get('patch /v1/posts/:id')(request('owner',id,{text:'Denied'})),e=>e.code==='CAPTION_NOT_EDITABLE');
      }
      const word=await make();await assert.rejects(()=>posts.get('patch /v1/posts/:id')(request('owner',word,{text:'Denied'})),e=>e.code==='CAPTION_NOT_EDITABLE');
    });

    await t.test('muting filters Home while preserving follows and the profile',async()=>{
      await pg.exec(`insert into follows(follower_id,followee_id) values('viewer','owner'),('owner','viewer'),('other','owner'),('blocked','owner');`);
      assert.ok((await feed.get('get /v1/feed')(request('viewer'))).items.length);
      await users.get('put /v1/users/:userId/mute')(request('viewer','owner'));
      assert.equal((await feed.get('get /v1/feed')(request('viewer'))).items.length,0);
      const p=await profile();assert.equal(p.viewer_following,true);assert.equal(p.follows_viewer,true);assert.equal(p.viewer_muted,true);assert.equal(p.viewer_post_notifications,'none');
      assert.ok((await posts.get('get /v1/users/:handle/posts')(request('viewer','owner'))).items.length);
      await users.get('delete /v1/users/:userId/mute')(request('viewer','owner'));
      assert.ok((await feed.get('get /v1/feed')(request('viewer'))).items.length);
    });

    await t.test('subscription modes persist, require follows for delivery and deduplicate mentions',async()=>{
      const pref=users.get('put /v1/users/:userId/post-notifications');
      await pref(request('viewer','owner',{mode:'posts'}));await pref(request('other','owner',{mode:'posts_replies'}));await pref(request('outsider','owner',{mode:'posts_replies'}));
      assert.equal((await profile()).viewer_post_notifications,'posts');
      notifications.length=0;
      const parent=await make({text:'Hello @viewer'});
      assert.deepEqual(notifications.map(n=>[n.userId,n.kind]).sort(),[['other','post'],['viewer','mention']]);
      notifications.length=0;
      await make({text:'A normal reply',replyToId:parent});
      assert.deepEqual(notifications.map(n=>[n.userId,n.kind]),[['other','post']]);
      notifications.length=0;await make({text:'Private update',visibility:'private'});assert.equal(notifications.length,0);
      await pref(request('viewer','owner',{mode:'none'}));assert.equal((await profile()).viewer_post_notifications,'none');
    });

    await t.test('following rows include viewer state; blocked rows and targets are hidden',async()=>{
      const result=await social.get('get /v1/users/:handle/followers')(request('viewer','owner'));
      assert.equal(result.items.find(p=>p.id==='other').viewer_following,false);
      await pg.exec(`insert into blocks(blocker_id,blocked_id) values('viewer','blocked');`);
      const filtered=await social.get('get /v1/users/:handle/followers')(request('viewer','owner'));
      assert.equal(filtered.items.some(p=>p.id==='blocked'),false);
      await assert.rejects(()=>social.get('get /v1/users/:handle/followers')(request('viewer','blocked')),deny404);
      const results=await search.get('get /v1/search')({user:user('viewer'),query:{q:'blocked'}});
      assert.equal(results.people.length,0);
      await assert.rejects(()=>social.get('put /v1/me/close-friends/:userId')(request('viewer','blocked')),deny404);
    });

    await t.test('notification insertion and unread counts suppress blocked and pending conversations',async()=>{
      const source=fs.readFileSync(path.join(root,'backend/src/lib/notify.js'),'utf8');
      const realNotify=new Function('db','publishToUsers',source.replace(/^import .*?;\n/gm,'').replace(/export /g,'')+';return notify;')(db,async()=>{});
      assert.equal(await realNotify({userId:'viewer',actorUserId:'blocked',kind:'follow'}),null);
      assert.ok(await realNotify({userId:'viewer',actorUserId:'other',kind:'follow'}));
      await pg.exec(`insert into notifications(user_id,actor_user_id,kind) values('viewer','blocked','follow');
        insert into conversations(id,request_status) values('accepted','accepted'),('pending','pending'),('blocked_chat','accepted');
        insert into conversation_members(conversation_id,user_id) values('accepted','viewer'),('accepted','other'),('pending','viewer'),('pending','outsider'),('blocked_chat','viewer'),('blocked_chat','blocked');
        insert into messages(id,conversation_id,sender_id,text) values('msg_ok','accepted','other','hi'),('msg_pending','pending','outsider','hidden'),('msg_blocked','blocked_chat','blocked','hidden');`);
      const routes=await routesFor('notifications.js');
      const unread=await routes.get('get /v1/me/unread-counts')(request('viewer'));
      assert.deepEqual(unread,{notifications:1,messages:1});
      const list=await routes.get('get /v1/notifications')(request('viewer'));
      assert.equal(list.items.length,1);assert.equal(list.items[0].actor_user_id,'other');
    });

    await t.test('notification list, badge and ticker agree on blocked and request-state visibility',async()=>{
      await pg.exec(`delete from notifications where user_id='viewer';
        insert into user_ticker_preferences(user_id,categories) values('viewer',array['you']) on conflict(user_id) do update set categories=excluded.categories;
        insert into conversations(id,request_status) values('declined','declined');
        insert into conversation_members(conversation_id,user_id) values('declined','viewer'),('declined','other');
        insert into notifications(user_id,actor_user_id,kind,object_type,object_id,payload) values
          ('viewer','blocked','follow','user','blocked','{"text":"Blocked notification"}'),
          ('viewer','other','follow','user','other','{"text":"Follow"}'),
          ('viewer','other','message','conversation','accepted','{"text":"Accepted message"}'),
          ('viewer','outsider','message_request','conversation','pending','{"text":"Pending request"}'),
          ('viewer','outsider','message','conversation','pending','{"text":"Unapproved message"}'),
          ('viewer','other','message_request','conversation','declined','{"text":"Declined request"}'),
          ('viewer','other','message_request','conversation','blocked_chat','{"text":"Blocked conversation"}');`);
      const ticker=await routesFor('ticker.js');
      const result=await ticker.get('get /v1/ticker')(request('viewer'));
      assert.deepEqual(result.items.map(item=>item.text).sort(),['Accepted message','Follow','Pending request']);
      const routes=await routesFor('notifications.js');
      const list=await routes.get('get /v1/notifications')(request('viewer'));
      assert.deepEqual(list.items.map(item=>item.payload.text).sort(),['Accepted message','Follow','Pending request']);
      const unread=await routes.get('get /v1/me/unread-counts')(request('viewer'));
      assert.deepEqual(unread,{notifications:3,messages:1});
    });

    await t.test('blocking removes relationships and denies content and interactions in both directions',async()=>{
      await pg.exec(`insert into close_friends(user_id,friend_user_id) values('viewer','owner'),('owner','viewer');`);
      const post=await make({text:'Block target'}),viewerPost=await make({text:'Viewer post'},'viewer');
      await users.get('put /v1/users/:userId/block')(request('viewer','owner'));
      for(const [viewer,target,postId] of [['viewer','owner',post],['owner','viewer',viewerPost]]){
        await assert.rejects(()=>users.get('get /v1/users/:handle')(request(viewer,target)),deny404);
        await assert.rejects(()=>users.get('post /v1/users/:userId/follow')(request(viewer,target)),deny404);
        await assert.rejects(()=>posts.get('get /v1/posts/:id')(request(viewer,postId)),deny404);
        await assert.rejects(()=>posts.get('put /v1/posts/:id/like')(request(viewer,postId)),deny404);
        await assert.rejects(()=>make({text:'Reply after block',replyToId:postId},viewer),deny404);
        await assert.rejects(()=>make({text:'Quote after block',quotePostId:postId},viewer),deny404);
      }
      const counts=await pg.query(`select (select count(*)::int from follows where (follower_id='viewer' and followee_id='owner') or (follower_id='owner' and followee_id='viewer')) follows,
        (select count(*)::int from close_friends) friends,(select count(*)::int from user_post_notifications where user_id='viewer' and author_user_id='owner') subscriptions`);
      assert.deepEqual(counts.rows[0],{follows:0,friends:0,subscriptions:0});
      await users.get('delete /v1/users/:userId/block')(request('viewer','owner'));
      assert.equal((await profile()).viewer_following,false);
    });
  } finally {await pg.close()}
});
