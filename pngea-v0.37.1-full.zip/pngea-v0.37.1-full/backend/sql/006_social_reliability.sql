begin;

-- Stable direct-message identity: a 1:1 pair owns exactly one conversation.
alter table conversations add column if not exists direct_key text;

-- Merge any historical duplicate 1:1 conversations before adding the unique key.
with direct_conversations as (
  select c.id,c.created_at,string_agg(cm.user_id,':' order by cm.user_id) as pair_key
  from conversations c join conversation_members cm on cm.conversation_id=c.id and cm.left_at is null
  where c.title is null
  group by c.id,c.created_at
  having count(*)=2
), ranked as (
  select *,first_value(id) over(partition by pair_key order by created_at,id) keeper
  from direct_conversations
)
update messages m set conversation_id=r.keeper
from ranked r where m.conversation_id=r.id and r.id<>r.keeper;

-- Carry the latest read marker from duplicate memberships onto the keeper.
with direct_conversations as (
  select c.id,c.created_at,string_agg(cm.user_id,':' order by cm.user_id) as pair_key
  from conversations c join conversation_members cm on cm.conversation_id=c.id and cm.left_at is null
  where c.title is null group by c.id,c.created_at having count(*)=2
), ranked as (
  select *,first_value(id) over(partition by pair_key order by created_at,id) keeper from direct_conversations
), reads as (
  select r.pair_key,cm.user_id,max(cm.last_read_at) last_read_at
  from ranked r join conversation_members cm on cm.conversation_id=r.id
  group by r.pair_key,cm.user_id
), keepers as (
  select distinct pair_key,keeper from ranked
)
update conversation_members cm set last_read_at=greatest(coalesce(cm.last_read_at,'epoch'),coalesce(rd.last_read_at,'epoch'))
from keepers k join reads rd on rd.pair_key=k.pair_key
where cm.conversation_id=k.keeper and cm.user_id=rd.user_id;

with direct_conversations as (
  select c.id,c.created_at,string_agg(cm.user_id,':' order by cm.user_id) as pair_key
  from conversations c join conversation_members cm on cm.conversation_id=c.id and cm.left_at is null
  where c.title is null group by c.id,c.created_at having count(*)=2
), ranked as (
  select *,first_value(id) over(partition by pair_key order by created_at,id) keeper from direct_conversations
)
delete from conversations c using ranked r where c.id=r.id and r.id<>r.keeper;

with direct_conversations as (
  select c.id,string_agg(cm.user_id,':' order by cm.user_id) as pair_key
  from conversations c join conversation_members cm on cm.conversation_id=c.id and cm.left_at is null
  where c.title is null group by c.id having count(*)=2
)
update conversations c set direct_key=d.pair_key from direct_conversations d where c.id=d.id;

create unique index if not exists conversations_direct_key_uq on conversations(direct_key) where direct_key is not null;

-- Client retry/idempotency support for fast mobile message sends.
alter table messages add column if not exists client_id text;
create unique index if not exists messages_sender_client_uq on messages(conversation_id,sender_id,client_id) where client_id is not null;

-- Saved posts power the Saved library tab.
create table if not exists bookmarks(
  user_id text not null references users(id) on delete cascade,
  post_id text not null references posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,post_id)
);
create index if not exists bookmarks_user_time_idx on bookmarks(user_id,created_at desc);

-- Preserve renamed handles so old links/data-profile attributes continue to resolve.
create table if not exists profile_handle_aliases(
  handle text primary key,
  user_id text not null references users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create index if not exists profile_handle_aliases_user_idx on profile_handle_aliases(user_id,created_at desc);

-- Communities: intentionally small core. Membership and posts are real network data.
create table if not exists communities(
  id text primary key,
  slug text not null unique,
  name text not null,
  description text not null default '',
  owner_user_id text references users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists communities_updated_idx on communities(updated_at desc);

create table if not exists community_members(
  community_id text not null references communities(id) on delete cascade,
  user_id text not null references users(id) on delete cascade,
  role text not null default 'member' check(role in('owner','moderator','member')),
  joined_at timestamptz not null default now(),
  primary key(community_id,user_id)
);
create index if not exists community_members_user_idx on community_members(user_id,joined_at desc);

create table if not exists community_posts(
  community_id text not null references communities(id) on delete cascade,
  post_id text not null unique references posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(community_id,post_id)
);
create index if not exists community_posts_time_idx on community_posts(community_id,created_at desc);

commit;
