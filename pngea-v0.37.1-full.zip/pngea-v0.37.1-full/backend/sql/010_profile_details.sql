begin;

alter table profiles add column if not exists location text not null default '' check(char_length(location)<=120);
alter table profiles add column if not exists website text not null default '' check(char_length(website)<=2048);

commit;
