begin;

alter table profiles add column if not exists avatar_media_id text references media(id) on delete set null;
alter table profiles add column if not exists banner_media_id text references media(id) on delete set null;
alter table media add column if not exists edit_json jsonb not null default '{}'::jsonb;

create table if not exists user_history(
  id bigserial primary key,
  user_id text not null references users(id) on delete cascade,
  kind text not null,
  object_type text,
  object_id text,
  label text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists user_history_user_time_idx on user_history(user_id,created_at desc);
create index if not exists user_history_user_object_idx on user_history(user_id,kind,object_id,created_at desc);

commit;
