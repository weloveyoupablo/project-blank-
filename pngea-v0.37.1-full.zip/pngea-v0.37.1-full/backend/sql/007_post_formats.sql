begin;
alter table posts add column if not exists content_kind text not null default 'text' check (content_kind in ('text','gallery','longform'));
alter table posts add column if not exists title text not null default '';
create index if not exists posts_author_original_active_idx on posts(author_id) where deleted_at is null and reply_to_id is null;
commit;
