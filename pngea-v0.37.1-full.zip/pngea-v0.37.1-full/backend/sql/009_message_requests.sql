begin;

-- Existing conversations were already open to both members. Preserve those chats.
-- New conversations explicitly opt in to 'none' or 'accepted' in the API.
alter table conversations add column if not exists request_status text not null default 'accepted';
alter table conversations add column if not exists requester_id text references users(id) on delete set null;
alter table conversations drop constraint if exists conversations_request_status_check;
alter table conversations add constraint conversations_request_status_check check(request_status in('none','pending','accepted','declined'));
create index if not exists conversations_requests_idx on conversations(request_status,updated_at desc) where request_status in('pending','none');

-- A short lease permits polling fallback and works across realtime instances.
create table if not exists conversation_typing(
  conversation_id text not null,
  user_id text not null,
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default now()+interval '6 seconds',
  primary key(conversation_id,user_id),
  foreign key(conversation_id,user_id) references conversation_members(conversation_id,user_id) on delete cascade
);
create index if not exists conversation_typing_expiry_idx on conversation_typing(expires_at);

commit;
