begin;

-- Muting changes only the viewer's Home feed; following stays intact.
create table if not exists user_mutes(
  user_id text not null references users(id) on delete cascade,
  muted_user_id text not null references users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,muted_user_id),
  check(user_id<>muted_user_id)
);

create table if not exists user_post_notifications(
  user_id text not null references users(id) on delete cascade,
  author_user_id text not null references users(id) on delete cascade,
  mode text not null check(mode in('posts','posts_replies')),
  updated_at timestamptz not null default now(),
  primary key(user_id,author_user_id),
  check(user_id<>author_user_id)
);
create index if not exists user_post_notifications_author_idx on user_post_notifications(author_user_id,user_id);
create index if not exists blocks_blocked_idx on blocks(blocked_id,blocker_id);

commit;
