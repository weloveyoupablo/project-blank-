begin;
create table if not exists sports_scores(
  id text primary key,
  league text not null,
  home_team text not null,
  away_team text not null,
  home_score int,
  away_score int,
  state text not null check(state in('live','final','scheduled')),
  status_text text not null,
  scheduled_at timestamptz not null,
  observed_at timestamptz not null,
  expires_at timestamptz not null,
  url text not null,
  raw jsonb not null default '{}'
);
create index if not exists sports_scores_current_idx on sports_scores(expires_at,observed_at desc);
commit;
