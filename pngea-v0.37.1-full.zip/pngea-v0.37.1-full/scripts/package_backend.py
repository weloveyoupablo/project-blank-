"""Rebuild the companion archive without changing Render's extraction contract."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'pngea-v0.37.1-full.zip'
PREFIX = 'pngea-v0.37.1-full'
FILES = ['index.html', 'pngea-core.js', 'pngea-v0.40.8-basic-ui-fix.js',
         'pngea-v0.40.9-profile-weixin.js', 'manifest.webmanifest 2',
         'apple-touch-icon 2.png', 'icon-192 2.png', 'icon-512 2.png',
         'sw 2.js', 'recovery.html', 'PNGEA_RELIABILITY_REVIEW.md',
         'tests/browser_reliability.py', 'tests/postgres_formats.mjs', 'tests/fixtures/reel.mp4', 'scripts/package_backend.py']

with zipfile.ZipFile(OUT, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in FILES:
        archive.write(ROOT / name, f'{PREFIX}/{name}')
    for file in sorted((ROOT / 'backend').rglob('*')):
        relative = file.relative_to(ROOT)
        if not file.is_file() or any(part in {'node_modules', '.git', '__pycache__'} for part in relative.parts):
            continue
        if file.name == '.env':
            continue
        archive.write(file, f'{PREFIX}/{relative.as_posix()}')

print(f'{OUT.name}: {OUT.stat().st_size} bytes')
print(f'SHA256 {hashlib.sha256(OUT.read_bytes()).hexdigest()}')
