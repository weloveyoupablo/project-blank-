# PNGEA backend hotfix v0.40.1

Production compatibility hotfix for the GitHub Pages frontend + Render API split.

- Refresh credentials can now be returned and supplied explicitly as `refreshToken` in auth JSON payloads, while HttpOnly cookies remain supported. This avoids Safari/cross-site cookie failures between GitHub Pages and Render.
- Production refresh cookies default to `SameSite=None; Secure` when no explicit override is configured.
- Profile PATCH now supports changing `handle`/username atomically and returns `HANDLE_TAKEN` on collisions.
- Generic iOS media MIME types can be inferred from common image/video/audio extensions.
- Video upload URLs last 60 minutes; other media upload URLs last 30 minutes. Video playback URLs last 60 minutes to support range requests/seeking.
- Existing media worker behavior is retained: originals are verified and marked ready; transcoding/thumbnail generation remains future pipeline work.

No database migration is required for this hotfix.
