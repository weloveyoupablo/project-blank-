# PNGEA v0.39 — Editorial ticker intelligence

The ticker is no longer a flat chronological blend. It now applies an editorial hierarchy:

1. YOU / direct user events
2. Verified BREAKING news
3. Fresh LIVE events
4. Developing / top stories
5. Extreme and major market moves
6. Personally relevant news
7. Routine watched-market updates

Key changes:
- BREAKING requires corroboration or an official source at high importance.
- High-importance single-source stories are labeled DEVELOPING instead.
- Source trust is weighted by publisher.
- Routine analyst / price-target chatter is downweighted.
- Broad-index moves use tighter thresholds than individual equities.
- Personal symbol/topic relevance gets a meaningful boost without overpowering major global news.
- Category caps and run limits reduce repetitive ticker sequences.
- Expanded topic inference includes geopolitics, defense, entertainment, China, climate, health, energy, and crypto.
