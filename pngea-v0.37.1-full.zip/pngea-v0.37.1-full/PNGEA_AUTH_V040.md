# PNGEA v0.40 — Accounts & Authentication

- Full-black authentication surface; no application content is visible behind sign-in.
- Sign in with email, phone number, username, or @username.
- Sign up with email and/or phone plus username/display name/password.
- Device account switcher in the sidebar via the person-plus icon.
- Add, switch, remove, and log out accounts without losing other saved accounts.
- Account-scoped HttpOnly refresh cookies support multiple signed-in accounts on one device.
- Refresh sessions use a 10-year sliding lifetime by default; normal inactivity does not log a user out.
- Email/phone verification challenge storage and delivery adapters are ready for Resend/Twilio.
- Live sidebar/profile counts come from the database; seeded counts and social activity were removed.
- Ticker crawl slowed from 36s to 108s.


## v0.40.5 device-session fallback
Static GitHub Pages and the Render API are cross-site in Safari, so PNGEA now also returns a rotating opaque device refresh credential to the client. The client stores it per account and uses it only to rotate sessions when the short-lived access token expires. Sessions remain server-revocable and retain the rolling 10-year inactivity window. Move this credential back to an HttpOnly same-site cookie when PNGEA ships behind a unified first-party domain.
