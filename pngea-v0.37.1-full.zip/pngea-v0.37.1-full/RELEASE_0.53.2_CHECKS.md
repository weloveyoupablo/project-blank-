# PNGEA 0.53.2 verification

The repository and all 89 entries of the previous companion ZIP were inspected and matched before implementation. Baseline: 61 focused browser cases and all 64 existing backend tests passed before changes.

## Release checks

207 unique browser cases were validated across the complete run and targeted reruns. The two complete groups initially passed 202 of 206 cases. Three older checks assumed no Home button, a one-step gallery exit, or a disconnected WebSocket retained in state; their expectations/fixture were updated for the requested Refresh/Back behavior and proper socket cleanup, then all six relevant cases passed. The remaining check caught voice-only posts entering the word-reply composer; the routing predicate was corrected to retain the voice waveform and inline replies. All 19 final word/voice/actual-upload checks passed, including a new voice compatibility regression. No unrelated broad suite was repeated.

All 80 backend tests passed. PostgreSQL applied migrations 001–011 and passed post formats, counts, following feeds, saved state, deletion, History and audience-safe mention checks. JavaScript syntax and git diff checks passed.

Focused checks already cover the real word-reply publisher, 280 Unicode code-point boundaries and overflow, audience/draft persistence, subpage Back navigation, intrinsic video proportions and fullscreen black margins, profile metadata/counts, Saved gallery, chat heads, message long-press exclusivity, keyboard geometry, working startup Retry, background-loading isolation and full-response cancellation.

## Real media path

The integration test uses actual browser File selection and XHR, the production AWS SDK presigner, checksum-validating local HTTP storage, production Fastify route bodies, validation and PostgreSQL. It verifies actual post creation, saved visibility, a following viewer's timeline, playback and seeking. Upload, completion and post creation are not replaced with canned success responses.

The previous 0.53.1 release was verified with an approved followers-only production upload and playback. The 0.53.2 frontend/backend changes are not deployed by this package's creation. Production data is not seeded by tests or migrations.

## Ticker sources and scores

Readonly live checks confirmed valid feeds for NBC News, MS NOW, NPR, ESPN, Sports Illustrated, CBS Sports, Yahoo Sports, NCAA football and MLB, plus the ESPN NFL scoreboard. Other approved publishers may use verified publisher RSS fallbacks; unavailable or unresolved entries are omitted.

Backend checks cover the publisher allowlist, deceptive host rejection, direct publisher links, headline freshness, live-score expiry, postponed/cancelled games, scheduled games without invented zero scores, stale scoreboard HTTP responses and ticker selection against actual PostgreSQL. The market allocation is capped against the requested ticker size; a short source pool can produce a shorter ticker.

## Practical limits

Keyboard and viewport behavior is exercised in Chromium using mobile viewport, resize, pan and touch-boundary cases. A physical iPhone Safari keyboard was not operated. Videos retain their uploaded codec; this release does not add a mandatory transcoder. Render Free cold starts and external publishers' page-loading times still exist; Retry restarts the connection and ticker taps no longer wait for application-side link resolution.

## Running the checks

Use PNGEA_TEST_MODULE_ROOT pointing to temporary test dependencies for backend/test/*.test.js and tests/postgres_formats.mjs. Start tests/live_backend_harness.mjs and set PNGEA_INTEGRATION_BASE to its printed local API URL for tests/test_video_integration.py. Browser modules are tests.browser_reliability plus all tests/test_*.py modules. Test data stays in isolated databases/storage.
