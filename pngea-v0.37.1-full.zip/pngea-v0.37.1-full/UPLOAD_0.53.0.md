# PNGEA 0.53.0

Unzip PNGEA-0.53.0.zip locally. Replace these four files at the root of the existing weloveyoupablo/project-blank- repository:

1. index.html
2. pngea-core.js
3. pngea-v0.40.8-basic-ui-fix.js
4. pngea-v0.37.1-full.zip — upload this file intact; do not unpack it into the repository.

The frontend and backend must both be updated for this release. Keep the existing Render Free service, archive name, build command and start command. The start command applies additive migrations 008_social_controls.sql and 009_message_requests.sql. No paid service is required.

After GitHub Pages publishes and Render finishes its deployment, open:
https://weloveyoupablo.github.io/project-blank-/?v=5301

Expected frontend build: 0.53.0-social-messaging.
Expected https://pngea-api-production.onrender.com/health version: 0.53.0.

This bundle adds caption editing for media posts, explicit drafts, reliable video completion, chat previews and return navigation, typing indicators, message requests, profile sharing/notifications/mute/block, follow controls in connection lists, compact Close Friends controls, photo comment sheets, and avatar/banner cropping. Text bubbles remain uneditable. Delete remains available from both post menus.

Approved news sources are Al Jazeera English, CNN, MSNBC, AP, Bloomberg and Reuters. Headlines refresh every two hours; the ticker rotates news, available notifications and real market data. Missing news or market data is never replaced with invented content. US time starts with Eastern and rotates through the other US zones with daylight-saving rules.

Historical conversations retain their accepted status. New nonmutual conversations require a request; mutual followers can chat directly. Blocking prevents both directions of interaction and discovery; muting only removes that account from Home. Account post notifications require following the account.

Videos publish after object-storage size verification; optional metadata inspection runs in the background and recovers abandoned jobs. Playback uses the original uploaded codec. Render Free can still cold-start, and this release does not add a paid video transcoder. Browser viewport/gesture tests cannot operate a physical iPhone keyboard.

The included backend archive contains the full source, migrations and regression tests. Roll back by restoring the previous frontend files and backend archive; leave the additive database migrations in place.
