# GitHub sync note

This v0.37.1 package is ready for the current `weloveyoupablo/project-blank-` repository state.

For this manual fallback package only, `index.html` points to the repository's existing legacy PWA files:
- `manifest.webmanifest 2`
- `apple-touch-icon 2.png`
- `sw 2.js`

This avoids breaking the deployed PWA while the ChatGPT GitHub connector is read-capable but write-blocked by GitHub with HTTP 403.

When connector write access works, normalize these to:
- `manifest.webmanifest`
- `apple-touch-icon.png`
- `icon-192.png`
- `icon-512.png`
- `sw.js`

Then remove the old ` 2` files.

- Routing correction: the persistent top-left avatar opens the sidebar; the sidebar identity header opens your Profile.
