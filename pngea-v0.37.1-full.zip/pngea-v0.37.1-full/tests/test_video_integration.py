"""Drive the actual app through real HTTP routes, signing, storage and PostgreSQL."""
import json
import os
import unittest
import urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = os.environ.get('PNGEA_INTEGRATION_BASE', '').rstrip('/')


@unittest.skipUnless(BASE, 'Start tests/live_backend_harness.mjs and set PNGEA_INTEGRATION_BASE')
class VideoIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()

    def data(self, path, user=None):
        request = urllib.request.Request(BASE + path, headers={'X-PNGEA-Test-User': user} if user else {})
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.load(response)

    def test_gallery_file_publishes_to_real_storage_and_followers_reel(self):
        before = self.data('/__test/state')
        context = self.browser.new_context(viewport=dict(width=390, height=844))
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        try:
            page.goto(BASE + '/', wait_until='domcontentloaded')
            page.wait_for_function("window.PNGEA_LIVE?.state.active&&document.documentElement.dataset.session==='signed-in'")
            page.locator('#compose').click()
            with page.expect_file_chooser() as chooser:
                page.locator('#composerLayer [data-attach="gallery"]').click()
            chooser.value.set_files(str(Path(__file__).parent / 'fixtures' / 'reel.mp4'))
            self.assertEqual(page.locator('#send').inner_text(), 'Next')
            page.locator('#send').click()
            page.locator('#postText').fill('Actual HTTP video integration')
            page.locator('#pngeaPhotoAudience').select_option('followers')
            page.locator('#send').click()
            page.wait_for_selector('#pngeaPostPage.show #pngeaPostBody video', timeout=20000)
            page.wait_for_function("document.querySelector('#pngeaPostBody video').readyState>=2", timeout=15000)
            saved_id = page.locator('#pngeaPostPage').get_attribute('data-post-id')
            self.assertTrue(saved_id)
            canonical = self.data('/v1/posts/' + saved_id)
            self.assertEqual(canonical['text'], 'Actual HTTP video integration')
            self.assertEqual(canonical['visibility'], 'followers')
            self.assertEqual(canonical['content_kind'], 'gallery')
            self.assertEqual(canonical['media'][0]['durationMs'], 2000)
            after = self.data('/__test/state')
            puts = [row for row in after['storageTrace'][len(before['storageTrace']):] if row['method'] == 'PUT']
            self.assertEqual(len(puts), 1)
            self.assertGreater(puts[0]['bytes'], 1000)
            self.assertTrue(puts[0]['validChecksum'])
            self.assertIsNone(puts[0]['signedCrc32'])
            self.assertEqual(len(after['posts']), len(before['posts']) + 1)
            self.assertNotIn(saved_id, [post['id'] for post in self.data('/v1/feed?limit=50')['items']])

            follower = self.browser.new_context(viewport=dict(width=390, height=844), extra_http_headers={'X-PNGEA-Test-User': 'usr_viewer'})
            try:
                viewing = follower.new_page()
                viewing.goto(BASE + '/', wait_until='domcontentloaded')
                card = viewing.locator('#feed [data-server-post="' + saved_id + '"]')
                card.wait_for(timeout=15000)
                viewing.wait_for_function("document.querySelector('#feed video')?.readyState>=2", timeout=15000)
                self.assertEqual(card.get_attribute('data-post-format'), 'reel')
                box = card.locator('.pngeaReelSlot').bounding_box()
                self.assertAlmostEqual(box['width'] / box['height'], 9 / 16, delta=.01)
                self.assertIn('Tester', card.locator('.pngeaCardHeader').inner_text())
                card.locator('video').click(position=dict(x=30, y=90))
                viewing.wait_for_selector('#pngeaMediaViewer.pngeaReelViewer.show')
                self.assertEqual(viewing.locator('.pngeaReelCaption').inner_text(), canonical['text'])
                self.assertEqual(viewing.locator('.pngeaReelActions [data-live-action]').count(), 5)
                viewing.wait_for_function("document.querySelector('#pngeaMediaViewer video').readyState>=2&&!document.querySelector('.pngeaReelSeek').disabled")
                if viewing.locator('.pngeaReelPlay').get_attribute('aria-label') == 'Pause':
                    viewing.locator('.pngeaReelPlay').click()
                seek = viewing.locator('.pngeaReelSeek')
                seek.evaluate("input=>{input.value='700';input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}))}")
                viewing.wait_for_function("Math.abs(document.querySelector('#pngeaMediaViewer video').currentTime-1.4)<.06", timeout=5000)
                seek.evaluate("input=>{input.value='200';input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}))}")
                viewing.wait_for_function("Math.abs(document.querySelector('#pngeaMediaViewer video').currentTime-.4)<.06", timeout=5000)
                self.assertEqual(errors, [])
            finally:
                follower.close()
        finally:
            context.close()


if __name__ == '__main__':
    unittest.main(verbosity=2)
