"""Startup retries and feed refresh without reloading the browser."""
import unittest
from urllib.parse import urlsplit
from . import browser_reliability as fixture
from . import test_session_recovery as session_fixture


class StartupRecovery(unittest.TestCase):
    setUpClass = classmethod(session_fixture.SessionRecovery.setUpClass.__func__)
    tearDownClass = classmethod(session_fixture.SessionRecovery.tearDownClass.__func__)
    open = session_fixture.SessionRecovery.open
    signed_in = session_fixture.SessionRecovery.signed_in
    resume = session_fixture.SessionRecovery.resume
    def setUp(self):
        self.hold_settings = False
        self.hold_next_me = False
        self.held_routes = []
        session_fixture.SessionRecovery.setUp(self)

    def route(self, route):
        parsed = urlsplit(route.request.url)
        if parsed.hostname == 'localhost' and parsed.port == 8787:
            if parsed.path == '/v1/me/settings' and self.hold_settings:
                self.held_routes.append(route)
                return
            if parsed.path == '/v1/me' and self.hold_next_me:
                self.hold_next_me = False
                self.held_routes.append(route)
                return
        session_fixture.SessionRecovery.route(self, route)

    def tearDown(self):
        for route in self.held_routes:
            try:
                route.fulfill(status=503, content_type='application/json', body='{}')
            except Exception:
                pass
        session_fixture.SessionRecovery.tearDown(self)

    def test_slow_background_settings_do_not_hold_the_authenticated_app(self):
        self.hold_settings = True
        self.open()
        self.page.wait_for_function("document.documentElement.dataset.session==='signed-in'", timeout=1800)
        self.page.wait_for_selector('#feed [data-server-post="pst_real"]', timeout=1800)
        self.assertFalse(self.page.locator('#pngeaSessionGate').is_visible())

    def test_retry_restarts_an_attempt_that_is_still_waiting_for_the_server(self):
        self.auth_mode = 'offline'
        self.open()
        self.page.wait_for_function("document.documentElement.dataset.session==='offline'")
        self.hold_next_me = True
        self.auth_mode = 'valid'
        self.page.evaluate('()=>{void window.PNGEA_LIVE.resume({validate:true})}')
        self.page.wait_for_timeout(150)
        self.assertTrue(self.held_routes)
        self.page.locator('#pngeaSessionRetry').click(timeout=1800)
        self.signed_in()
        self.assertFalse(self.page.locator('#pngeaSessionGate').is_visible())

    def test_startup_and_retry_use_the_same_screen_identity(self):
        self.auth_mode = 'offline'
        self.hold_next_me = True
        self.open()
        title = self.page.locator('#pngeaSessionTitle').inner_text()
        self.held_routes.pop().fulfill(status=503, content_type='application/json', body='{}')
        self.page.wait_for_function("document.documentElement.dataset.session==='offline'")
        self.assertEqual(self.page.locator('#pngeaSessionTitle').inner_text(), title)

    def test_expiry_discards_delayed_private_conversation_results(self):
        self.open()
        self.signed_in()
        self.page.evaluate("""()=>{
          window.PNGEA_API.conversations=()=>new Promise(resolve=>window.releasePrivateList=resolve);
          void window.PNGEA_LIVE.loadConversations();
        }""")
        self.page.wait_for_function('typeof window.releasePrivateList==="function"')
        self.page.evaluate("""()=>{
          window.dispatchEvent(new CustomEvent('pngea:session-expired'));
          window.releasePrivateList({items:[{id:'private_old_account',members:[{handle:'private',displayName:'Private old account'}]}]});
        }""")
        self.page.wait_for_timeout(100)
        self.assertEqual(self.page.locator('[data-live-conversation="private_old_account"]').count(), 0)
        self.assertEqual(self.page.evaluate('window.PNGEA_LIVE.state.conversations.length'), 0)

    def test_expiry_discards_a_delayed_websocket_ticket(self):
        self.open()
        self.signed_in()
        self.page.evaluate("""()=>{
          const live=window.PNGEA_LIVE.state;live.ws?.close();live.ws=null;live.realtimeReady=false;
          window.PNGEA_API.realtimeTicket=()=>new Promise(resolve=>window.releasePrivateTicket=resolve);
          void window.PNGEA_LIVE.resume({validate:true});
        }""")
        self.page.wait_for_function('typeof window.releasePrivateTicket==="function"')
        self.page.evaluate("""()=>{
          window.dispatchEvent(new CustomEvent('pngea:session-expired'));
          window.releasePrivateTicket({ticket:'old-account-ticket'});
        }""")
        self.page.wait_for_timeout(100)
        self.assertTrue(self.page.evaluate('window.PNGEA_LIVE.state.ws===null'))

    def test_expiry_covers_an_open_word_reply_with_sign_in(self):
        self.open()
        self.signed_in()
        self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_selector('#composerLayer.pngeaWordReply.show')
        self.page.evaluate("window.dispatchEvent(new CustomEvent('pngea:session-expired'))")
        self.assertTrue(self.page.locator('#pngeaLiveAuth.show').is_visible())
        self.assertFalse(self.page.locator('#composerLayer').is_visible())


class FeedRefresh(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp = fixture.Reliability.setUp
    tearDown = fixture.Reliability.tearDown
    route = fixture.Reliability.route

    def test_refresh_loads_the_new_feed_without_navigating(self):
        url = self.page.url
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>({items:[{id:'pst_new',author_id:'usr_other',handle:'other',text:'A newly refreshed post',media:[]}]})}")
        self.page.locator('#pngeaFeedRefresh').click(timeout=1800)
        self.page.wait_for_selector('#feed [data-server-post="pst_new"]')
        self.assertEqual(self.page.url, url)
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_real"]').count(), 0)

    def test_failed_refresh_retains_the_feed_and_allows_another_attempt(self):
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>{throw new Error('Temporary connection failure')}}")
        self.page.locator('#pngeaFeedRefresh').click(timeout=1800)
        self.page.wait_for_function("!document.querySelector('#pngeaFeedRefresh').disabled")
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_real"]').count(), 1)
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>({items:[]})}")
        self.page.locator('#pngeaFeedRefresh').click()
        self.page.wait_for_function("!document.querySelector('#feed [data-server-post]')")
        self.assertIn('Your following feed is quiet', self.page.locator('#feed').inner_text())

    def test_pull_refresh_only_acts_on_the_feed_at_the_top(self):
        self.page.evaluate("""()=>{
          window.pullRefreshCalls=0;
          window.PNGEA_API.feed=async()=>{window.pullRefreshCalls++;return {items:[]}};
          const feed=document.querySelector('#feed');feed.scrollTop=0;
          function gesture(type,y){const event=new Event(type,{bubbles:true,cancelable:true});Object.defineProperty(event,'touches',{value:type==='touchend'?[]:[{clientX:100,clientY:y}]});feed.dispatchEvent(event)}
          gesture('touchstart',100);gesture('touchmove',185);gesture('touchend',185);
        }""")
        self.page.wait_for_function('window.pullRefreshCalls===1')
        self.assertEqual(self.page.evaluate('window.scrollY'), 0)
        self.assertEqual(self.page.locator('#feed [data-server-post]').count(), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
