// Run with PNGEA_TEST_MODULE_ROOT pointing to a temporary npm install of
// @electric-sql/pglite and zod. This uses embedded PostgreSQL, never production.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const deps=process.env.PNGEA_TEST_MODULE_ROOT;
if(!deps)throw new Error('Set PNGEA_TEST_MODULE_ROOT to the temporary node_modules directory.');
const {PGlite}=await import(`${deps}/@electric-sql/pglite/dist/index.js`);
const {pgcrypto}=await import(`${deps}/@electric-sql/pglite/dist/contrib/pgcrypto.js`);
const {z}=await import(`${deps}/zod/index.js`);
const pg=new PGlite({extensions:{pgcrypto}});
class ApiError extends Error{constructor(statusCode,code,message){super(message);Object.assign(this,{statusCode,code})}}
const db={query:async(sql,args)=>{const result=await pg.query(sql,args);return {...result,rowCount:result.affectedRows??result.rows.length}}};
const tx=fn=>pg.transaction(async c=>fn({query:async(sql,args)=>{const result=await c.query(sql,args);return {...result,rowCount:result.affectedRows??result.rows.length}}}));
let seq=0;
async function routesFor(file){const source=fs.readFileSync(path.join(root,'backend/src/modules',file),'utf8'),name=source.match(/export async function (\w+)/)[1],routes=new Map(),app={authenticate(){},optionalAuth(){}};for(const method of ['get','post','put','delete','patch'])app[method]=(url,opts,handler)=>routes.set(`${method} ${url}`,handler);const context={z,db,tx,ApiError,opaqueId:()=>`test_${++seq}`,audit:async()=>{},notify:async()=>{},publishGlobal:async()=>{},publishToUsers:async()=>{},fetchVisiblePost:async()=>({id:'unused'})};await new Function(...Object.keys(context),source.replace(/^import .*?;\n/gm,'').replace(/export \{[^}]+\};/g,'').replace(/export /g,'')+`;return ${name};`)(...Object.values(context))(app);return routes}
const reply=()=>({status:200,body:null,code(n){this.status=n;return this},send(b){this.body=b;return this}});
try{
 for(const file of fs.readdirSync(path.join(root,'backend/sql')).filter(f=>f.endsWith('.sql')).sort()){await pg.exec(fs.readFileSync(path.join(root,'backend/sql',file),'utf8'));console.log('Applied',file)}
 // The additive migration is safe to rerun and preserves historical text posts.
 await pg.exec(fs.readFileSync(path.join(root,'backend/sql/007_post_formats.sql'),'utf8'));
 await pg.exec(`insert into users(id,email,password_hash) values('usr_self','self@example.test','test'),('usr_other','other@example.test','test');insert into profiles(user_id,handle,display_name) values('usr_self','tester','Tester'),('usr_other','other','Other');insert into posts(id,author_id,text,visibility) values('pst_old','usr_self','Historical text','public');`);
 const posts=await routesFor('posts.js'),users=await routesFor('users.js'),feed=await routesFor('feed.js'),social=await routesFor('social.js');
 const make=async body=>{const response=reply();await posts.get('post /v1/posts')({user:{sub:'usr_self'},body:{text:'Example',visibility:'public',mediaIds:[],...body}},response);assert.equal(response.status,201);return response.body.id};
 const gallery=await make({contentKind:'gallery',text:'Caption'}),long=await make({contentKind:'longform',title:'Long-form title',text:'word '.repeat(8000)});
 await assert.rejects(()=>make({contentKind:'longform',title:''}),e=>e instanceof z.ZodError);
 const longPost=await posts.get('get /v1/posts/:id')({user:{sub:'usr_self'},params:{id:long}});assert.equal(longPost.title,'Long-form title');assert.equal(longPost.content_kind,'longform');assert.ok(longPost.text.length>20000);
 const old=await posts.get('get /v1/posts/:id')({user:{sub:'usr_self'},params:{id:'pst_old'}});assert.equal(old.content_kind,'text');
 const home=await feed.get('get /v1/feed')({user:{sub:'usr_self'},query:{limit:50}});assert.equal(home.items.find(p=>p.id===gallery).content_kind,'gallery');assert.equal(home.items.find(p=>p.id===long).title,'Long-form title');assert.equal(home.items.find(p=>p.id===long).text,'');
 let profile=await users.get('get /v1/users/:handle')({user:{sub:'usr_self'},params:{handle:'tester'}});assert.equal(profile.posts_count,3);
 await make({replyToId:'pst_old',text:'A reply'});
 profile=await users.get('get /v1/users/:handle')({user:{sub:'usr_self'},params:{handle:'tester'}});assert.equal(profile.posts_count,3);
 const denied=posts.get('delete /v1/posts/:id');await assert.rejects(()=>denied({user:{sub:'usr_other'},params:{id:gallery}}),e=>e.statusCode===404);
 await denied({user:{sub:'usr_self'},params:{id:gallery}});
 profile=await users.get('get /v1/users/:handle')({user:{sub:'usr_self'},params:{handle:'tester'}});assert.equal(profile.posts_count,2);
 await social.get('put /v1/posts/:id/bookmark')({user:{sub:'usr_self'},params:{id:long}});
 const library=await social.get('get /v1/me/library')({user:{sub:'usr_self'},query:{tab:'saved'}});assert.equal(library.items[0].title,'Long-form title');
 console.log('PASS: migrations, format persistence, long-form validation, visibility, counts, deletion, feed and library SQL.');
}finally{await pg.close()}
