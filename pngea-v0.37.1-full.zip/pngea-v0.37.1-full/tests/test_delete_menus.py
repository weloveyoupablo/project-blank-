"""Delete actions on real timeline/detail menu surfaces, using isolated API fixtures."""
import unittest
try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture


class DeleteMenus(unittest.TestCase):
    setUpClass=classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass=classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp=fixture.Reliability.setUp
    tearDown=fixture.Reliability.tearDown
    route=fixture.Reliability.route
    navigate=fixture.Reliability.navigate

    def own_post(self):
        self.page.evaluate("""()=>{
            const post={id:'pst_mine',author_id:'usr_self',handle:'tester',display_name:'Tester',text:'My deletable post',media:[]};
            window.deletedPosts=[];
            window.PNGEA_API.feed=async()=>({items:window.deletedPosts.length?[]:[post]});
            window.PNGEA_API.myPosts=async()=>({items:window.deletedPosts.length?[]:[post]});
            window.PNGEA_API.post=async()=>post;
            window.PNGEA_API.postReplies=async()=>({items:[]});
            window.PNGEA_API.deletePost=async id=>{window.deletedPosts.push(id);return {ok:true}};
        }""")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.page.wait_for_selector('#feed [data-server-post="pst_mine"]')

    def test_post_page_three_dots_delete_removes_all_rendered_copies(self):
        self.own_post()
        self.navigate('Profile','tester')
        self.page.wait_for_selector('#p-posts [data-server-post="pst_mine"]')
        self.navigate('Home')
        self.page.locator('#feed .xPostText').click()
        self.page.locator('#pngeaPostBody .more').click()
        self.page.locator('[data-pngea516-action="delete"]').click()
        self.page.wait_for_function("window.deletedPosts[0]==='pst_mine'")
        self.page.wait_for_function("!document.querySelector('#pngeaPostPage').classList.contains('show')")
        self.assertEqual(self.page.locator('[data-server-post="pst_mine"]').count(),0)

    def test_post_page_three_dots_cannot_delete_another_users_post(self):
        self.page.locator('#feed .xPostText').first.click()
        self.page.locator('#pngeaPostBody .more').click()
        self.assertTrue(self.page.locator('#pnActionSheet').is_visible())
        self.assertEqual(self.page.locator('[data-pngea516-action="delete"]').count(),0)

    def test_failed_delete_keeps_post_and_can_be_retried(self):
        self.own_post()
        self.page.evaluate("()=>{window.PNGEA_API.deletePost=async()=>{throw new Error('Delete failed')}}")
        self.page.locator('#feed .more').click()
        self.page.locator('[data-pngea516-action="delete"]').click()
        self.page.wait_for_function("!document.querySelector('#pnActionSheet').classList.contains('show')")
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_mine"]').count(),1)
        self.page.evaluate("()=>{window.PNGEA_API.deletePost=async id=>{window.deletedPosts.push(id);return {ok:true}}}")
        self.page.locator('#feed .more').click()
        self.page.locator('[data-pngea516-action="delete"]').click()
        self.page.wait_for_function("window.deletedPosts[0]==='pst_mine'")
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_mine"]').count(),0)


if __name__=='__main__':unittest.main(verbosity=2)
