"""Canonical profile metadata/counts and the Saved gallery use local fixtures."""
import json
import unittest
from urllib.parse import parse_qs, unquote, urlsplit
try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture


class ProfileMetadataSaved(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    tearDown = fixture.Reliability.tearDown
    navigate = fixture.Reliability.navigate

    def setUp(self):
        self.server_me = dict(fixture.ME, location='Brooklyn, NY', website='https://pngea.example/', created_at='2024-03-01T00:00:00Z', joined_at='2024-03-01T00:00:00Z')
        self.server_other = dict(fixture.OTHER, location='Seattle, WA', website='https://other.example/', created_at='2025-09-11T14:00:00Z', joined_at='2025-09-11T14:00:00Z', viewer_following=False, following=5, followers=3)
        self.saved_items = []
        self.profile_updates = []
        self.media_reads = []
        fixture.Reliability.setUp(self)

    def route(self, route):
        parsed = urlsplit(route.request.url)
        path = unquote(parsed.path)
        if parsed.hostname != 'localhost' or parsed.port != 8787:
            return fixture.Reliability.route(self, route)
        data = None
        if path == '/v1/me':
            data = self.server_me
        elif path == '/v1/users/tester':
            data = self.server_me
        elif path == '/v1/users/other':
            data = self.server_other
        elif path == '/v1/me/profile' and route.request.method == 'PATCH':
            body = route.request.post_data_json
            self.profile_updates.append(body)
            for source, target in [('displayName', 'display_name'), ('handle', 'handle'), ('bio', 'bio'), ('location', 'location'), ('website', 'website')]:
                if source in body:
                    self.server_me[target] = body[source]
            website = self.server_me.get('website', '').strip()
            if website and '://' not in website:
                website = 'https://' + website
            if website and not urlsplit(website).path:
                website += '/'
            self.server_me['website'] = website
            data = self.server_me
        elif path == '/v1/users/usr_other/follow':
            following = route.request.method == 'POST'
            if self.server_other['viewer_following'] != following:
                self.server_me['following'] += 1 if following else -1
                self.server_other['followers'] += 1 if following else -1
            self.server_other['viewer_following'] = following
            data = dict(following=following, counts=[dict(userId=self.server_me['id'], following=self.server_me['following'], followers=self.server_me['followers']), dict(userId=self.server_other['id'], following=self.server_other['following'], followers=self.server_other['followers'])])
        elif path == '/v1/me/library':
            tab = parse_qs(parsed.query).get('tab', ['saved'])[0]
            data = dict(items=self.saved_items if tab == 'saved' else [fixture.POST])
        elif path.startswith('/v1/media/') and path.endswith('/access'):
            media_id = path.split('/')[3]
            self.media_reads.append(media_id)
            video = media_id == 'saved_video_media'
            data = dict(url='http://localhost/tests/fixtures/reel.mp4' if video else 'http://localhost/saved-thumb.svg', mimeType='video/mp4' if video else 'image/svg+xml')
        elif path.startswith('/v1/posts/') and not path.endswith('/replies'):
            data = next((post for post in self.saved_items if post['id'] == path.split('/')[3]), None)
        if data is None:
            return fixture.Reliability.route(self, route)
        self.requests.append((route.request.method, path))
        route.fulfill(status=200, content_type='application/json', body=json.dumps(data))

    def prepare_saved(self):
        def post(post_id, **values):
            return dict(fixture.POST, **dict(id=post_id, viewer_saved=True, **values))
        self.saved_items = [
            post('saved_photo', content_kind='gallery', text='Photo caption', media=[dict(id='saved_photo_media', mimeType='image/png')]),
            post('saved_video', content_kind='gallery', text='Video caption', media=[dict(id='saved_video_media', mimeType='video/mp4', durationMs=30000)]),
            post('saved_word_image', content_kind='text', text='Words come first with an attached photo', media=[dict(id='saved_word_image_media', mimeType='image/png')]),
            post('saved_words', content_kind='text', text='A plain word post', media=[]),
            post('saved_longform', content_kind='longform', title='A longer essay title', text='', media=[]),
            post('saved_voice', content_kind='text', text='A voice post caption', media=[dict(id='saved_voice_media', mimeType='audio/webm')]),
        ]
        self.navigate('History')
        self.page.wait_for_selector('[data-saved-post="saved_photo"] img')

    def test_profile_fields_show_real_metadata_and_persist_through_edit_reopen(self):
        self.navigate('Profile', 'tester')
        self.assertEqual(self.page.locator('.pngeaProfileLocation').inner_text(), 'Brooklyn, NY')
        self.assertEqual(self.page.locator('.pngeaProfileWebsite').get_attribute('href'), 'https://pngea.example/')
        self.assertEqual(self.page.locator('.pngeaProfileJoined').inner_text(), 'Joined March 2024')
        self.assertEqual(self.page.locator('#pngeaProfileMessage svg').count(), 0)
        self.page.evaluate("()=>{window.PNGEA.state.user.location='Stale local location';window.PNGEA.state.user.website='https://stale.example/'}")
        self.page.locator('#Profile .profileEdit').click()
        self.assertEqual(self.page.locator('#peLocation').input_value(), 'Brooklyn, NY')
        self.assertEqual(self.page.locator('#peWebsite').input_value(), 'https://pngea.example/')
        self.page.locator('#peLocation').fill('Queens, NY')
        self.page.locator('#peWebsite').fill('new.example/portfolio')
        self.page.locator('#profileEditSave').click()
        self.page.wait_for_function("!document.querySelector('#profileEditLayer').classList.contains('show')")
        self.assertEqual(self.profile_updates[-1]['location'], 'Queens, NY')
        self.assertEqual(self.profile_updates[-1]['website'], 'new.example/portfolio')
        self.assertEqual(self.page.locator('.pngeaProfileWebsite').get_attribute('href'), 'https://new.example/portfolio')
        self.navigate('Home'); self.navigate('Profile', 'tester')
        self.assertEqual(self.page.locator('.pngeaProfileLocation').inner_text(), 'Queens, NY')
        self.page.locator('#Profile .profileEdit').click()
        self.assertEqual(self.page.locator('#peWebsite').input_value(), 'https://new.example/portfolio')

    def test_profile_link_occupies_missing_location_and_rejects_unsafe_schemes(self):
        self.server_me['location'] = ''
        self.navigate('Profile', 'tester')
        self.assertEqual(self.page.locator('.pngeaProfileLocation').count(), 0)
        self.assertEqual(self.page.locator('.pngeaProfileMetaRow').inner_text(), 'pngea.example')
        self.assertEqual(self.page.locator('.pngeaProfileJoined').inner_text(), 'Joined March 2024')
        for glyph in ['◎', '⌁', '◷']:
            self.assertNotIn(glyph, self.page.locator('#Profile .profileMeta').inner_text())
        self.server_me['website'] = 'javascript:alert(1)'
        self.page.evaluate("window.PNGEA_CORE.loadProfile('tester')")
        self.assertEqual(self.page.locator('.pngeaProfileWebsite').count(), 0)

    def test_sidebar_and_profile_follow_counts_follow_canonical_snapshots(self):
        self.server_me.update(following=4, followers=7)
        self.navigate('Profile', 'tester')
        self.assertEqual(self.page.locator('#sideFollowing').inner_text(), '4')
        self.assertEqual(self.page.locator('#sideFollowers').inner_text(), '7')
        self.navigate('Profile', 'other')
        self.page.locator('#Profile .profileEdit').click()
        self.page.wait_for_function("document.querySelector('#sideFollowing').textContent==='5'")
        self.assertEqual(self.page.locator('#Profile .profileStats b').nth(1).inner_text(), '4')
        self.server_me.update(following=8, followers=9)
        self.page.evaluate("()=>window.dispatchEvent(new CustomEvent('pngea:realtime',{detail:{type:'social.updated',data:{counts:[{userId:'usr_self',following:8,followers:9}]}}}))")
        self.assertEqual(self.page.locator('#sideFollowing').inner_text(), '8')
        self.assertEqual(self.page.locator('#sideFollowers').inner_text(), '9')
        self.page.locator('#Profile .profileEdit').click()
        self.page.wait_for_function("document.querySelector('#sideFollowing').textContent==='7'")
        self.navigate('Profile', 'tester')
        self.assertEqual(self.page.locator('#Profile .profileStats b').all_text_contents(), ['7', '9'])
        self.assertEqual(self.page.locator('#sideFollowing').inner_text(), '7')

    def test_saved_gallery_has_square_tiles_for_all_formats_without_word_media(self):
        self.prepare_saved()
        self.assertEqual(self.page.locator('.pngeaSavedTile').count(), 6)
        self.assertEqual(self.page.locator('[data-saved-post="saved_video"] video').count(), 1)
        for tile in self.page.locator('.pngeaSavedTile').all():
            box = tile.bounding_box()
            self.assertAlmostEqual(box['width'], box['height'], delta=1)
        self.assertIn('Words come first', self.page.locator('[data-saved-post="saved_word_image"]').inner_text())
        self.assertEqual(self.page.locator('[data-saved-post="saved_word_image"] img,[data-saved-post="saved_word_image"] video').count(), 0)
        self.assertNotIn('saved_word_image_media', self.media_reads)
        self.assertNotIn('saved_voice_media', self.media_reads)
        self.assertIn('A longer essay title', self.page.locator('[data-saved-post="saved_longform"]').inner_text())

    def test_saved_word_tile_opens_complete_post_and_back_returns_to_gallery(self):
        self.prepare_saved()
        self.page.locator('[data-saved-post="saved_word_image"]').click()
        self.page.wait_for_selector('#pngeaPostBody .pngeaDetailMedia img')
        self.assertIn('saved_word_image_media', self.media_reads)
        self.assertIn('Words come first with an attached photo', self.page.locator('#pngeaPostBody').inner_text())
        self.page.locator('#pngeaPostBack').click()
        self.page.wait_for_selector('[data-saved-post="saved_word_image"]')
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'), 'History')
        self.assertEqual(self.page.locator('.pngeaSavedTile').count(), 6)

    def test_other_history_tabs_keep_regular_post_layouts(self):
        self.prepare_saved()
        self.page.locator('[data-library-tab="likes"]').click()
        self.page.wait_for_selector('.pngeaLibraryList [data-server-post="pst_real"]')
        self.assertEqual(self.page.locator('.pngeaSavedGrid').count(), 0)
        self.assertGreater(self.page.locator('.pngeaLibraryList [data-live-action]').count(), 0)
        self.page.locator('[data-library-tab="activity"]').click()
        self.assertEqual(self.page.locator('#pngeaActivityHistory').count(), 1)
        self.page.locator('[data-library-tab="saved"]').click()
        self.page.wait_for_selector('.pngeaSavedGrid [data-saved-post]')
        self.assertEqual(self.page.locator('.pngeaSavedTile').count(), 6)


if __name__ == '__main__':
    unittest.main(verbosity=2)
