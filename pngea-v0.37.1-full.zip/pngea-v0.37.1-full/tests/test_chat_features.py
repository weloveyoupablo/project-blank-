"""Real chat render/navigation/request flows with isolated API fixtures."""
import unittest
try:
    from . import browser_reliability as fixtures
except ImportError:
    import browser_reliability as fixtures


class ChatFeatures(unittest.TestCase):
    setUpClass = classmethod(fixtures.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixtures.Reliability.tearDownClass.__func__)
    setUp = fixtures.Reliability.setUp
    tearDown = fixtures.Reliability.tearDown
    route = fixtures.Reliability.route
    navigate = fixtures.Reliability.navigate

    def messages(self, text, **metadata):
        self.page.evaluate("""([text,metadata])=>{
          window.PNGEA_API.messages=async()=>({items:[{id:'msg_share',sender_id:'usr_other',text,media:[]}],...metadata});
        }""", [text, metadata])

    def gate(self, status, requester='usr_self'):
        self.page.evaluate("""([status,requester])=>{
          window.gateState={request_status:status,requester_id:requester,viewer_can_message:status==='accepted'};
          window.PNGEA_LIVE.state.conversations.find(c=>c.id==='cnv_a').request_status=status;
          window.PNGEA_API.messages=async()=>({items:[],...window.gateState});
        }""", [status, requester])
        self.navigate('Inbox', 'cnv_a')

    def event(self, kind, data):
        self.page.evaluate("([type,data])=>window.dispatchEvent(new CustomEvent('pngea:realtime',{detail:{type,data}}))", [kind, data])

    def test_shared_post_has_compact_actual_caption_and_media(self):
        self.messages('http://localhost/#/post/pst_real')
        self.page.evaluate("""()=>{
          window.PNGEA_API.post=async()=>({id:'pst_real',handle:'other',display_name:'Other',text:'Actual shared caption',media:[{id:'med_preview',mimeType:'image/png'}]});
          window.PNGEA_API.mediaAccess=async()=>({url:'http://localhost/preview.svg',mimeType:'image/png'});
        }""")
        self.navigate('Inbox', 'cnv_a')
        card = self.page.locator('.pngeaSharedPreview')
        self.assertIn('Actual shared caption', card.inner_text())
        self.assertIn('@other', card.inner_text())
        self.assertEqual(card.locator('.pngeaSharedPreviewMedia img').count(), 1)
        self.assertLess(card.bounding_box()['height'], 280)
        self.assertLessEqual(card.bounding_box()['width'], 230)

    def test_shared_post_back_restores_same_chat_draft_and_scroll(self):
        self.page.evaluate("""()=>{window.PNGEA_API.messages=async()=>({items:Array.from({length:40},(_,i)=>({id:'msg_'+i,sender_id:'usr_other',text:i===10?'http://localhost/#/post/pst_real':'Message '+i,media:[]}))})}""")
        self.navigate('Inbox', 'cnv_a')
        self.page.locator('#dmInput').fill('Keep my chat draft')
        self.page.locator('.pngeaSharedPreview').scroll_into_view_if_needed()
        scroll = self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop')
        self.page.locator('.pngeaSharedPreview').click()
        self.page.wait_for_function("document.querySelector('#pngeaPostPage').classList.contains('show')")
        self.page.locator('#pngeaPostBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Inbox'&&window.PNGEA.parseRoute().detail==='cnv_a'")
        self.assertEqual(self.page.locator('#dmInput').input_value(), 'Keep my chat draft')
        self.assertAlmostEqual(self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop'), scroll, delta=3)

    def test_profile_link_preview_opens_profile_and_back_to_chat(self):
        self.messages('http://localhost/#/profile/other')
        self.navigate('Inbox', 'cnv_a')
        self.assertIn('@other', self.page.locator('.pngeaSharedPreview').inner_text())
        self.page.locator('#dmInput').fill('Profile return draft')
        self.page.locator('.pngeaSharedPreview').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'")
        self.page.locator('#Profile .xTop .xBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().detail==='cnv_a'")
        self.assertEqual(self.page.locator('#dmInput').input_value(), 'Profile return draft')

    def test_post_author_profile_back_follows_nested_chat_path(self):
        self.messages('http://localhost/#/post/pst_real')
        self.navigate('Inbox', 'cnv_a')
        self.page.locator('#dmInput').fill('Nested return draft')
        self.page.locator('.pngeaSharedPreview').click()
        self.page.wait_for_function("document.querySelector('#pngeaPostBody .pngeaDetailAvatar')")
        self.page.locator('#pngeaPostBody .pngeaDetailAvatar').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'")
        self.page.locator('#Profile .xTop .xBack').click()
        self.page.wait_for_function("location.hash==='#/post/pst_real'&&document.querySelector('#pngeaPostPage').classList.contains('show')")
        self.page.wait_for_function("document.querySelector('#pngeaPostBody').textContent.includes('Real fixture post')")
        self.assertIn('Real fixture post', self.page.locator('#pngeaPostBody').inner_text())
        self.page.locator('#pngeaPostBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Inbox'&&window.PNGEA.parseRoute().detail==='cnv_a'")
        self.assertEqual(self.page.locator('#dmInput').input_value(), 'Nested return draft')

    def test_caption_editor_gesture_is_not_blocked_by_background_chat_lock(self):
        self.navigate('Inbox', 'cnv_a')
        prevented = self.page.evaluate("""()=>{
          document.querySelector('#pngeaCaptionEditor').classList.add('show');
          const target=document.querySelector('#pngeaCaptionText');
          const touch=y=>new Touch({identifier:1,target,clientX:100,clientY:y,pageX:100,pageY:y,screenX:100,screenY:y});
          target.dispatchEvent(new TouchEvent('touchstart',{bubbles:true,cancelable:true,touches:[touch(250)],changedTouches:[touch(250)]}));
          const move=new TouchEvent('touchmove',{bubbles:true,cancelable:true,touches:[touch(200)],changedTouches:[touch(200)]});
          target.dispatchEvent(move);return move.defaultPrevented;
        }""")
        self.assertFalse(prevented)

    def test_external_links_do_not_request_metadata(self):
        self.messages('https://example.com/#/profile/other')
        self.page.evaluate("()=>{window.previewCalls=0;window.PNGEA_API.getUser=async()=>{window.previewCalls++;throw new Error('Must not fetch')}}")
        self.navigate('Inbox', 'cnv_a')
        self.assertEqual(self.page.locator('.pngeaSharedPreview').count(), 0)
        self.assertEqual(self.page.evaluate('window.previewCalls'), 0)
        self.assertIn('https://example.com/', self.page.locator('#dmMessages').inner_text())

    def test_unavailable_post_preview_does_not_expose_cached_content(self):
        self.messages('http://localhost/#/post/private')
        self.page.evaluate("()=>{window.PNGEA_API.post=async()=>{throw new Error('Unavailable')}}")
        self.navigate('Inbox', 'cnv_a')
        self.assertEqual(self.page.locator('.pngeaSharedPreview').inner_text(), 'Post unavailable')
        self.assertTrue(self.page.locator('.pngeaSharedPreview').is_disabled())

    def test_typing_bubble_clears_on_stop_message_and_expiry(self):
        self.navigate('Inbox', 'cnv_a')
        self.page.evaluate("()=>{window.PNGEA_API.messages=async()=>({items:[]})}")
        def typing(milliseconds=5000):
            self.page.evaluate("ms=>window.dispatchEvent(new CustomEvent('pngea:realtime',{detail:{type:'conversation.typing',data:{conversationId:'cnv_a',userId:'usr_other',typing:true,expiresAt:new Date(Date.now()+ms).toISOString()}}}))", milliseconds)
        typing()
        self.assertEqual(self.page.locator('#pngeaDmTyping span').count(), 3)
        self.event('conversation.typing', dict(conversationId='cnv_a', userId='usr_other', typing=False))
        self.assertEqual(self.page.locator('#pngeaDmTyping').count(), 0)
        typing()
        self.event('message.created', dict(conversationId='cnv_a', senderId='usr_other'))
        self.assertEqual(self.page.locator('#pngeaDmTyping').count(), 0)
        typing(80)
        self.page.wait_for_function("!document.querySelector('#pngeaDmTyping')", timeout=1500)

    def test_outgoing_typing_is_throttled_and_cleared_on_leave(self):
        self.navigate('Inbox', 'cnv_a')
        self.page.evaluate("()=>{window.typingCalls=[];window.PNGEA_API.setConversationTyping=async(id,b)=>{window.typingCalls.push({id,...b});return{ok:true}}}")
        self.page.locator('#dmInput').focus()
        self.page.locator('#dmInput').fill('H')
        self.page.locator('#dmInput').fill('He')
        self.page.locator('#dmInput').fill('Hello')
        self.assertEqual(len(self.page.evaluate('window.typingCalls.filter(x=>x.typing)')), 1)
        self.navigate('Home')
        calls = self.page.evaluate('window.typingCalls')
        self.assertFalse(calls[-1]['typing'])
        self.assertEqual(calls[-1]['id'], 'cnv_a')

    def test_request_gate_then_waiting_state_hides_composer(self):
        self.gate('none')
        self.assertFalse(self.page.locator('.dmCompose').is_visible())
        self.assertEqual(self.page.locator('[data-dm-request="request"]').inner_text(), 'Request')
        self.assertEqual(self.page.locator('[data-dm-request="close"]').inner_text(), 'Close')
        self.page.evaluate("()=>{window.PNGEA_API.requestConversation=async()=>{window.gateState={request_status:'pending',requester_id:'usr_self',viewer_can_message:false};return window.gateState}}")
        self.page.locator('[data-dm-request="request"]').click()
        self.page.wait_for_function("document.querySelector('#pngeaDmRequestGate').textContent.includes('Waiting')")
        self.assertFalse(self.page.locator('.dmCompose').is_visible())
        self.assertEqual(self.page.locator('#pngeaDmRequestGate button').count(), 0)
        self.assertEqual(self.page.locator('#dmMessages').inner_text().strip(), '')

    def test_request_recipient_accepts_into_normal_chat(self):
        self.gate('pending', 'usr_other')
        self.page.evaluate("()=>{window.PNGEA_API.respondConversationRequest=async(id,b)=>{window.accepted=b.accept;window.gateState={request_status:'accepted',requester_id:'usr_other',viewer_can_message:true};return window.gateState}}")
        self.page.locator('[data-dm-request="accept"]').click()
        self.page.wait_for_function("!document.querySelector('.dmCompose').hidden")
        self.assertTrue(self.page.evaluate('window.accepted'))
        self.assertTrue(self.page.locator('#dmInput').is_visible())
        self.assertFalse(self.page.locator('#pngeaDmRequestGate').is_visible())

    def test_request_recipient_declines_and_chat_closes(self):
        self.gate('pending', 'usr_other')
        self.page.evaluate("()=>{window.PNGEA_API.respondConversationRequest=async()=>({request_status:'declined',viewer_can_message:false,requester_id:'usr_other'})}")
        self.page.locator('[data-dm-request="decline"]').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Inbox'&&!window.PNGEA.parseRoute().detail")
        self.assertFalse(self.page.locator('#dmThread').is_visible())

    def test_accepted_request_event_immediately_unlocks_requester(self):
        self.gate('pending')
        self.page.evaluate("()=>{window.gateState={request_status:'accepted',requester_id:'usr_self',viewer_can_message:true}}")
        self.event('conversation.request', dict(conversationId='cnv_a', request_status='accepted', requester_id='usr_self', viewer_can_message=True))
        self.page.wait_for_function("!document.querySelector('.dmCompose').hidden")
        self.assertTrue(self.page.locator('#dmInput').is_visible())

    def test_request_panel_remains_inside_locked_chat_frame(self):
        self.gate('none')
        self.assertTrue(self.page.locator('#pngeaDmRequestGate').evaluate('(e)=>e.parentElement.id==="dmThread"'))
        self.assertEqual(self.page.locator('#dmThread').evaluate('(e)=>getComputedStyle(e).position'), 'fixed')
        self.assertFalse(self.page.locator('#pngeaDmAttachments').is_visible())

    def test_chat_photos_align_with_the_senders_text_edge(self):
        self.page.evaluate("""()=>{
          window.PNGEA_API.messages=async()=>({items:[
            {id:'own_photo',sender_id:'usr_self',text:'Own photo',media:[{id:'image_own',mimeType:'image/png'}]},
            {id:'other_photo',sender_id:'usr_other',text:'Other photo',media:[{id:'image_other',mimeType:'image/png'}]}
          ]});
          window.PNGEA_API.mediaAccess=async id=>({url:'http://localhost/'+id+'.svg',mimeType:'image/png'});
        }""")
        self.navigate('Inbox', 'cnv_a')
        self.page.wait_for_function("document.querySelectorAll('#dmMessages .liveMessageMedia img').length===2&&[...document.querySelectorAll('#dmMessages .liveMessageMedia img')].every(i=>i.complete)")
        frame = self.page.locator('#dmMessages').bounding_box()
        own = self.page.locator('[data-message-id="own_photo"]')
        other = self.page.locator('[data-message-id="other_photo"]')
        own_image, own_text = own.locator('img').bounding_box(), own.locator('.msgBubble').bounding_box()
        other_image, other_text = other.locator('img').bounding_box(), other.locator('.msgBubble').bounding_box()
        self.assertAlmostEqual(own_image['x'] + own_image['width'], own_text['x'] + own_text['width'], delta=2)
        self.assertAlmostEqual(other_image['x'], other_text['x'], delta=2)
        self.assertLess(frame['x'] + frame['width'] - own_image['x'] - own_image['width'], 40)
        self.assertLess(other_image['x'] - frame['x'], 40)
        self.assertGreater(own_image['x'], other_image['x'] + other_image['width'])

    def test_inbox_uses_latest_text_media_fallback_and_message_timestamp(self):
        self.page.evaluate("""()=>{
          const base={members:[{id:'usr_other',handle:'other',displayName:'Other'}],last_message_at:'2026-10-13T12:00:00Z',updated_at:'2026-10-16T12:00:00Z'};
          window.PNGEA_API.conversations=async()=>({items:[
            {...base,id:'text_preview',last_message_id:'message_text',last_message:'Latest message',last_message_sender_id:'usr_self'},
            {...base,id:'photo_preview',last_message_id:'message_photo',last_message:'',last_message_sender_id:'usr_self',last_message_media:[{mimeType:'image/jpeg'}]},
            {...base,id:'video_preview',last_message_id:'message_video',last_message:'',last_message_media:[{mimeType:'video/mp4'}]},
            {...base,id:'voice_preview',last_message_id:'message_voice',last_message:'',last_message_media:[{mimeType:'audio/webm'}]},
            {...base,id:'legacy_preview',last_message:''},
            {id:'empty_preview',members:base.members,last_message:null,last_message_at:null,updated_at:base.updated_at}
          ]});
        }""")
        self.navigate('Inbox')
        self.page.evaluate('()=>window.PNGEA_LIVE.loadConversations()')
        expected = {'text_preview': 'You: Latest message', 'photo_preview': 'You: Photo',
                    'video_preview': 'Video', 'voice_preview': 'Voice message',
                    'legacy_preview': 'Attachment', 'empty_preview': 'No messages yet'}
        for conversation, preview in expected.items():
            row = self.page.locator('[data-live-conversation="'+conversation+'"]')
            self.assertEqual(row.locator('.dmPreview').inner_text(), preview)
            if conversation != 'empty_preview':
                self.assertEqual(row.locator('.dmTime').get_attribute('data-message-time'), '2026-10-13T12:00:00Z')
                self.assertTrue(row.locator('.dmTime').inner_text())

    def test_inbox_requests_filter_uses_canonical_pending_recipient_state(self):
        self.page.evaluate("""()=>{
          window.PNGEA_API.conversations=async()=>({items:[
            {id:'request_in',members:[],request_status:'pending',requester_id:'usr_other'},
            {id:'request_out',members:[],request_status:'pending',requester_id:'usr_self'},
            {id:'normal_chat',members:[],request_status:'accepted'}
          ]});window.PNGEA_MESSAGE_FILTER='requests';
        }""")
        self.navigate('Inbox')
        self.page.evaluate('()=>window.PNGEA_LIVE.loadConversations()')
        self.assertEqual(self.page.locator('#Inbox [data-live-conversation]').count(), 1)
        self.assertEqual(self.page.locator('#Inbox .dmPreview').inner_text(), 'Message request')


if __name__ == '__main__':
    unittest.main(verbosity=2)
