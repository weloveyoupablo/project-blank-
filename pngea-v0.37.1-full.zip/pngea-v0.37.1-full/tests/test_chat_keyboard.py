"""Chat viewport and return navigation regressions, using isolated API fixtures."""
import unittest
try:
    from . import browser_reliability as fixtures
except ImportError:
    import browser_reliability as fixtures


class ChatKeyboard(unittest.TestCase):
    setUpClass = classmethod(fixtures.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixtures.Reliability.tearDownClass.__func__)
    setUp = fixtures.Reliability.setUp
    tearDown = fixtures.Reliability.tearDown
    route = fixtures.Reliability.route
    navigate = fixtures.Reliability.navigate

    def open_keyboard(self, height=460, offset=0):
        self.page.evaluate("([height,offset])=>{Object.defineProperty(window.visualViewport,'height',{configurable:true,value:height});Object.defineProperty(window.visualViewport,'offsetTop',{configurable:true,value:offset});window.visualViewport.dispatchEvent(new Event('resize'))}", [height,offset])
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        self.page.wait_for_timeout(80)

    def touch_drag_prevented(self, selector, delta):
        """Exercise the cancelable native gesture path, not only resize handlers."""
        return self.page.locator(selector).evaluate("""(target,delta)=>{
          const touch=y=>new Touch({identifier:1,target,clientX:150,clientY:y,pageX:150,pageY:y,screenX:150,screenY:y});
          target.dispatchEvent(new TouchEvent('touchstart',{bubbles:true,cancelable:true,touches:[touch(250)],changedTouches:[touch(250)]}));
          const move=new TouchEvent('touchmove',{bubbles:true,cancelable:true,touches:[touch(250+delta)],changedTouches:[touch(250+delta)]});
          target.dispatchEvent(move);
          target.dispatchEvent(new TouchEvent('touchend',{bubbles:true,cancelable:true,touches:[],changedTouches:[touch(250+delta)]}));
          return move.defaultPrevented;
        }""", delta)

    def test_header_drag_cannot_pan_the_chat_while_typing(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        header=self.page.locator('#dmThread .xTop').bounding_box()
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertTrue(self.touch_drag_prevented('#dmThread .xTop',60))
        self.assertEqual(self.page.locator('#dmThread .xTop').bounding_box(),header)
        self.assertEqual(self.page.locator('.dmCompose').bounding_box(),bar)

    def test_message_gestures_scroll_inside_list_and_stop_at_its_edges(self):
        self.page.evaluate("window.PNGEA_API.messages=async()=>({items:Array.from({length:50},(_,i)=>({id:'long_'+i,sender_id:'usr_other',text:'Message '+i+' has enough content to fill a conversation',media:[]}))})")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        messages=self.page.locator('#dmMessages')
        messages.evaluate('(e)=>e.scrollTop=140')
        self.assertFalse(self.touch_drag_prevented('#dmMessages',40))
        self.assertFalse(self.touch_drag_prevented('#dmMessages',-40))
        messages.evaluate('(e)=>e.scrollTop=0')
        self.assertTrue(self.touch_drag_prevented('#dmMessages',40))
        self.assertFalse(self.touch_drag_prevented('#dmMessages',-40))
        messages.evaluate('(e)=>e.scrollTop=e.scrollHeight')
        self.assertTrue(self.touch_drag_prevented('#dmMessages',-40))
        self.assertFalse(self.touch_drag_prevented('#dmMessages',40))

    def test_short_conversation_cannot_drag_the_whole_screen(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        self.assertLessEqual(self.page.locator('#dmMessages').evaluate('(e)=>e.scrollHeight-e.clientHeight'),1)
        self.assertTrue(self.touch_drag_prevented('#dmMessages',50))
        self.assertTrue(self.touch_drag_prevented('#dmMessages',-50))

    def test_repeated_keyboard_close_restores_normal_chat_and_navigation(self):
        self.navigate('Inbox','cnv_a')
        header=self.page.locator('#dmThread .xTop').bounding_box()
        bar=self.page.locator('.dmCompose').bounding_box()
        nav=self.page.locator('.bottom').bounding_box()
        self.page.locator('#dmInput').focus()
        self.assertGreaterEqual(self.page.locator('#dmInput').evaluate('(e)=>parseFloat(getComputedStyle(e).fontSize)'),16)
        for height in (460,430,480):
            self.open_keyboard(height)
            self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:844});Object.defineProperty(window.visualViewport,'offsetTop',{configurable:true,value:0});window.visualViewport.dispatchEvent(new Event('resize'))")
            self.page.wait_for_function("!document.documentElement.classList.contains('pngeaKeyboardOpen')")
            self.page.wait_for_timeout(80)
            self.assertEqual(self.page.locator('#dmThread .xTop').bounding_box(),header)
            self.assertEqual(self.page.locator('.dmCompose').bounding_box(),bar)
            self.assertEqual(self.page.locator('.bottom').bounding_box(),nav)

    def test_chat_composer_meets_keyboard_and_navigation_stays_covered(self):
        self.navigate('Inbox','cnv_a')
        nav_top=self.page.locator('.bottom').bounding_box()['y']
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertAlmostEqual(self.page.locator('.bottom').bounding_box()['y'],nav_top,delta=2)
        self.assertGreater(self.page.locator('.bottom').bounding_box()['y'],460)
        self.assertEqual(self.page.locator('#dmMessages').evaluate('(e)=>getComputedStyle(e).touchAction'),'pan-y')
        self.assertEqual(self.page.locator('.dmCompose').evaluate('(e)=>getComputedStyle(e).position'),'relative')
        self.assertEqual(self.page.locator('#dmMessages').evaluate('(e)=>getComputedStyle(e).flexGrow'),'1')

    def test_visual_viewport_pan_moves_header_list_and_editor_as_one_frame(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        for height,offset in ((460,0),(460,70),(430,25),(480,0)):
            self.open_keyboard(height,offset)
            header=self.page.locator('#dmThread .xTop').bounding_box()
            messages=self.page.locator('#dmMessages').bounding_box()
            bar=self.page.locator('.dmCompose').bounding_box()
            self.assertAlmostEqual(header['y'],offset,delta=2)
            self.assertAlmostEqual(messages['y'],header['y']+header['height'],delta=2)
            self.assertAlmostEqual(messages['y']+messages['height'],bar['y'],delta=2)
            self.assertAlmostEqual(bar['y']+bar['height'],offset+height,delta=2)

    def test_leaving_chat_releases_page_gesture_lock(self):
        self.navigate('Inbox','cnv_a')
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaThreadViewport')")
        self.assertTrue(self.touch_drag_prevented('#dmThread .xTop',50))
        self.navigate('Home')
        self.page.wait_for_function("!document.documentElement.classList.contains('pngeaThreadViewport')")
        self.assertFalse(self.touch_drag_prevented('#Home .top',50))

    def test_chat_handles_visual_viewport_pan_and_both_viewports_shrinking(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.page.evaluate("Object.defineProperty(window,'innerHeight',{configurable:true,value:460})")
        self.open_keyboard(460,25)
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],485,delta=2)
        self.assertGreater(self.page.locator('.bottom').bounding_box()['y'],485)

    def test_viewport_scroll_events_do_not_reset_a_scrolled_chat(self):
        self.page.evaluate("window.PNGEA_API.messages=async()=>({items:Array.from({length:50},(_,i)=>({id:'long_'+i,sender_id:'usr_other',text:'Message '+i+' has enough content to fill a conversation',media:[]}))})")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop=140')
        self.page.wait_for_timeout(50)
        self.page.evaluate("window.visualViewport.dispatchEvent(new Event('scroll'))")
        self.page.wait_for_timeout(100)
        self.assertAlmostEqual(self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop'),140,delta=2)
        self.open_keyboard(430)
        self.assertAlmostEqual(self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop'),140,delta=2)

    def test_latest_message_remains_visible_when_keyboard_opens(self):
        self.page.evaluate("window.PNGEA_API.messages=async()=>({items:Array.from({length:30},(_,i)=>({id:'long_'+i,sender_id:'usr_other',text:'Message '+i,media:[]}))})")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop=e.scrollHeight')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        gap=self.page.locator('#dmMessages').evaluate('(e)=>e.scrollHeight-e.scrollTop-e.clientHeight')
        self.assertLessEqual(gap,2)
        latest=self.page.locator('[data-message-id="long_29"]').bounding_box()
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertLessEqual(latest['y']+latest['height'],bar['y']+2)

    def test_safe_area_does_not_add_a_gap_below_the_composer(self):
        self.page.evaluate("document.documentElement.style.setProperty('--pn-safe-top','44px');document.documentElement.style.setProperty('--pn-safe-bottom','34px')")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        header=self.page.locator('#dmThread .xTop').bounding_box()
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertAlmostEqual(header['y'],44,delta=2)
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertEqual(self.page.locator('#dmThread').evaluate('(e)=>getComputedStyle(e).paddingBottom'),'0px')

    def test_comment_editor_and_tools_meet_keyboard_without_lifting_navigation(self):
        nav_top=self.page.locator('.bottom').bounding_box()['y']
        self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.open_keyboard()
        bar=self.page.locator('#pngeaPostReplyBar').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertAlmostEqual(self.page.locator('.bottom').bounding_box()['y'],nav_top,delta=2)
        self.assertTrue(self.page.locator('.pngeaReplyTools').is_visible())

    def test_reply_gestures_cannot_drag_the_page_outside_comment_scroller(self):
        self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.open_keyboard()
        self.assertTrue(self.touch_drag_prevented('#pngeaPostPage .pngeaPostTop',50))
        self.page.locator('#pngeaReplyList').evaluate("(e)=>e.innerHTML='<div style=\"height:1800px\">Long conversation</div>'")
        self.page.locator('#pngeaPostScroll').evaluate('(e)=>e.scrollTop=140')
        self.assertFalse(self.touch_drag_prevented('#pngeaPostScroll',40))
        self.page.locator('#pngeaPostScroll').evaluate('(e)=>e.scrollTop=0')
        self.assertTrue(self.touch_drag_prevented('#pngeaPostScroll',40))
        self.assertEqual(self.page.locator('#pngeaPostReplyBar').evaluate('(e)=>getComputedStyle(e).position'),'relative')

    def test_chat_profile_back_restores_conversation_and_draft(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').fill('Draft kept while viewing profile')
        self.page.locator('#dmThread .xAvatar').first.click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'")
        self.page.locator('#Profile .xTop .xBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Inbox' && window.PNGEA.parseRoute().detail==='cnv_a'")
        self.assertEqual(self.page.locator('#dmInput').input_value(),'Draft kept while viewing profile')
        self.assertTrue(self.page.locator('#dmThread').is_visible())

    def test_chat_profile_return_context_is_account_scoped(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmThread .xAvatar').first.click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'")
        self.page.evaluate("window.PNGEA_API.getActiveAccountKey=()=> 'another-account'")
        self.page.locator('#Profile .xTop .xBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Home'")


if __name__ == '__main__':
    unittest.main(verbosity=2)
