"""Chat viewport and return navigation regressions, using isolated API fixtures."""
import unittest
try:
    from . import browser_reliability as fixtures
except ImportError:
    import browser_reliability as fixtures


class ChatKeyboard(unittest.TestCase):
    setUpClass = classmethod(fixtures.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixtures.Reliability.tearDownClass.__func__)
    setUp = fixtures.Reliability.setUp
    tearDown = fixtures.Reliability.tearDown
    route = fixtures.Reliability.route
    navigate = fixtures.Reliability.navigate

    def open_keyboard(self, height=460, offset=0):
        self.page.evaluate("([height,offset])=>{Object.defineProperty(window.visualViewport,'height',{configurable:true,value:height});Object.defineProperty(window.visualViewport,'offsetTop',{configurable:true,value:offset});window.visualViewport.dispatchEvent(new Event('resize'))}", [height,offset])
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        self.page.wait_for_timeout(80)

    def test_chat_composer_meets_keyboard_and_navigation_stays_covered(self):
        self.navigate('Inbox','cnv_a')
        nav_top=self.page.locator('.bottom').bounding_box()['y']
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertAlmostEqual(self.page.locator('.bottom').bounding_box()['y'],nav_top,delta=2)
        self.assertGreater(self.page.locator('.bottom').bounding_box()['y'],460)
        self.assertEqual(self.page.locator('#dmMessages').evaluate('(e)=>getComputedStyle(e).touchAction'),'pan-y')

    def test_chat_handles_visual_viewport_pan_and_both_viewports_shrinking(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.page.evaluate("Object.defineProperty(window,'innerHeight',{configurable:true,value:460})")
        self.open_keyboard(460,25)
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],485,delta=2)
        self.assertGreater(self.page.locator('.bottom').bounding_box()['y'],485)

    def test_viewport_scroll_events_do_not_reset_a_scrolled_chat(self):
        self.page.evaluate("window.PNGEA_API.messages=async()=>({items:Array.from({length:50},(_,i)=>({id:'long_'+i,sender_id:'usr_other',text:'Message '+i+' has enough content to fill a conversation',media:[]}))})")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop=140')
        self.page.wait_for_timeout(50)
        self.page.evaluate("window.visualViewport.dispatchEvent(new Event('scroll'))")
        self.page.wait_for_timeout(100)
        self.assertAlmostEqual(self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop'),140,delta=2)
        self.open_keyboard(430)
        self.assertAlmostEqual(self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop'),140,delta=2)

    def test_latest_message_remains_visible_when_keyboard_opens(self):
        self.page.evaluate("window.PNGEA_API.messages=async()=>({items:Array.from({length:30},(_,i)=>({id:'long_'+i,sender_id:'usr_other',text:'Message '+i,media:[]}))})")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmMessages').evaluate('(e)=>e.scrollTop=e.scrollHeight')
        self.page.locator('#dmInput').focus()
        self.open_keyboard()
        gap=self.page.locator('#dmMessages').evaluate('(e)=>e.scrollHeight-e.scrollTop-e.clientHeight')
        self.assertLessEqual(gap,2)
        latest=self.page.locator('[data-message-id="long_29"]').bounding_box()
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertLessEqual(latest['y']+latest['height'],bar['y']+2)

    def test_comment_editor_and_tools_meet_keyboard_without_lifting_navigation(self):
        nav_top=self.page.locator('.bottom').bounding_box()['y']
        self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.open_keyboard()
        bar=self.page.locator('#pngeaPostReplyBar').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertAlmostEqual(self.page.locator('.bottom').bounding_box()['y'],nav_top,delta=2)
        self.assertTrue(self.page.locator('.pngeaReplyTools').is_visible())

    def test_chat_profile_back_restores_conversation_and_draft(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').fill('Draft kept while viewing profile')
        self.page.locator('#dmThread .xAvatar').first.click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'")
        self.page.locator('#Profile .xTop .xBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Inbox' && window.PNGEA.parseRoute().detail==='cnv_a'")
        self.assertEqual(self.page.locator('#dmInput').input_value(),'Draft kept while viewing profile')
        self.assertTrue(self.page.locator('#dmThread').is_visible())

    def test_chat_profile_return_context_is_account_scoped(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmThread .xAvatar').first.click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'")
        self.page.evaluate("window.PNGEA_API.getActiveAccountKey=()=> 'another-account'")
        self.page.locator('#Profile .xTop .xBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Home'")


if __name__ == '__main__':
    unittest.main(verbosity=2)
