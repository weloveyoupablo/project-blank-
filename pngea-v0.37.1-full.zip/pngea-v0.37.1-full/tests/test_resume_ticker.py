"""Release resume and ticker-clock checks against isolated browser fixtures."""
import re
import unittest
from urllib.parse import parse_qs, urlsplit
from . import browser_reliability as fixture


class ResumeTicker(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    tearDown = fixture.Reliability.tearDown
    navigate = fixture.Reliability.navigate

    def setUp(self):
        self.next_build = None
        fixture.Reliability.setUp(self)
        self.page.wait_for_function('!!window.PNGEA_RELEASE&&!!window.PNGEA_CLOCK')
        self.navigations = []
        self.page.on('request', lambda request: self.navigations.append(request.url) if request.is_navigation_request() and request.frame == self.page.main_frame else None)

    def route(self, route):
        parsed = urlsplit(route.request.url)
        if parsed.hostname == 'localhost' and 'pngea-check' in parse_qs(parsed.query) and self.next_build:
            html = (fixture.ROOT / 'index.html').read_text()
            html = re.sub(r'''(<meta\s+name=["']pngea-build["']\s+content=["'])[^"']+''', lambda match: match[1] + self.next_build, html, count=1)
            route.fulfill(content_type='text/html', body=html, headers={'Cache-Control': 'no-store'})
            return
        fixture.Reliability.route(self, route)

    def test_newer_release_reloads_once_and_preserves_route_and_query(self):
        self.navigate('Profile', 'other')
        self.page.evaluate("history.replaceState(null,'','/?keep=yes'+location.hash)")
        old_hash = urlsplit(self.page.url).fragment
        self.navigations.clear()
        self.next_build = '99.0.0-resume-test'
        with self.page.expect_navigation(wait_until='domcontentloaded'):
            self.page.evaluate('()=>{window.PNGEA_RELEASE.check({force:true})}')
        self.page.wait_for_function('!!window.PNGEA_RELEASE')
        query = parse_qs(urlsplit(self.page.url).query)
        self.assertEqual(query['v'], [self.next_build])
        self.assertEqual(query['keep'], ['yes'])
        self.assertEqual(urlsplit(self.page.url).fragment, old_hash)
        self.assertEqual(self.page.evaluate("sessionStorage.getItem('pngea:lastReloadBuild')"), self.next_build)
        # The fixture still serves the old document after navigation. The saved
        # build guard must prevent an endless reload against that stale shell.
        self.page.evaluate('()=>window.PNGEA_RELEASE.check({force:true})')
        self.assertEqual(len(self.navigations), 1)

    def test_same_or_older_release_does_not_reload(self):
        original_url = self.page.url
        current = self.page.evaluate('window.PNGEA_RELEASE.build')
        for version in (current, '0.0.0-older'):
            with self.subTest(version=version):
                self.next_build = version
                self.page.evaluate('()=>window.PNGEA_RELEASE.check({force:true})')
                self.assertEqual(self.page.url, original_url)
                self.assertEqual(self.navigations, [])
        self.assertIsNone(self.page.evaluate("sessionStorage.getItem('pngea:lastReloadBuild')"))

    def test_unsent_post_defers_reload_until_saved_to_drafts(self):
        self.page.locator('.compose').click()
        self.page.locator('#postText').fill('Do not lose this unsent post')
        self.next_build = '99.0.0-draft-resume'
        original_url = self.page.url
        self.page.evaluate('()=>window.PNGEA_RELEASE.check({force:true})')
        self.assertEqual(self.page.url, original_url)
        self.assertEqual(self.navigations, [])
        self.assertEqual(self.page.locator('#postText').input_value(), 'Do not lose this unsent post')
        self.assertIsNone(self.page.evaluate("sessionStorage.getItem('pngea:lastReloadBuild')"))
        self.page.locator('#closeComposer').click()
        self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        with self.page.expect_navigation(wait_until='domcontentloaded'):
            self.page.evaluate('()=>{window.PNGEA_RELEASE.check({force:true})}')
        self.page.wait_for_function('window.PNGEA_LIVE?.state?.active')
        self.page.wait_for_function("document.querySelector('#pngeaDraftsBtn')?.dataset.draftCount==='1'")
        self.page.locator('.compose').click(); self.page.locator('#pngeaDraftsBtn').click()
        self.page.wait_for_selector('#pngeaDraftList .pngeaDraftCopy')
        self.assertIn('Do not lose this unsent post', self.page.locator('#pngeaDraftList').inner_text())

    def test_clock_moves_inside_ticker_and_refresh_updates_existing_nodes(self):
        self.page.evaluate("""async()=>{
            window.fixtureTickerTime='2031-07-04T16:58:00.000Z';
            window.fixtureTickerItems=Array.from({length:12},(_,index)=>({key:'headline:'+index,kind:'news',label:'NEWS',source:'Reuters',text:'Fixture headline '+index}));
            window.PNGEA_API.ticker=async()=>({generatedAt:window.fixtureTickerTime,items:window.fixtureTickerItems});
            await window.PNGEA_CORE.refreshTicker();
            window.originalTimeItem=document.querySelector('#tickerTrack .pngeaTimeItem');
            window.originalTimeText=window.originalTimeItem.querySelector('.tickerTime').textContent;
        }""")
        self.assertEqual(self.page.locator('.pngeaTickerClock,#pngeaTickerClock').count(), 0)
        clocks = self.page.locator('#tickerTrack > .tickerItem.pngeaTimeItem')
        self.assertEqual(clocks.count(), 6)  # Three clocks in each repeated track.
        positions = self.page.locator('#tickerTrack').evaluate("track=>[...track.children].slice(0,15).flatMap((node,index)=>node.classList.contains('pngeaTimeItem')?[index]:[])")
        self.assertEqual(positions, [4, 9, 14])
        accuracy = self.page.evaluate("""()=>{const element=document.querySelector('#tickerTrack .tickerTime'),time=window.PNGEA_CLOCK.now();return{offset:Math.abs(time-Date.parse(window.fixtureTickerTime)),matches:element.textContent===new Intl.DateTimeFormat('en-US',{timeZone:element.dataset.timeZone,hour:'numeric',minute:'2-digit',hour12:true,timeZoneName:'short'}).format(new Date(time)),zone:element.dataset.timeZone}}""")
        self.assertLess(accuracy['offset'], 2000)
        self.assertTrue(accuracy['matches'])
        self.assertEqual(accuracy['zone'], 'America/New_York')
        self.page.evaluate("""async()=>{window.fixtureTickerTime='2031-07-04T17:00:00.000Z';await window.PNGEA_CORE.refreshTicker();window.PNGEA_CLOCK.paint()}""")
        self.assertTrue(self.page.evaluate("window.originalTimeItem===document.querySelector('#tickerTrack .pngeaTimeItem')"))
        self.assertNotEqual(self.page.locator('#tickerTrack .tickerTime').first.inner_text(), self.page.evaluate('window.originalTimeText'))
        self.assertLess(self.page.evaluate('Math.abs(window.PNGEA_CLOCK.now()-Date.parse(window.fixtureTickerTime))'), 2000)


if __name__ == '__main__':
    unittest.main(verbosity=2)
