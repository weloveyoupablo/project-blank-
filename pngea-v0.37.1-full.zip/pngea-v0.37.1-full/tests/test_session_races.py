"""Account/session races use the real API block and controlled fetch promises."""
import unittest
from . import browser_reliability as fixture


class SessionRaces(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)

    def setUp(self):
        self.page = self.browser.new_page()
        self.page.set_default_timeout(4000)
        self.errors = []
        self.page.on('pageerror', lambda error: self.errors.append(str(error)))
        self.page.route('**/*', lambda route: route.fulfill(content_type='text/html', body='<html><head></head><body></body></html>'))
        self.page.goto('http://localhost/')
        self.page.evaluate("""() => {
          localStorage.clear();
          localStorage.setItem('pngea:activeAccountKey','aaaaaaaaaaaaaaaa');
          localStorage.setItem('pngea:accessToken','access-a');
          localStorage.setItem('pngea:deviceAccounts.v1',JSON.stringify([{accountKey:'aaaaaaaaaaaaaaaa',userId:'a'},{accountKey:'bbbbbbbbbbbbbbbb',userId:'b'}]));
          localStorage.setItem('pngea:deviceRefreshTokens.v1',JSON.stringify({aaaaaaaaaaaaaaaa:'refresh-a',bbbbbbbbbbbbbbbb:'refresh-b'}));
          window.calls=[];window.results={};window.expiredEvents=0;
          window.addEventListener('pngea:session-expired',()=>window.expiredEvents++);
          window.runRequest=(name,promise)=>{promise.then(value=>window.results[name]={ok:true,value},error=>window.results[name]={ok:false,name:error.name,status:error.status})};
          window.fetch=(url,options={})=>{
            const path=new URL(url).pathname;
            if(path==='/health')return Promise.resolve(new Response('{"ok":true}',{status:200}));
            const call={path,options,body:options.body?JSON.parse(options.body):null};window.calls.push(call);
            return new Promise(resolve=>{
              call.release=(payload,status=200)=>resolve(new Response(JSON.stringify(payload),{status,headers:{'Content-Type':'application/json'}}));
              call.headersOnly=()=>{
                const stream=new ReadableStream({start(controller){call.stream=controller;controller.enqueue(new TextEncoder().encode('{"id":'))}});
                const response=new Response(stream,{status:200,headers:{'Content-Type':'application/json'}}),read=response.json.bind(response);
                response.json=()=>{call.readingBody=true;return read()};resolve(response);
              };
            });
          };
        }""")
        source = (fixture.ROOT / 'index.html').read_text()
        start = source.index("(() => {\n  const storedBase = localStorage.getItem('pngea:apiBase');")
        end = source.index('\n})();', start) + len('\n})();')
        self.page.add_script_tag(content=source[start:end])
        self.page.wait_for_function("document.documentElement.dataset.backend==='ready'")

    def tearDown(self):
        try:
            self.assertEqual(self.errors, [])
        finally:
            self.page.close()

    def wait_calls(self, number):
        self.page.wait_for_function('(count)=>window.calls.length>=count', arg=number)

    def wait_result(self, name):
        self.page.wait_for_function('(name)=>!!window.results[name]', arg=name)
        return self.page.evaluate('(name)=>window.results[name]', name)

    def release(self, index, payload, status=200):
        self.page.evaluate('([index,payload,status])=>window.calls[index].release(payload,status)', [index, payload, status])

    def assert_account_b(self):
        self.assertEqual(self.page.evaluate("localStorage.getItem('pngea:accessToken')"), 'fresh-b')
        self.assertEqual(self.page.evaluate('window.PNGEA_API.getActiveAccountKey()'), 'bbbbbbbbbbbbbbbb')

    def test_switch_does_not_join_or_commit_the_previous_accounts_refresh(self):
        self.page.evaluate("()=>window.runRequest('old',window.PNGEA_API.refresh())")
        self.wait_calls(1)
        self.page.evaluate("()=>window.runRequest('switch',window.PNGEA_API.switchAccount('bbbbbbbbbbbbbbbb'))")
        self.wait_calls(2)
        self.assertEqual(self.page.evaluate('window.calls[1].body.accountKey'), 'bbbbbbbbbbbbbbbb')
        self.release(1, dict(accessToken='fresh-b', accountKey='bbbbbbbbbbbbbbbb', refreshToken='new-refresh-b'))
        self.assertTrue(self.wait_result('switch')['ok'])
        self.release(0, dict(accessToken='stale-a', accountKey='aaaaaaaaaaaaaaaa', refreshToken='stale-refresh-a'))
        self.assertEqual(self.wait_result('old')['name'], 'AbortError')
        self.assert_account_b()

    def test_refresh_finishing_after_logout_cannot_restore_credentials(self):
        self.page.evaluate("()=>window.runRequest('refresh',window.PNGEA_API.refresh())")
        self.wait_calls(1)
        self.page.evaluate("()=>window.runRequest('logout',window.PNGEA_API.logout())")
        self.wait_calls(2)
        self.release(0, dict(accessToken='stale-a', accountKey='aaaaaaaaaaaaaaaa', refreshToken='stale-refresh-a'))
        self.release(1, dict(ok=True))
        self.assertTrue(self.wait_result('logout')['ok'])
        self.assertIsNone(self.page.evaluate("localStorage.getItem('pngea:accessToken')"))
        self.assertNotIn('aaaaaaaaaaaaaaaa', self.page.evaluate("JSON.parse(localStorage.getItem('pngea:deviceRefreshTokens.v1'))"))

    def test_late_logout_does_not_clear_a_newly_authenticated_account(self):
        self.page.evaluate("()=>window.runRequest('logout',window.PNGEA_API.logout())")
        self.wait_calls(1)
        self.page.evaluate("()=>window.runRequest('login',window.PNGEA_API.login({identifier:'b',password:'test-password'}))")
        self.wait_calls(2)
        self.release(1, dict(accessToken='fresh-b', accountKey='bbbbbbbbbbbbbbbb'))
        self.assertTrue(self.wait_result('login')['ok'])
        self.release(0, dict(ok=True))
        self.assertEqual(self.wait_result('logout')['name'], 'AbortError')
        self.assert_account_b()

    def test_aborted_refresh_retry_starts_before_old_finalizer_and_keeps_its_own_flight(self):
        self.page.evaluate("()=>{window.firstController=new AbortController();window.runRequest('old',window.PNGEA_API.refresh(null,{signal:window.firstController.signal}))}")
        self.wait_calls(1)
        self.page.evaluate("()=>{window.firstController.abort();window.runRequest('new',window.PNGEA_API.refresh());window.runRequest('joined',window.PNGEA_API.refresh())}")
        self.wait_calls(2)
        self.release(1, dict(accessToken='fresh-a', accountKey='aaaaaaaaaaaaaaaa'))
        self.assertTrue(self.wait_result('new')['ok'])
        self.assertTrue(self.wait_result('joined')['ok'])
        self.release(0, dict(accessToken='stale-a', accountKey='aaaaaaaaaaaaaaaa'))
        self.assertEqual(self.wait_result('old')['name'], 'AbortError')
        self.assertEqual(self.page.evaluate("localStorage.getItem('pngea:accessToken')"), 'fresh-a')
        self.assertEqual(self.page.evaluate('window.calls.length'), 2)

    def test_timeout_covers_a_response_body_that_never_finishes(self):
        self.page.evaluate("()=>window.runRequest('body',window.PNGEA_API.me({timeoutMs:250}))")
        self.wait_calls(1)
        self.page.evaluate('()=>window.calls[0].headersOnly()')
        self.page.wait_for_function('window.calls[0].readingBody===true')
        self.assertEqual(self.wait_result('body')['name'], 'TimeoutError')
        self.page.evaluate('()=>window.calls[0].stream.close()')

    def test_caller_abort_still_cancels_after_headers_arrive(self):
        self.page.evaluate("()=>{window.bodyController=new AbortController();window.runRequest('body',window.PNGEA_API.me({signal:window.bodyController.signal}))}")
        self.wait_calls(1)
        self.page.evaluate('()=>window.calls[0].headersOnly()')
        self.page.wait_for_function('window.calls[0].readingBody===true')
        self.page.evaluate('()=>window.bodyController.abort()')
        self.assertEqual(self.wait_result('body')['name'], 'AbortError')
        self.page.evaluate('()=>window.calls[0].stream.close()')

    def test_joining_a_background_refresh_keeps_the_callers_overall_deadline(self):
        self.page.evaluate("()=>window.runRequest('background',window.PNGEA_API.refresh())")
        self.wait_calls(1)
        self.page.evaluate("()=>window.runRequest('me',window.PNGEA_API.me({timeoutMs:250}))")
        self.wait_calls(2)
        self.release(1, dict(error=dict(message='Expired')), 401)
        self.assertEqual(self.wait_result('me')['name'], 'TimeoutError')
        self.assertEqual(self.page.evaluate('window.calls.length'), 2)
        self.release(0, dict(accessToken='fresh-a', accountKey='aaaaaaaaaaaaaaaa'))
        self.assertTrue(self.wait_result('background')['ok'])

    def test_a_stale_unauthorized_response_cannot_sign_out_the_new_account(self):
        self.page.evaluate("()=>window.runRequest('old-me',window.PNGEA_API.me())")
        self.wait_calls(1)
        self.page.evaluate("()=>window.runRequest('login',window.PNGEA_API.login({identifier:'b',password:'test-password'}))")
        self.wait_calls(2)
        self.release(1, dict(accessToken='fresh-b', accountKey='bbbbbbbbbbbbbbbb'))
        self.assertTrue(self.wait_result('login')['ok'])
        self.release(0, dict(error=dict(message='Expired')), 401)
        self.assertEqual(self.wait_result('old-me')['name'], 'AbortError')
        self.assertEqual(self.page.evaluate('window.expiredEvents'), 0)
        self.assert_account_b()


if __name__ == '__main__':
    unittest.main(verbosity=2)
