"""Profile social controls and artwork use isolated local API fixtures."""
import json
import struct
import unittest
import zlib
try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture


class ProfileControls(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    tearDown = fixture.Reliability.tearDown
    route = fixture.Reliability.route
    navigate = fixture.Reliability.navigate

    def setUp(self):
        fixture.Reliability.setUp(self)
        self.page.evaluate("""()=>{
          const getUser=window.PNGEA_API.getUser;
          window.PNGEA_API.getUser=async handle=>handle==='tester'?window.PNGEA_LIVE.state.me:{...(await getUser(handle)),viewer_following:false,viewer_post_notifications:'none',followers:3,following:4};
        }""")

    def test_own_profile_has_large_share_and_edit_buttons_below_counts(self):
        self.navigate('Profile', 'tester')
        counts = self.page.locator('#Profile .profileStats').bounding_box()
        edit = self.page.locator('#Profile .profileEdit').bounding_box()
        share = self.page.locator('#pngeaProfileMessage').bounding_box()
        self.assertGreaterEqual(edit['y'], counts['y'] + counts['height'])
        self.assertEqual(edit['y'], share['y'])
        self.assertGreaterEqual(edit['height'], 44)
        self.assertGreaterEqual(share['height'], 44)
        self.assertAlmostEqual(edit['width'], share['width'], delta=1)
        self.assertEqual(self.page.locator('#pngeaProfileMessage').inner_text(), 'Share profile')
        self.assertEqual(self.page.locator('#Profile .profileAvatarRow .profileEdit').count(), 0)
        self.page.locator('#Profile .profileEdit').click()
        self.assertTrue(self.page.locator('#profileEditLayer').is_visible())
        self.page.locator('#profileEditCancel').click()
        self.assertFalse(self.page.locator('#profileEditLayer').is_visible())

    def test_own_profile_share_lists_and_searches_only_followed_people(self):
        self.navigate('Profile', 'tester')
        self.page.evaluate("""()=>{
          window.unfilteredShareSearches=0;
          window.PNGEA_API.following=async handle=>{window.shareFollowingHandle=handle;return{items:[{id:'usr_other',handle:'other',display_name:'Other'},{id:'usr_followed',handle:'friend',display_name:'Followed friend'},window.PNGEA_LIVE.state.me]}};
          window.PNGEA_API.search=async()=>{window.unfilteredShareSearches++;return{people:[{id:'usr_outsider',handle:'outsider',display_name:'Outsider'}]}};
          window.PNGEA_API.createConversation=async body=>{window.shareMembers=body.memberIds;return{id:'cnv_a'}};
          window.PNGEA_API.sendMessage=async(id,body)=>{window.ownProfileSent=body;return{id:'msg_shared'}};
        }""")
        self.page.locator('#pngeaProfileMessage').click()
        self.page.wait_for_selector('#pngeaSendPostPeople [data-recipient]')
        self.assertEqual(self.page.locator('#pngeaSendPostPage .pngeaPostTop b').inner_text(), 'Share profile')
        self.assertEqual(self.page.locator('#pngeaSendPostPeople [data-recipient]').evaluate_all('(els)=>els.map(el=>el.dataset.recipient)'), ['usr_other', 'usr_followed'])
        self.assertEqual(self.page.evaluate('window.shareFollowingHandle'), 'tester')
        self.page.locator('#pngeaSendPostSearch').fill('outsider')
        self.page.wait_for_function("document.querySelector('#pngeaSendPostPeople').textContent.includes('No followed accounts match')")
        self.assertEqual(self.page.locator('#pngeaSendPostPeople [data-recipient]').count(), 0)
        self.assertEqual(self.page.evaluate('window.unfilteredShareSearches'), 0)
        self.page.locator('#pngeaSendPostSearch').fill('@OTHER')
        self.page.wait_for_selector('#pngeaSendPostPeople [data-recipient="usr_other"]')
        self.assertEqual(self.page.locator('#pngeaSendPostPeople [data-recipient]').count(), 1)
        self.page.locator('#pngeaSendPostPeople [data-recipient="usr_other"]').click()
        self.page.wait_for_function('!!window.ownProfileSent')
        self.assertEqual(self.page.evaluate('window.shareMembers'), ['usr_other'])
        self.assertTrue(self.page.evaluate('window.ownProfileSent.text').endswith('#/profile/tester'))
        self.page.locator('#pngeaSendPostBack').click()
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().detail'), 'tester')

    def test_empty_self_share_does_not_fall_back_to_unfollowed_conversations(self):
        self.navigate('Profile', 'tester')
        self.page.evaluate("()=>{window.PNGEA_API.following=async()=>({items:[]})}")
        self.page.locator('#pngeaProfileMessage').click()
        self.page.wait_for_function("document.querySelector('#pngeaSendPostPeople').textContent.includes('Follow people to share your profile')")
        self.assertEqual(self.page.locator('#pngeaSendPostPeople [data-recipient]').count(), 0)
        self.page.locator('#pngeaSendPostBack').click()
        self.navigate('Profile', 'other')
        self.page.locator('#pngeaProfileShare').click()
        self.page.wait_for_selector('#pngeaSendPostPeople [data-recipient="cnv_b"]')
        self.assertEqual(self.page.locator('#pngeaSendPostPage .pngeaPostTop b').inner_text(), 'Send account')

    def test_profile_actions_below_counts_and_old_position_has_icon_tools(self):
        self.navigate('Profile', 'other')
        counts = self.page.locator('#Profile .profileStats').bounding_box()
        follow = self.page.locator('#Profile .profileEdit').bounding_box()
        message = self.page.locator('#pngeaProfileMessage').bounding_box()
        self.assertGreaterEqual(follow['y'], counts['y'] + counts['height'])
        self.assertEqual(follow['y'], message['y'])
        self.assertGreaterEqual(follow['height'], 44)
        self.assertEqual(self.page.locator('#Profile .profileAvatarRow #pngeaProfileTools button').count(), 2)
        self.page.evaluate("window.PNGEA_API.createConversation=async()=>({id:'cnv_a'})")
        self.page.locator('#pngeaProfileMessage').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().detail==='cnv_a'")
        self.assertTrue(self.page.locator('#dmThread').is_visible())

    def test_notification_sheet_saves_exact_three_modes_and_keeps_selection(self):
        self.navigate('Profile', 'other')
        self.page.locator('#pngeaProfileNotifications').click()
        self.assertEqual(self.page.locator('#pngeaProfileSocialSheet h3').inner_text(), 'Account notifications')
        self.assertEqual(self.page.locator('#pngeaProfileSocialSheet small').inner_text(), '@other')
        self.assertEqual(self.page.locator('[data-notification-mode]').evaluate_all('(els)=>els.map(el=>el.dataset.notificationMode)'), ['none', 'posts', 'posts_replies'])
        self.page.locator('[data-notification-mode="posts_replies"]').click()
        self.page.wait_for_function("!document.querySelector('#pngeaProfileSocialShade').classList.contains('show')")
        self.assertIn(('PUT', '/v1/users/usr_other/post-notifications'), self.requests)
        self.page.locator('#pngeaProfileNotifications').click()
        self.assertEqual(self.page.locator('[data-notification-mode="posts_replies"]').get_attribute('aria-checked'), 'true')

    def test_profile_menu_external_share_mute_and_block(self):
        self.navigate('Profile', 'other')
        self.page.evaluate("Object.defineProperty(navigator,'share',{configurable:true,value:async value=>{window.sharedProfile=value}})")
        self.page.locator('#Profile .xTop>.xAction').click()
        self.assertEqual(self.page.locator('#pngeaProfileSocialSheet button').all_text_contents(), ['Share', 'Mute', 'Block'])
        self.page.locator('#pngeaProfileSocialSheet button').get_by_text('Share', exact=True).click()
        self.page.wait_for_function('!!window.sharedProfile')
        self.assertTrue(self.page.evaluate('window.sharedProfile.url').endswith('#/profile/other'))
        self.page.locator('#Profile .xTop>.xAction').click()
        self.page.locator('#pngeaProfileSocialSheet button').get_by_text('Mute', exact=True).click()
        self.page.wait_for_function("!document.querySelector('#pngeaProfileSocialShade').classList.contains('show')")
        self.assertIn(('PUT', '/v1/users/usr_other/mute'), self.requests)
        self.page.locator('#Profile .xTop>.xAction').click()
        self.assertIn('Unmute', self.page.locator('#pngeaProfileSocialSheet').inner_text())
        self.page.locator('#pngeaProfileSocialSheet button').get_by_text('Block', exact=True).click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Home'")
        self.assertIn(('PUT', '/v1/users/usr_other/block'), self.requests)

    def test_internal_profile_share_sends_profile_url_and_back_preserves_profile(self):
        self.navigate('Profile', 'other')
        self.page.evaluate("window.PNGEA_API.sendMessage=async(id,body)=>{window.profileSent=body;return{id:'msg_sent'}}")
        self.page.locator('#pngeaProfileShare').click()
        self.page.wait_for_selector('#pngeaSendPostPeople [data-recipient]')
        self.assertEqual(self.page.locator('#pngeaSendPostPage .pngeaPostTop b').inner_text(), 'Send account')
        self.page.locator('#pngeaSendPostPeople [data-recipient]').first.click()
        self.page.wait_for_function('!!window.profileSent')
        self.assertTrue(self.page.evaluate('window.profileSent.text').endswith('#/profile/other'))
        self.page.locator('#pngeaSendPostBack').click()
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().detail'), 'other')

    def test_connections_have_follow_actions_without_opening_profile(self):
        self.navigate('Profile', 'tester')
        self.page.locator('#Profile .profileStats span').nth(1).click()
        self.page.wait_for_selector('[data-connection-follow="usr_other"]')
        button = self.page.locator('[data-connection-follow="usr_other"]')
        button.click()
        self.page.wait_for_function("document.querySelector('[data-connection-follow]').dataset.following==='true'")
        self.assertTrue(self.page.locator('#pngeaConnectionsPage').is_visible())
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().detail'), 'tester')
        self.assertIn(('POST', '/v1/users/usr_other/follow'), self.requests)
        button.click()
        self.page.wait_for_function("document.querySelector('[data-connection-follow]').dataset.following==='false'")
        self.assertIn(('DELETE', '/v1/users/usr_other/follow'), self.requests)

    def test_close_friend_chip_has_remove_close_sheet_and_horizontal_strip(self):
        self.navigate('CloseFriends')
        self.assertEqual(self.page.locator('#pngeaClosePeople [data-remove-close]').count(), 0)
        self.assertEqual(self.page.locator('#pngeaClosePeople').evaluate('(el)=>getComputedStyle(el).overflowX'), 'auto')
        self.page.locator('[data-close-friend="usr_other"] .xAvatar').click()
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'), 'CloseFriends')
        self.assertEqual(self.page.locator('#pngeaProfileSocialSheet button').all_text_contents(), ['Remove', 'Close'])
        self.page.locator('#pngeaProfileSocialSheet button').get_by_text('Remove', exact=True).click()
        self.page.wait_for_function("!document.querySelector('#pngeaProfileSocialShade').classList.contains('show')")
        self.assertIn(('DELETE', '/v1/me/close-friends/usr_other'), self.requests)

    def test_profile_refresh_retains_post_avatar_nodes_and_banner_style(self):
        self.navigate('Profile', 'other')
        self.page.wait_for_selector('#Profile .xAvatar.big img')
        self.page.evaluate("window.profileNodes=[document.querySelector('#p-posts [data-server-post]'),document.querySelector('#Profile .xAvatar.big img')];window.bannerMutations=[];window.bannerObserver=new MutationObserver(m=>window.bannerMutations.push(...m));window.bannerObserver.observe(document.querySelector('#Profile .profileCover'),{attributes:true,attributeFilter:['style']})")
        self.page.evaluate("window.PNGEA_CORE.loadProfile('other')")
        self.assertTrue(self.page.evaluate("window.profileNodes[0]===document.querySelector('#p-posts [data-server-post]')&&window.profileNodes[1]===document.querySelector('#Profile .xAvatar.big img')"))
        self.assertEqual(self.page.evaluate('window.bannerMutations.length'), 0)

    def test_blocked_profile_response_clears_previous_identity_and_actions(self):
        self.navigate('Profile', 'other')
        self.page.evaluate("()=>{window.PNGEA_API.getUser=async()=>{throw Object.assign(new Error('Not found'),{status:404})}}")
        self.page.evaluate("window.PNGEA_CORE.loadProfile('other')")
        self.assertEqual(self.page.locator('#Profile .profileName').inner_text(), 'Account unavailable')
        self.assertFalse(self.page.locator('#pngeaProfileMessage').is_visible())
        self.assertEqual(self.page.locator('#Profile .profileCover').evaluate('(el)=>el.style.backgroundImage'), '')
        self.assertEqual(self.page.locator('#p-posts [data-server-post]').count(), 0)

    def test_profile_art_crop_returns_real_cropped_files_and_cancel_preserves_editor(self):
        self.navigate('Profile', 'tester')
        self.page.locator('#Profile .profileEdit').click()
        self.page.evaluate("""()=>{window.artUploads=[];window.PNGEA_API.createMediaUpload=async body=>{window.artUploads.push(body);return{mediaId:'med_art',uploadUrl:'http://localhost/upload',headers:{}}};window.PNGEA_API.completeMedia=async()=>({ok:true});window.PNGEA_API.media=async()=>({status:'ready'});window.PNGEA_API.updateProfile=async body=>{window.profileArtBody=body;return{ok:true}};window.XMLHttpRequest=class{constructor(){this.upload={}}open(){}setRequestHeader(){}send(file){window.artFile=file;this.status=200;setTimeout(()=>this.onload(),0)}}}""")
        def chunk(kind, body):
            return struct.pack('>I', len(body)) + kind + body + struct.pack('>I', zlib.crc32(kind + body) & 0xffffffff)
        png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 320, 240, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress((b'\0' + bytes([130, 140, 150]) * 320) * 240)) + chunk(b'IEND', b'')
        for control, ratio, field in [('#pngeaChangeAvatar', 1, 'avatarMediaId'), ('#pngeaChangeBanner', 3, 'bannerMediaId')]:
            with self.page.expect_file_chooser() as chosen:
                self.page.locator(control).click()
            chosen.value.set_files(dict(name='art.png', mimeType='image/png', buffer=png))
            self.page.wait_for_function("document.querySelector('#pngeaMediaEditor').classList.contains('show')&&document.querySelector('#pngeaEditorStage canvas')?.height>0")
            self.page.locator('#pngeaMediaEditorDone').click()
            self.page.wait_for_function('!!window.artFile')
            dimensions = self.page.evaluate('async()=>{const image=await createImageBitmap(window.artFile);return[image.width,image.height]}')
            self.assertAlmostEqual(dimensions[0] / dimensions[1], ratio, places=2)
            self.page.wait_for_function('field=>window.profileArtBody?.[field]==="med_art"', arg=field)
            self.assertTrue(self.page.locator('#profileEditLayer').is_visible())
            self.page.evaluate('window.artFile=null;window.profileArtBody=null')
        with self.page.expect_file_chooser() as chosen:
            self.page.locator('#pngeaChangeAvatar').click()
        chosen.value.set_files(dict(name='art.png', mimeType='image/png', buffer=png))
        self.page.wait_for_selector('#pngeaMediaEditor.show')
        self.page.locator('#pngeaMediaEditorCancel').click()
        self.assertTrue(self.page.locator('#profileEditLayer').is_visible())
        self.assertFalse(self.page.locator('#pngeaMediaEditor').is_visible())


if __name__ == '__main__':
    unittest.main()
