"""Session restoration uses local HTTP fixtures, including transient cold starts."""
import json
import unittest
from urllib.parse import unquote, urlsplit
try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture


class SessionRecovery(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    tearDown = fixture.Reliability.tearDown

    def setUp(self):
        self.page = self.browser.new_page(viewport=dict(width=390, height=844))
        self.page.set_default_timeout(6000)
        self.requests = []
        self.errors = []
        self.health_calls = 0
        self.me_calls = 0
        self.refresh_calls = 0
        self.auth_mode = 'valid'
        self.page.on('pageerror', lambda error: self.errors.append(str(error)))
        self.page.route('**/*', self.route)

    def route(self, route):
        parsed = urlsplit(route.request.url)
        path = unquote(parsed.path)
        if parsed.hostname != 'localhost' or parsed.port != 8787:
            return fixture.Reliability.route(self, route)
        status, data = 200, None
        if path == '/health':
            self.health_calls += 1
            if self.auth_mode == 'offline':
                status, data = 503, dict(error=dict(code='UNAVAILABLE', message='Backend is starting'))
            else:
                data = dict(ok=True)
        elif path == '/v1/me':
            self.me_calls += 1
            authorization = route.request.headers.get('authorization', '')
            if self.auth_mode == 'offline':
                status, data = 503, dict(error=dict(code='UNAVAILABLE', message='Backend is starting'))
            elif self.auth_mode in ('signed-out', 'refresh-unavailable') or (self.auth_mode == 'expired' and authorization != 'Bearer fresh-access'):
                status, data = 401, dict(error=dict(code='UNAUTHENTICATED', message='Authentication required'))
            else:
                data = fixture.ME
        elif path == '/v1/auth/refresh':
            self.refresh_calls += 1
            if self.auth_mode in ('offline', 'refresh-unavailable'):
                status, data = 503, dict(error=dict(code='UNAVAILABLE', message='Try again shortly'))
            elif self.auth_mode == 'signed-out':
                status, data = 401, dict(error=dict(code='INVALID_REFRESH_TOKEN', message='Sign in again'))
            else:
                data = dict(accessToken='fresh-access', accountKey=fixture.ME['account_key'], refreshToken='fresh-refresh')
        elif path == '/v1/users/tester':
            data = fixture.ME
        if data is None:
            return fixture.Reliability.route(self, route)
        self.requests.append((route.request.method, path))
        route.fulfill(status=status, content_type='application/json', body=json.dumps(data))

    def open(self, *, access='test-token', remembered=True, profile=False):
        stored = {}
        if access is not None:
            stored['pngea:accessToken'] = access
        if remembered:
            key = fixture.ME['account_key']
            stored['pngea:activeAccountKey'] = key
            stored['pngea:deviceRefreshTokens.v1'] = json.dumps({key: 'stored-refresh'})
            stored['pngea:deviceAccounts.v1'] = json.dumps([dict(accountKey=key, userId=fixture.ME['id'], handle='tester', displayName='Tester')])
        self.page.add_init_script('localStorage.clear();' + ''.join('localStorage.setItem(' + json.dumps(key) + ',' + json.dumps(value) + ');' for key, value in stored.items()))
        self.page.goto('http://localhost/' + ('#/profile/tester' if profile else ''), wait_until='domcontentloaded')
        self.page.wait_for_function("typeof window.PNGEA_LIVE?.resume==='function'")

    def signed_in(self):
        self.page.wait_for_function("window.PNGEA_LIVE?.state.active&&document.documentElement.dataset.session==='signed-in'")

    def resume(self):
        self.page.evaluate("async()=>{try{await window.PNGEA_LIVE.resume({validate:true})}catch(error){window.fixtureResumeError=error.message}}")

    def test_cold_backend_failure_recovers_on_online_without_new_url(self):
        self.auth_mode = 'offline'
        self.open()
        self.page.wait_for_function("document.documentElement.dataset.session==='offline'")
        self.assertGreaterEqual(self.health_calls, 1)
        self.assertFalse(self.page.locator('#pngeaLiveAuth').is_visible())
        self.auth_mode = 'valid'
        self.page.evaluate("window.dispatchEvent(new Event('online'))")
        self.signed_in()
        self.page.wait_for_selector('#feed [data-server-post="pst_real"]')
        self.assertFalse(self.page.locator('#pngeaLiveAuth').is_visible())

    def test_fresh_signed_out_session_shows_global_auth_without_live_feed(self):
        self.auth_mode = 'signed-out'
        self.open(access=None, remembered=False)
        self.page.wait_for_function("document.documentElement.dataset.session==='signed-out'")
        self.assertFalse(self.page.evaluate('window.PNGEA_LIVE.state.active'))
        self.assertTrue(self.page.locator('#pngeaLiveAuth').is_visible())
        self.assertTrue(self.page.locator('.app').evaluate('(el)=>el.classList.contains("authOpen")'))
        self.assertEqual(self.page.locator('#feed [data-server-post]').count(), 0)

    def test_fresh_offline_visitor_keeps_sign_in_screen(self):
        self.auth_mode = 'offline'
        self.open(access=None, remembered=False)
        self.page.wait_for_timeout(150)
        self.assertTrue(self.page.locator('#pngeaLiveAuth').is_visible())
        self.assertFalse(self.page.locator('#pngeaSessionGate').is_visible())
        self.assertFalse(self.page.evaluate('window.PNGEA_LIVE.state.active'))

    def test_expired_access_refresh_restores_own_profile_on_first_route(self):
        self.auth_mode = 'expired'
        self.open(access='expired-access', profile=True)
        self.signed_in()
        self.page.wait_for_function("document.querySelector('#Profile .profileHandle').textContent==='@tester'&&!!document.querySelector('#p-posts [data-server-post]')")
        self.assertGreaterEqual(self.refresh_calls, 1)
        self.assertGreaterEqual(self.me_calls, 1)
        self.assertNotIn('Sign in to view profiles', self.page.locator('#Profile').inner_text())
        self.assertFalse(self.page.locator('#pngeaLiveAuth').is_visible())
        self.assertEqual(self.page.evaluate("localStorage.getItem('pngea:accessToken')"), 'fresh-access')
        self.assertEqual(self.errors, [])

    def test_persisted_pageshow_restores_an_inactive_session_and_profile(self):
        self.open(profile=True)
        self.signed_in()
        self.resume()
        calls_before = self.me_calls
        self.page.evaluate("()=>{window.PNGEA_LIVE.state.active=false;window.PNGEA_LIVE.state.ws?.close();window.dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}))}")
        self.signed_in()
        self.page.wait_for_function("!!document.querySelector('#p-posts [data-server-post]')")
        self.assertGreater(self.me_calls, calls_before)
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().detail'), 'tester')
        self.assertNotIn('Sign in to view profiles', self.page.locator('#Profile').inner_text())

    def test_transient_refresh_failure_preserves_credentials_and_then_recovers(self):
        self.open()
        self.signed_in()
        self.resume()
        credentials_before = self.page.evaluate("[localStorage.getItem('pngea:accessToken'),localStorage.getItem('pngea:deviceRefreshTokens.v1')]")
        self.auth_mode = 'refresh-unavailable'
        self.resume()
        self.page.wait_for_function("document.documentElement.dataset.session==='offline'")
        self.assertGreaterEqual(self.refresh_calls, 1)
        self.assertEqual(self.page.evaluate("[localStorage.getItem('pngea:accessToken'),localStorage.getItem('pngea:deviceRefreshTokens.v1')]"), credentials_before)
        self.assertFalse(self.page.locator('#pngeaLiveAuth').is_visible())
        self.auth_mode = 'valid'
        self.page.evaluate("window.dispatchEvent(new Event('online'))")
        self.signed_in()

    def test_actual_authentication_expiry_replaces_active_app_with_global_auth(self):
        self.open()
        self.signed_in()
        self.resume()
        self.auth_mode = 'signed-out'
        self.resume()
        self.page.wait_for_function("document.documentElement.dataset.session==='signed-out'")
        self.assertFalse(self.page.evaluate('window.PNGEA_LIVE.state.active'))
        self.assertTrue(self.page.locator('#pngeaLiveAuth').is_visible())
        self.assertTrue(self.page.locator('.app').evaluate('(el)=>el.classList.contains("authOpen")'))


if __name__ == '__main__':
    unittest.main(verbosity=2)
