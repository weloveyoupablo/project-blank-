"""Real audio playback regressions; all files and API responses stay local."""
import io
import math
import re
import struct
import unittest
import wave
from urllib.parse import urlsplit

try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture


class VoiceWaveforms(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.Reliability.setUpClass.__func__(cls)
        sample_rate = 12000
        output = io.BytesIO()
        with wave.open(output, 'wb') as recording:
            recording.setnchannels(1)
            recording.setsampwidth(2)
            recording.setframerate(sample_rate)
            recording.writeframes(b''.join(struct.pack('<h', int(
                15000 * (.15 + .85 * (index / (sample_rate * 4))) *
                math.sin(index * 2 * math.pi * 440 / sample_rate)))
                for index in range(sample_rate * 4)))
        cls.recording = output.getvalue()

    @classmethod
    def tearDownClass(cls):
        fixture.Reliability.tearDownClass.__func__(cls)

    setUp = fixture.Reliability.setUp
    tearDown = fixture.Reliability.tearDown
    navigate = fixture.Reliability.navigate

    def route(self, route):
        if urlsplit(route.request.url).path == '/voice.wav':
            body=self.recording
            headers={'Accept-Ranges':'bytes','Content-Length':str(len(body))}
            requested=re.fullmatch(r'bytes=(\d*)-(\d*)',route.request.headers.get('range',''))
            if requested:
                start=int(requested[1] or 0)
                end=min(len(body)-1,int(requested[2]) if requested[2] else len(body)-1)
                if start> end:
                    route.fulfill(status=416,headers={'Content-Range':f'bytes */{len(body)}'},body=b'')
                    return
                headers.update({'Content-Range':f'bytes {start}-{end}/{len(body)}','Content-Length':str(end-start+1)})
                route.fulfill(status=206,content_type='audio/wav',headers=headers,body=body[start:end+1])
            else:
                route.fulfill(status=200,content_type='audio/wav',headers=headers,body=body)
            return
        fixture.Reliability.route(self, route)

    def install_voice_post(self, count=1):
        self.page.evaluate("""count=>{
            const media=Array.from({length:count},(_,index)=>({id:'voice_'+index,mimeType:'audio/wav',durationMs:4000}));
            window.voicePost={id:'pst_voice',author_id:'usr_other',handle:'other',display_name:'Other',text:'A voice note',created_at:'2026-10-13T12:00:00Z',content_kind:'text',media};
            window.PNGEA_API.mediaAccess=async()=>({mimeType:'audio/wav',url:'http://localhost/voice.wav'});
            window.PNGEA_API.feed=async()=>({items:[window.voicePost]});
            window.PNGEA_API.post=async()=>window.voicePost;
            window.PNGEA_API.postReplies=async()=>({items:[]});
            return window.PNGEA_LIVE.loadFeed();
        }""", count)
        self.page.wait_for_function("document.querySelectorAll('#Home .pngeaVoiceNote').length>0")

    def test_feed_and_post_detail_use_same_voice_player(self):
        self.install_voice_post()
        player=self.page.locator('#Home .pngeaVoiceNote')
        self.assertEqual(player.locator('audio[controls]').count(),0)
        self.assertEqual(player.locator('.pngeaVoiceBars i').count(),40)
        self.assertLessEqual(player.bounding_box()['width'],320)
        self.page.locator('#Home [data-live-action="reply"]').click()
        self.page.wait_for_function("document.querySelector('#pngeaPostBody .pngeaVoiceNote')")
        self.assertEqual(self.page.locator('#pngeaPostBody .pngeaVoiceBars i').count(),40)
        self.assertEqual(self.errors,[])

    def test_voice_caption_keeps_inline_reply_beside_the_waveform(self):
        self.install_voice_post()
        self.page.locator('#Home [data-live-action="reply"]').click()
        self.page.wait_for_selector('#pngeaPostBody .pngeaVoiceNote')
        self.assertFalse(self.page.locator('#pngeaPostReplyInput').evaluate('(input)=>input.readOnly'))
        self.page.locator('#pngeaPostReplyInput').focus()
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertTrue(self.page.locator('#pngeaPostBody .pngeaVoiceNote').is_visible())
        self.assertEqual(self.page.evaluate('document.activeElement.id'),'pngeaPostReplyInput')

    def test_playback_decodes_actual_waveform_and_seeking_fills_bars(self):
        self.install_voice_post()
        player=self.page.locator('#Home .pngeaVoiceNote')
        player.locator('.pngeaVoicePlay').click()
        self.page.wait_for_function("document.querySelector('#Home .pngeaVoiceNote').dataset.waveform==='decoded'")
        heights=player.locator('.pngeaVoiceBars i').evaluate_all('(bars)=>bars.map(bar=>bar.style.height)')
        self.assertGreater(len(set(heights)),5)
        self.page.wait_for_function("!document.querySelector('#Home .pngeaVoiceSeek').disabled")
        player.locator('.pngeaVoiceSeek').evaluate("seek=>{seek.value='750';seek.dispatchEvent(new Event('input'));seek.dispatchEvent(new Event('change'))}")
        self.page.wait_for_function("document.querySelector('#Home .pngeaVoiceNote audio').currentTime>2.8 && !document.querySelector('#Home .pngeaVoiceNote audio').seeking")
        self.page.wait_for_function("document.querySelectorAll('#Home .pngeaVoiceBars .heard').length>=29")
        self.assertGreater(player.locator('audio').evaluate('(audio)=>audio.currentTime'),2.8)
        self.assertGreaterEqual(player.locator('.pngeaVoiceBars .heard').count(),29)
        self.assertIn('of 0:04',player.locator('.pngeaVoiceSeek').get_attribute('aria-valuetext'))
        self.assertFalse(self.page.locator('#pngeaPostPage').is_visible())
        self.assertEqual(self.errors,[])

    def test_only_one_voice_note_plays_at_a_time(self):
        self.install_voice_post(count=2)
        self.page.wait_for_function("document.querySelectorAll('#Home .pngeaVoiceNote').length===2")
        players=self.page.locator('#Home .pngeaVoiceNote')
        players.nth(0).locator('.pngeaVoicePlay').click()
        self.page.wait_for_function("!document.querySelectorAll('#Home .pngeaVoiceNote audio')[0].paused")
        players.nth(1).locator('.pngeaVoicePlay').click()
        self.page.wait_for_function("!document.querySelectorAll('#Home .pngeaVoiceNote audio')[1].paused")
        self.assertTrue(players.nth(0).locator('audio').evaluate('(audio)=>audio.paused'))

    def test_chat_voice_notes_share_playback_and_progress_controls(self):
        self.page.evaluate("""()=>{
            window.PNGEA_API.mediaAccess=async()=>({mimeType:'audio/wav',url:'http://localhost/voice.wav'});
            window.PNGEA_API.messages=async()=>({items:[{id:'msg_voice',sender_id:'usr_other',media:[{id:'voice_chat',mimeType:'audio/wav',durationMs:4000}],created_at:'2026-10-13T12:00:00Z'}]});
        }""")
        self.navigate('Inbox','cnv_a')
        player=self.page.locator('#dmMessages .pngeaVoiceNote')
        player.wait_for()
        player.locator('.pngeaVoicePlay').click()
        self.page.wait_for_function("document.querySelectorAll('#dmMessages .pngeaVoiceBars .heard').length>0")
        self.assertGreater(player.locator('.pngeaVoiceBars .heard').count(),0)
        player.locator('.pngeaVoicePlay').click()
        self.assertTrue(player.locator('audio').evaluate('(audio)=>audio.paused'))
        self.assertEqual(self.errors,[])

    def test_waveform_decode_failure_keeps_audio_playable(self):
        self.install_voice_post()
        self.page.evaluate("""()=>{const original=window.fetch;window.fetch=(url,...options)=>String(url).endsWith('/voice.wav')?Promise.reject(new TypeError('Fixture CORS denial')):original(url,...options)}""")
        player=self.page.locator('#Home .pngeaVoiceNote')
        player.locator('.pngeaVoicePlay').click()
        self.page.wait_for_function("document.querySelectorAll('#Home .pngeaVoiceBars .heard').length>0")
        self.assertEqual(player.get_attribute('data-waveform'),'uniform')
        self.assertGreater(player.locator('.pngeaVoiceBars .heard').count(),0)
        self.assertEqual(self.errors,[])


if __name__ == '__main__':
    unittest.main(verbosity=2)
