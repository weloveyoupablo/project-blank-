"""Browser regressions using isolated API fixtures; never contacts production."""
import json
import os
import re
import unittest
from pathlib import Path
from urllib.parse import urlsplit, unquote
from playwright.sync_api import sync_playwright

ROOT = Path(os.environ.get('PNGEA_ROOT', str(Path(__file__).resolve().parents[1])))
ME = dict(id='usr_self', handle='tester', display_name='Tester', account_key='0123456789abcdef',
          avatar_media_id=None, banner_media_id=None, avatar_url='http://localhost/self.svg',
          banner_url='http://localhost/self-banner.svg', followers=1, following=1)
OTHER = dict(id='usr_other', handle='other', display_name='Other', avatar_media_id=None,
             banner_media_id=None, avatar_url='http://localhost/other.svg', banner_url='http://localhost/other-banner.svg')
POST = dict(id='pst_real', author_id='usr_other', handle='other', display_name='Other', text='Real fixture post',
            created_at='2026-10-13T12:00:00Z', viewer_liked=False, viewer_reposted=False, likes=2, replies=0, reposts=0, media=[])
CONVERSATIONS = [dict(id='cnv_a', members=[dict(id='usr_other', handle='other', displayName='Other')], unread=0),
                 dict(id='cnv_b', members=[dict(id='usr_b', handle='second', displayName='Second')], unread=0)]

class Reliability(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()

    def setUp(self):
        self.page = self.browser.new_page(viewport=dict(width=390, height=844))
        self.requests=[]
        self.errors = []
        self.page.set_default_timeout(4000)
        self.page.on('pageerror', lambda error: self.errors.append(str(error)))
        self.page.route('**/*', self.route)
        self.page.add_init_script("localStorage.setItem('pngea:accessToken','test-token')")
        self.page.goto('http://localhost/', wait_until='domcontentloaded')
        self.page.wait_for_function('window.PNGEA_LIVE?.state?.active')
        self.page.wait_for_timeout(1200)

    def tearDown(self):
        self.page.close()

    def route(self, route):
        url = urlsplit(route.request.url)
        path = unquote(url.path)
        self.requests.append((route.request.method,path))
        if url.hostname == 'localhost' and url.port in (None, 80):
            if path.endswith('.mp4'):
                route.fulfill(content_type='video/mp4',body=(ROOT/path.lstrip('/')).read_bytes())
            elif path.endswith('.svg'):
                route.fulfill(content_type='image/svg+xml', body='<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50"><rect width="50" height="50" fill="red"/></svg>')
            else:
                file = ROOT / (path.lstrip('/') or 'index.html')
                body=file.read_text() if file.is_file() else ''
                if getattr(self,'defer_core',False) and file.name=='index.html': body=re.sub(r'<script src="\./pngea-core.js[^"]*"></script>','',body)
                route.fulfill(content_type='text/javascript' if file.suffix == '.js' else 'text/html', body=body)
            return
        data = dict(items=[])
        if path == '/health': data = dict(ok=True)
        elif path == '/v1/me': data = ME
        elif path == '/v1/me/posts' or path.endswith('/posts') or path == '/v1/feed': data = dict(items=[POST])
        elif path == '/v1/posts/pst_real': data = POST
        elif path == '/v1/conversations': data = dict(items=CONVERSATIONS)
        elif '/messages' in path: data = dict(items=[dict(id='msg_'+path.split('/')[3], text='Message '+path.split('/')[3], sender_id='usr_other', media=[], created_at='2026-10-13T12:00:00Z')])
        elif path.endswith('/followers') or path.endswith('/following') or path == '/v1/me/close-friends': data = dict(items=[OTHER])
        elif path.startswith('/v1/users/'): data = OTHER
        elif path == '/v1/search': data = dict(people=[OTHER], posts=[])
        elif path == '/v1/communities': data = dict(items=[dict(id='com_real',name='Real community',description='A test community',members=1,viewer_member=False)])
        elif path == '/v1/me/settings': data = dict(permissions={})
        elif path == '/v1/realtime/ticket': data = dict(ticket='test')
        elif path == '/v1/me/unread-counts': data = dict(messages=0, notifications=0)
        elif path == '/v1/ticker': data = dict(items=[dict(key='news:test', kind='news', label='NEWS', source='Reuters', text='Test headline', asOf='2026-10-13T12:00:00Z')])
        route.fulfill(status=200, content_type='application/json', body=json.dumps(data))

    def navigate(self, screen, detail=''):
        self.page.evaluate('([s,d])=>window.PNGEA.navigate(s,d)', [screen, detail])
        self.page.wait_for_timeout(600)

    def test_boot_has_no_runtime_errors(self):
        self.assertEqual(self.errors, [])

    def test_single_external_script_loads(self):
        scripts=self.page.locator('script[src]').evaluate_all('(nodes)=>nodes.map(n=>n.src)')
        self.assertEqual(len(scripts), len(set(scripts)))

    def test_history_library_keeps_its_host(self):
        self.navigate('History')
        self.assertEqual(self.page.locator('.pngeaLibraryList').count(), 1)
        self.assertIn('No saved yet', self.page.locator('#History .xScroll').inner_text())

    def test_other_profile_has_other_artwork(self):
        self.navigate('Profile', 'other')
        self.page.wait_for_timeout(500)
        self.assertIn('other-banner.svg', self.page.locator('#Profile .profileCover').evaluate('(el)=>el.style.backgroundImage'))
        self.assertIn('other.svg', self.page.locator('#Profile .xAvatar.big img').get_attribute('src'))

    def test_avatar_removal_clears_painted_images(self):
        self.page.evaluate("window.PNGEA_API.me=async()=>({...window.PNGEA_LIVE.state.me,avatar_url:null,avatar_media_id:null}); window.PNGEA_LIVE.state.me.avatar_url=null; window.PNGEA_LIVE.state.me.avatar_media_id=null")
        self.navigate('Profile', 'tester')
        self.page.wait_for_timeout(500)
        self.assertEqual(self.page.locator('#youButton img').count(), 0)

    def test_failed_send_preserves_draft_and_retry_identity(self):
        self.navigate('Inbox', 'cnv_a')
        self.page.evaluate("()=>{window.sentBodies=[]; window.PNGEA_API.sendMessage=async(id,b)=>{window.sentBodies.push(b);throw new Error('Send failed')};void 0}")
        self.page.locator('#dmInput').fill('Keep this draft')
        self.page.locator('#dmSend').click()
        self.page.wait_for_timeout(200)
        self.assertEqual(self.page.locator('#dmInput').input_value(), 'Keep this draft')
        self.page.locator('#dmSend').click()
        self.page.wait_for_timeout(200)
        bodies=self.page.evaluate('window.sentBodies')
        self.assertEqual(len(bodies), 2)
        self.assertEqual(bodies[0]['clientId'], bodies[1]['clientId'])

    def test_stale_thread_response_cannot_overwrite_current_thread(self):
        self.page.evaluate("window.PNGEA_API.messages=async id=>{await new Promise(r=>setTimeout(r,id==='cnv_a'?700:30));return {items:[{id:'msg_'+id,text:'Only '+id,sender_id:'usr_other',media:[]}]}};window.PNGEA.navigate('Inbox','cnv_a');setTimeout(()=>window.PNGEA.navigate('Inbox','cnv_b'),20)")
        self.page.wait_for_timeout(1000)
        self.assertIn('Only cnv_b', self.page.locator('#dmMessages').inner_text())
        self.assertNotIn('Only cnv_a', self.page.locator('#dmMessages').inner_text())

    def test_ticker_retains_nodes_across_navigation(self):
        self.page.evaluate("window.tickerNode=document.querySelector('#tickerTrack .tickerItem')")
        self.navigate('Search')
        self.navigate('Home')
        self.assertTrue(self.page.evaluate("!!window.tickerNode && window.tickerNode===document.querySelector('#tickerTrack .tickerItem')"))

    def test_followers_avatar_is_hydrated_from_list(self):
        self.navigate('Profile', 'tester')
        self.page.locator('#Profile .profileStats span').nth(1).click()
        self.page.wait_for_timeout(250)
        self.assertEqual(self.page.locator('#pngeaConnectionsList img').count(), 1)

    def test_close_friend_can_be_removed(self):
        self.navigate('CloseFriends')
        self.assertEqual(self.page.locator('[data-close-friend="usr_other"]').count(), 1)
        self.page.locator('[data-close-friend="usr_other"]').click()
        self.page.locator('#pngeaProfileSocialSheet button').get_by_text('Remove',exact=True).click()
        self.page.wait_for_timeout(200)
        self.assertIn(('DELETE','/v1/me/close-friends/usr_other'),self.requests)

    def test_reaction_reconciliation_cannot_override_new_intent(self):
        self.page.evaluate("""()=>{
          window.PNGEA_API.likePost=async()=>({liked:true});
          window.PNGEA_API.unlikePost=async()=>{await new Promise(r=>setTimeout(r,1500));return {liked:false}};
          window.PNGEA_API.post=async()=>{await new Promise(r=>setTimeout(r,500));return {id:'pst_real',viewer_liked:true,likes:3,reposts:0,replies:0}};
        }""")
        action=self.page.locator('#feed [data-live-action="like"]').first
        action.click()
        self.page.wait_for_timeout(700)
        action.click()
        self.page.wait_for_timeout(600)
        self.assertNotIn('activeAction',action.get_attribute('class'))
        self.assertFalse(self.page.locator('#pnActionSheet').evaluate('(el)=>el.classList.contains("show")'))

    def test_community_discover_join_and_open(self):
        self.navigate('Communities')
        self.page.locator('[data-community-tab="discover"]').click()
        self.page.wait_for_timeout(200)
        self.page.locator('[data-community-join="com_real"]').click()
        self.page.wait_for_timeout(200)
        self.assertIn(('PUT','/v1/communities/com_real/join'),self.requests)
        self.page.locator('#pngeaCommunitiesList [data-community-id="com_real"]').click()
        self.page.wait_for_timeout(200)
        self.assertEqual(self.page.locator('#pngeaCommunityName').inner_text(),'Real community')
        self.assertIn(('GET','/v1/communities/com_real/feed'),self.requests)

    def test_history_activity_and_library_tabs_do_not_replace_each_other(self):
        self.navigate('History')
        self.page.locator('[data-library-tab="activity"]').click()
        self.page.wait_for_timeout(100)
        self.assertEqual(self.page.locator('#pngeaActivityHistory').count(),1)
        self.page.locator('[data-library-tab="saved"]').click()
        self.page.wait_for_timeout(150)
        self.assertEqual(self.page.locator('.pngeaLibraryList').count(),1)
        self.assertEqual(self.page.locator('#pngeaActivityHistory').count(),0)

    def test_unchanged_thread_poll_preserves_message_nodes(self):
        self.navigate('Inbox','cnv_a')
        self.page.evaluate("window.messageNode=document.querySelector('#dmMessages [data-message-id]')")
        self.page.evaluate("window.PNGEA_CORE.loadThread('cnv_a')")
        self.assertTrue(self.page.evaluate("!!window.messageNode && window.messageNode===document.querySelector('#dmMessages [data-message-id]')"))

    def test_ticker_empty_response_removes_obsolete_updates(self):
        self.page.evaluate("()=>{window.PNGEA_API.ticker=async()=>({items:[]})}")
        self.page.evaluate("window.PNGEA_CORE.refreshTicker()")
        self.assertNotIn('Test headline',self.page.locator('#tickerTrack').inner_text())

    def test_failed_profile_save_keeps_canonical_identity(self):
        self.navigate('Profile','tester')
        self.page.locator('#Profile .profileEdit').click()
        self.page.locator('#peName').fill('Unsaved name')
        self.page.locator('#peHandle').fill('unsaved_handle')
        self.page.evaluate("()=>{window.PNGEA_API.updateProfile=async()=>{throw new Error('Save failed')}}")
        self.page.locator('#profileEditSave').click()
        self.page.wait_for_timeout(250)
        self.assertEqual(self.page.evaluate('window.PNGEA_LIVE.state.me.display_name'),'Tester')
        self.assertTrue(self.page.locator('#profileEditLayer').evaluate('(el)=>el.classList.contains("show")'))

    def test_earlier_message_page_is_reachable(self):
        self.page.evaluate("()=>{window.PNGEA_API.messages=async(id,params={})=>params.before?{items:[{id:'msg_old',text:'Earlier message',sender_id:'usr_other',media:[]}],nextCursor:null}:{items:[{id:'msg_new',text:'Latest message',sender_id:'usr_other',media:[]}],nextCursor:'older-page'}}")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#pngeaLoadEarlier').click()
        self.page.wait_for_timeout(200)
        self.assertIn('Earlier message',self.page.locator('#dmMessages').inner_text())
        self.assertIn('Latest message',self.page.locator('#dmMessages').inner_text())

    def test_real_feed_and_reaction_observer_settle(self):
        self.assertIn('Real fixture post',self.page.locator('#feed').inner_text())
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_real"]').count(),1)
        self.page.evaluate("window.mutationCount=0;window.testObserver=new MutationObserver(m=>window.mutationCount+=m.length);window.testObserver.observe(document.querySelector('#feed'),{childList:true,subtree:true})")
        self.page.wait_for_timeout(500)
        self.assertLess(self.page.evaluate('window.mutationCount'),20)

    def test_core_initializes_ticker_when_auth_finishes_before_script_load(self):
        self.page.close()
        self.defer_core=True
        self.page=self.browser.new_page()
        self.page.set_default_timeout(3000)
        self.page.route('**/*',self.route)
        self.page.add_init_script("localStorage.setItem('pngea:accessToken','test-token')")
        self.page.goto('http://localhost/',wait_until='domcontentloaded')
        self.page.wait_for_function('window.PNGEA_LIVE?.state?.active')
        self.page.add_script_tag(path=str(ROOT/'pngea-core.js'))
        self.page.wait_for_function("document.querySelector('#tickerTrack').textContent.includes('Test headline')",timeout=2000)

    def test_new_messages_do_not_drop_the_oldest_loaded_window_edge(self):
        self.page.evaluate("()=>{window.messagePhase=0;window.PNGEA_API.messages=async(id,params={})=>params.before?{items:[{id:'msg_old',text:'Earlier page',sender_id:'usr_other',media:[]}],nextCursor:null}:{items:[...(window.messagePhase?[]:[{id:'msg_edge',text:'Window edge',sender_id:'usr_other',media:[]}]),{id:'msg_last',text:'Latest',sender_id:'usr_other',media:[]}],nextCursor:'older-page'}}")
        self.navigate('Inbox','cnv_a')
        self.page.evaluate("window.messagePhase=1;window.PNGEA_CORE.loadThread('cnv_a')")
        self.page.locator('#pngeaLoadEarlier').click()
        self.page.wait_for_timeout(200)
        self.assertIn('Window edge',self.page.locator('#dmMessages').inner_text())
        self.assertIn('Earlier page',self.page.locator('#dmMessages').inner_text())

    def test_no_demo_posts_remain(self):
        self.assertEqual(self.page.locator('#feed [data-demo-content="true"]').count(), 0)

    def test_transient_send_retries_without_another_tap(self):
        self.page.evaluate("()=>{window.sentBodies=[];window.PNGEA_API.sendMessage=async(id,body)=>{window.sentBodies.push(body);if(window.sentBodies.length===1)throw Object.assign(new Error('Unavailable'),{status:503});return {id:'msg_ack'}}}")
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').fill('Retry automatically')
        self.page.locator('#dmSend').click()
        self.page.wait_for_function("window.sentBodies.length===2 && document.querySelector('#dmInput').value===''")
        bodies=self.page.evaluate('window.sentBodies')
        self.assertEqual(bodies[0]['clientId'],bodies[1]['clientId'])

    def test_receipt_changes_do_not_mark_same_message_read_again(self):
        self.page.evaluate("window.readCalls=0;window.PNGEA_API.markConversationRead=async()=>{window.readCalls++;return {ok:true}};window.receipt=0;window.PNGEA_API.messages=async()=>({items:[{id:'msg_in',sender_id:'usr_other',text:'Incoming',media:[],read_by:[{userId:'usr_self',readAt:String(window.receipt++)}]}]})")
        self.navigate('Inbox','cnv_a')
        self.page.wait_for_function('window.readCalls===1')
        self.page.evaluate("window.PNGEA_CORE.loadThread('cnv_a')")
        self.page.wait_for_timeout(200)
        self.assertEqual(self.page.evaluate('window.readCalls'),1)

    def test_thread_loads_without_waiting_for_conversation_list(self):
        self.page.evaluate("()=>{window.PNGEA_LIVE.state.conversations=[];window.PNGEA_LIVE.loadConversations=()=>new Promise(()=>{});window.PNGEA_API.messages=async(id,params)=>{window.requestedLimit=params.limit;return {items:[{id:'msg_fast',sender_id:'usr_other',text:'Fast thread',media:[]}]}}}")
        self.navigate('Inbox','cnv_a')
        self.page.wait_for_function("document.querySelector('#dmMessages').textContent.includes('Fast thread')")
        self.assertEqual(self.page.evaluate('window.requestedLimit'),50)

    def test_keyboard_viewport_keeps_composer_visible(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        bottom=self.page.locator('.dmCompose').bounding_box()
        self.assertLessEqual(bottom['y']+bottom['height'],461)

    def test_sidebar_pages_can_always_exit(self):
        for screen in ['Communities','CloseFriends','History','Dating','Wallet','Shop','Activity','Settings']:
            self.navigate(screen)
            self.page.locator('#'+screen+' .xBack[data-screen],#'+screen+' .back[data-screen]').first.click()
            self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Home'")

    def test_dating_action_and_community_plus(self):
        self.assertEqual(self.page.locator('#pnAdaptive [data-adaptive-screen="Dating"]').count(),1)
        self.assertEqual(self.page.locator('#pnAdaptive [data-adaptive-screen="Inbox"]').count(),0)
        self.navigate('Communities')
        self.assertEqual(self.page.locator('#Communities .xTop #pngeaCommunityCreate').count(),1)
        self.page.locator('#pngeaCommunityCreate').click()
        self.assertEqual(self.page.locator('#pngeaCommunityToolTitle').inner_text(),'Create community')

    def test_share_sends_post_inside_pngea(self):
        self.page.evaluate("()=>{window.sharedBodies=[];window.PNGEA_API.sendMessage=async(id,body)=>{window.sharedBodies.push({id,body});return {id:'msg_share'}};navigator.share=()=>{throw new Error('Native sharing must not open')}}")
        self.page.locator('#feed [data-live-action="share"]').first.click()
        self.page.locator('#pngeaSendPostPeople [data-recipient="cnv_a"]').click()
        self.page.wait_for_function('window.sharedBodies.length===1')
        sent=self.page.evaluate('window.sharedBodies[0]')
        self.assertEqual(sent['id'],'cnv_a')
        self.assertIn('#/post/pst_real',sent['body']['text'])
        self.assertEqual(self.page.locator('#pngeaSendPostPeople [data-recipient="cnv_a"]').inner_text(),'Sent')

    def test_delete_option_only_appears_on_own_posts(self):
        self.page.locator('#feed .more').first.click()
        self.assertEqual(self.page.locator('[data-pngea516-action="delete"]').count(),0)
        self.page.locator('#pnActionClose').click()
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>({items:[{id:'pst_mine',author_id:'usr_self',handle:'tester',display_name:'Tester',text:'My post',media:[]}]});window.deleted=[];window.PNGEA_API.deletePost=async(id)=>{window.deleted.push(id);return {ok:true}}}")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.page.locator('#feed .more').first.click()
        self.page.locator('[data-pngea516-action="delete"]').click()
        self.page.wait_for_function("window.deleted[0]==='pst_mine'")
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_mine"]').count(),0)

    def test_own_profile_uses_canonical_post_count(self):
        self.page.evaluate("()=>{window.PNGEA_API.me=async()=>({...window.PNGEA_LIVE.state.me,posts_count:3});window.PNGEA_API.myPosts=async()=>({items:[]})}")
        self.navigate('Profile','tester')
        self.page.wait_for_function("document.querySelector('#Profile .xTopTitle small').textContent==='3 posts'")

    def test_long_form_has_title_and_no_bottom_toolbar(self):
        self.page.locator('.compose').click()
        self.page.locator('#composerLayer [data-attach="longform"]').click()
        self.assertTrue(self.page.locator('#pngeaLongTitleInput').is_visible())
        self.assertFalse(self.page.locator('#composerLayer .capture').is_visible())
        self.assertEqual(self.page.locator('#postText').get_attribute('maxlength'),None)
        self.assertEqual(self.page.locator('#composerLayer .captureHint').count(),0)
        result=self.page.evaluate("()=>{const p={id:'long_test',author_id:'usr_other',handle:'other',display_name:'Other',content_kind:'longform',title:'A real title',text:'The body stays in the detail page',media:[]};return window.PNGEA_CORE.renderPost(p,p)}")
        self.assertIn('A real title',result)
        self.assertNotIn('The body stays in the detail page',result)

    def test_long_form_post_saves_format_and_title(self):
        self.page.evaluate("()=>{window.createdBody=null;window.PNGEA_API.createPost=async body=>{window.createdBody=body;return {id:'pst_long'}}}")
        self.page.locator('.compose').click()
        self.page.locator('#composerLayer [data-attach="longform"]').click()
        self.page.locator('#pngeaLongTitleInput').fill('My title')
        self.page.locator('#postText').fill('A long-form body')
        self.page.locator('#send').click()
        self.page.wait_for_function('window.createdBody!==null')
        body=self.page.evaluate('window.createdBody')
        self.assertEqual(body['contentKind'],'longform')
        self.assertEqual(body['title'],'My title')

    def test_formats_and_video_duration_boundary(self):
        formats=self.page.evaluate("()=>[window.PNGEA_CORE.postFormat({content_kind:'gallery',media:[]}),window.PNGEA_CORE.postFormat({content_kind:'text',media:[]}),...[89999,90000,120000].map(durationMs=>window.PNGEA_CORE.postFormat({media:[{mimeType:'video/mp4',durationMs}]}))]")
        self.assertEqual(formats,['gallery','text','reel','video','video'])
        order=self.page.evaluate("()=>{const p={id:'photo',handle:'other',display_name:'Other',text:'Caption',content_kind:'gallery',media:[{id:'med',mimeType:'image/png'}]};const gallery=window.PNGEA_CORE.renderPost(p,p);p.content_kind='text';return [gallery,window.PNGEA_CORE.renderPost(p,p)]}")
        self.assertLess(order[0].index('data-media-rail'),order[0].index('Caption'))
        self.assertLess(order[1].index('Caption'),order[1].index('data-media-rail'))

    def test_photo_sizing_is_shared_across_post_hosts(self):
        sizes=self.page.evaluate("()=>{const p={id:'photo_size',handle:'other',display_name:'Other',media:[]};return ['feed','pngeaCloseFeed','pngeaHistoryLibrary'].map(id=>{let host=document.getElementById(id);if(!host){host=document.createElement('div');host.id=id;document.body.appendChild(host)}host.innerHTML=window.PNGEA_CORE.renderPost(p,p);const img=document.createElement('img');host.querySelector('.liveMediaRail').appendChild(img);const style=getComputedStyle(img);return [style.aspectRatio,style.maxHeight,style.objectFit]})}")
        self.assertEqual(sizes[0],sizes[1]);self.assertEqual(sizes[1],sizes[2]);self.assertEqual(sizes[0][0],'auto');self.assertEqual(sizes[0][2],'cover')

    def test_badges_are_attached_to_icon_corners(self):
        self.page.evaluate("()=>{window.PNGEA_API.unreadCounts=async()=>({messages:4,notifications:3});window.dispatchEvent(new Event('focus'))}")
        self.page.wait_for_function("document.querySelector('#pngeaInboxBadge').textContent==='4'")
        self.assertEqual(self.page.locator('.pngeaNavIcon #pngeaInboxBadge').count(),1)
        self.assertEqual(self.page.locator('.pngeaNavIcon #pngeaNotifBadge').count(),1)

    def test_keyboard_resizes_chat_frame_without_moving_header(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        before=self.page.locator('#dmThread .xTop').bounding_box()['y']
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        bar=self.page.locator('.dmCompose').bounding_box()
        nav=self.page.locator('.bottom').bounding_box()
        self.assertGreaterEqual(nav['y'],460)
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertTrue(self.page.locator('.bottom').is_visible())
        self.assertEqual(self.page.locator('#dmThread .xTop').bounding_box()['y'],before)
        self.assertEqual(self.page.locator('.dmCompose').evaluate('(e)=>getComputedStyle(e).position'),'relative')

    def test_post_detail_reply_compact_and_keyboard_bar(self):
        self.page.evaluate("()=>{window.PNGEA_API.postReplies=async()=>({items:[{id:'rep_compact',author_id:'usr_other',handle:'other',display_name:'Other',text:'Compact reply',media:[]}]})}")
        self.page.locator('#feed .xPostText').first.click()
        self.page.wait_for_selector('#pngeaReplyList .pngeaReplyItem')
        self.assertEqual(self.page.locator('.pngeaReplyItem .pngeaDetailText').evaluate('(e)=>getComputedStyle(e).fontSize'),'15px')
        self.page.locator('#pngeaPostReplyInput').focus()
        before=self.page.locator('#pngeaPostPage .pngeaPostTop').bounding_box()['y']
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        bar=self.page.locator('#pngeaPostReplyBar').bounding_box()
        nav=self.page.locator('.bottom').bounding_box()
        self.assertGreaterEqual(nav['y'],460)
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertTrue(self.page.locator('.bottom').is_visible())
        self.assertEqual(self.page.locator('#pngeaPostPage .pngeaPostTop').bounding_box()['y'],before)
        self.page.locator('#pngeaPostBack').click()
        self.assertFalse(self.page.locator('#pngeaPostPage').is_visible())

    def test_gallery_picker_browses_photos_and_videos(self):
        self.page.locator('.compose').click()
        with self.page.expect_file_chooser() as chooser:
            self.page.locator('#composerLayer [data-attach="gallery"]').click()
        self.assertTrue(chooser.value.is_multiple())
        self.assertEqual(self.page.locator('#pngeaGalleryInput').get_attribute('accept'),'image/*,video/*')
        self.assertIsNone(self.page.locator('#pngeaGalleryInput').get_attribute('capture'))
        chooser.value.set_files(dict(name='photo.png',mimeType='image/png',buffer=bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001a5f645400000000049454e44ae426082')))
        self.assertTrue(self.page.locator('#composerLayer').is_visible())
        self.assertEqual(self.page.locator('#composerLayer').get_attribute('data-post-kind'),'gallery')
        self.assertEqual(self.page.locator('#postText').get_attribute('placeholder'),'Write a caption…')

    def test_typing_before_gallery_keeps_text_post_format(self):
        self.page.locator('.compose').click()
        self.page.locator('#postText').fill('Text first')
        with self.page.expect_file_chooser():
            self.page.locator('#composerLayer [data-attach="gallery"]').click()
        self.assertNotEqual(self.page.locator('#composerLayer').get_attribute('data-post-kind'),'gallery')

    def test_reel_has_autoplay_overlay_and_expands_with_seek_controls(self):
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>({items:[{id:'reel_test',author_id:'usr_other',handle:'other',display_name:'Other',text:'A reel',media:[{id:'video_test',mimeType:'video/mp4',durationMs:30000}]}]});window.PNGEA_API.mediaAccess=async()=>({mimeType:'video/mp4',url:'http://localhost/tests/fixtures/reel.mp4'})}")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        video=self.page.locator('#feed video')
        self.page.wait_for_function("document.querySelector('#feed video')?.dataset.pngeaReel==='true'")
        self.assertEqual(video.evaluate('(v)=>[v.muted,v.autoplay,v.loop,v.controls]'),[True,True,True,True])
        self.page.wait_for_function("document.querySelector('#feed video').currentTime>0 && !document.querySelector('#feed video').paused")
        self.assertEqual(video.evaluate('(v)=>getComputedStyle(v).aspectRatio'),'9 / 16')
        self.assertEqual(self.page.locator('#feed .pngeaCardHeader').evaluate('(e)=>getComputedStyle(e).position'),'absolute')
        video.click(position=dict(x=30,y=80))
        self.assertTrue(self.page.locator('#pngeaMediaViewer').is_visible())
        self.assertTrue(self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>v.controls'))

    def test_reply_action_uses_the_single_comment_view(self):
        self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_function("document.querySelector('#pngeaPostPage').classList.contains('show')")
        self.assertEqual(self.page.locator('#pngeaReplyPage').count(),0)
        self.assertEqual(self.page.evaluate('document.activeElement.id'),'pngeaPostReplyInput')

    def test_short_thread_has_no_blank_gap_above_keyboard(self):
        self.page.evaluate("()=>{window.PNGEA_API.postReplies=async()=>({items:[]})}")
        self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_timeout(200)
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        body=self.page.locator('#pngeaPostBody').bounding_box()
        bar=self.page.locator('#pngeaPostReplyBar').bounding_box()
        self.assertLessEqual(abs(bar['y']-body['y']-body['height']),3)

    def test_you_profile_alias_counts_own_posts(self):
        self.page.evaluate("()=>{window.PNGEA_API.me=async()=>({...window.PNGEA_LIVE.state.me,posts_count:3});window.PNGEA_API.myPosts=async()=>({items:[]})}")
        self.navigate('Profile','you')
        self.page.wait_for_function("document.querySelector('#Profile .xTopTitle small').textContent==='3 posts'")
        self.assertEqual(self.page.locator('#Profile .profileEdit').inner_text(),'Edit profile')

    def test_gallery_photo_opens_the_comment_view(self):
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>({items:[{id:'pst_real',author_id:'usr_other',handle:'other',display_name:'Other',content_kind:'gallery',text:'Caption',media:[{id:'photo',mimeType:'image/png'}]}]});window.PNGEA_API.mediaAccess=async()=>({mimeType:'image/png',url:'http://localhost/other.svg'})}")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.page.locator('#feed .liveMediaRail img').click()
        self.assertTrue(self.page.locator('#pngeaPostPage').is_visible())
        self.assertFalse(self.page.locator('#pngeaMediaViewer').is_visible())

    def test_composer_icons_have_consistent_visible_sizes(self):
        self.page.locator('.compose').click()
        icons=self.page.locator('#composerLayer .cap svg').evaluate_all('(icons)=>icons.map(e=>{const r=e.getBoundingClientRect();return [r.width,r.height,getComputedStyle(e).fill]})')
        self.assertEqual(icons,[[24,24,'none']]*4)

    def test_home_has_no_gallery_shortcut(self):
        self.assertEqual(self.page.locator('#pngeaGalleryPost').count(),0)
        self.assertEqual(self.page.locator('#Home .top button').count(),0)

    def test_historical_photo_posts_have_no_outer_bubble(self):
        formats=self.page.evaluate("()=>{const p={id:'legacy_photo',handle:'other',display_name:'Other',content_kind:'text',text:'Old caption',media:[{id:'photo',mimeType:'image/png'}]};const box=document.createElement('div');box.innerHTML=window.PNGEA_CORE.renderPost(p,p);document.body.appendChild(box);const card=box.firstElementChild,style=getComputedStyle(card);return [card.dataset.postFormat,style.borderTopWidth,style.borderRadius]}")
        self.assertEqual(formats,['text','1px','20px'])

    def test_only_latest_sent_message_has_a_receipt(self):
        self.page.evaluate("()=>{window.PNGEA_API.messages=async()=>({items:[{id:'one',sender_id:'usr_self',text:'First',read_by:[{userId:'usr_other'}]},{id:'two',sender_id:'usr_self',text:'Latest',read_by:[{userId:'usr_other'}]}]})}")
        self.navigate('Inbox','cnv_a')
        self.assertEqual(self.page.locator('.pngeaReadReceipt').count(),1)
        self.assertEqual(self.page.locator('[data-message-id="two"] .pngeaReadReceipt').count(),1)

    def test_new_unread_sent_message_removes_older_receipt(self):
        self.page.evaluate("()=>{window.PNGEA_API.messages=async()=>({items:[{id:'one',sender_id:'usr_self',text:'First',read_by:[{userId:'usr_other'}]},{id:'two',sender_id:'usr_self',text:'Latest unread',read_by:[]}]})}")
        self.navigate('Inbox','cnv_a')
        self.assertEqual(self.page.locator('.pngeaReadReceipt').count(),0)

    def test_keyboard_detection_when_both_viewports_shrink(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.page.wait_for_timeout(50)
        self.page.evaluate("Object.defineProperty(window,'innerHeight',{configurable:true,value:460});Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        bar=self.page.locator('.dmCompose').bounding_box();nav=self.page.locator('.bottom').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)
        self.assertGreaterEqual(nav['y'],460)

    def test_reply_attachment_icons_stay_with_keyboard(self):
        self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        self.assertTrue(self.page.locator('.pngeaReplyTools').is_visible())
        self.assertTrue(self.page.locator('.bottom').is_visible())
        bar=self.page.locator('#pngeaPostReplyBar').bounding_box();nav=self.page.locator('.bottom').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)

    def test_post_composer_toolbar_stays_above_keyboard(self):
        self.page.locator('.compose').click()
        self.page.locator('#postText').focus()
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        toolbar=self.page.locator('#composerLayer .capture').bounding_box();nav=self.page.locator('.bottom').bounding_box()
        self.assertLessEqual(toolbar['y']+toolbar['height'],462)
        self.assertTrue(self.page.locator('#composerLayer .capture').is_visible())

    def test_keyboard_dismissal_restores_navigation_and_composer(self):
        self.navigate('Inbox','cnv_a')
        self.page.locator('#dmInput').focus()
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        self.page.evaluate("document.querySelector('#dmInput').blur();Object.defineProperty(window.visualViewport,'height',{configurable:true,value:844});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("!document.documentElement.classList.contains('pngeaKeyboardOpen')")
        self.assertEqual(self.page.locator('.bottom').evaluate('(e)=>e.style.position'),'')
        self.assertEqual(self.page.locator('.dmCompose').evaluate('(e)=>e.style.top'),'')
        self.assertTrue(self.page.locator('.bottom').is_visible())

if __name__ == '__main__':
    unittest.main(verbosity=2)
