"""Following-feed lifecycle regressions using isolated browser/API fixtures."""
import unittest
try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture


class FollowingRefresh(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    tearDown = fixture.Reliability.tearDown
    route = fixture.Reliability.route
    navigate = fixture.Reliability.navigate

    def setUp(self):
        self.page = self.browser.new_page(viewport=dict(width=390, height=844))
        self.requests, self.errors = [], []
        self.page.set_default_timeout(4000)
        self.page.on('pageerror', lambda error: self.errors.append(str(error)))
        self.page.route('**/*', self.route)
        self.page.add_init_script("""
          localStorage.setItem('pngea:accessToken','test-token');
          window.WebSocket=class {
            static OPEN=1;
            constructor(){this.readyState=1}
            close(){this.readyState=3;queueMicrotask(()=>this.onclose?.())}
          };
        """)
        self.page.goto('http://localhost/', wait_until='domcontentloaded')
        self.page.wait_for_function('window.PNGEA_LIVE?.state.active&&typeof window.PNGEA_LIVE.state.ws?.onmessage==="function"')

    def test_unfollow_removes_home_posts_and_pending_reaction_cannot_restore_them(self):
        self.page.wait_for_function("typeof window.PNGEA_LIVE.state.ws?.onmessage==='function'")
        self.page.evaluate("""()=>{
          window.PNGEA_API.post=()=>new Promise(resolve=>window.releaseReaction=resolve);
          window.PNGEA_LIVE.state.ws.onmessage({data:JSON.stringify({type:'post.reaction.changed',data:{postId:'pst_real'}})});
        }""")
        self.page.wait_for_function("typeof window.releaseReaction==='function'")
        self.navigate('Profile', 'other')
        self.page.evaluate("""()=>{
          document.querySelector('#Profile .profileEdit').dataset.viewerFollowing='1';
          window.unfollowed=false;window.feedReloaded=false;
          window.PNGEA_API.unfollow=async()=>{window.unfollowed=true};
          window.PNGEA_API.feed=async()=>{window.feedReloaded=true;return {items:[]}};
        }""")
        self.page.locator('#Profile .profileEdit').click()
        self.page.wait_for_function('window.unfollowed&&window.feedReloaded')
        self.page.wait_for_function("!document.querySelector('#feed [data-server-post=\"pst_real\"]')")
        self.page.evaluate("window.releaseReaction({id:'pst_real',author_id:'usr_other',handle:'other',display_name:'Other',text:'Stale reaction response',media:[]})")
        self.page.wait_for_timeout(200)
        self.navigate('Home')
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_real"]').count(), 0)

    def test_unfollow_requests_fresh_feed_after_an_older_request_finishes(self):
        self.navigate('Profile', 'other')
        self.page.evaluate("""()=>{
          document.querySelector('#Profile .profileEdit').dataset.viewerFollowing='1';
          window.feedCalls=0;window.unfollowed=false;
          window.PNGEA_API.unfollow=async()=>{window.unfollowed=true};
          window.PNGEA_API.feed=()=>{window.feedCalls++;return window.feedCalls===1?new Promise(resolve=>window.releaseOldFeed=resolve):Promise.resolve({items:[]})};
          window.PNGEA_LIVE.loadFeed();
        }""")
        self.page.wait_for_function("typeof window.releaseOldFeed==='function'")
        self.page.locator('#Profile .profileEdit').click()
        self.page.wait_for_function('window.unfollowed')
        self.page.evaluate("window.releaseOldFeed({items:[{id:'pst_real',author_id:'usr_other',handle:'other',display_name:'Other',text:'Old feed result',media:[]}]})")
        self.page.wait_for_function('window.feedCalls===2')
        self.page.wait_for_function("!document.querySelector('#feed [data-server-post=\"pst_real\"]')")
        self.navigate('Home')
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_real"]').count(), 0)

    def test_follow_from_profile_refreshes_home_without_reloading_the_page(self):
        self.page.evaluate("window.PNGEA_API.feed=async()=>({items:[]})")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.navigate('Profile', 'other')
        self.page.evaluate("""()=>{
          window.followed=false;
          window.PNGEA_API.follow=async()=>{window.followed=true};
          window.PNGEA_API.feed=async()=>({items:window.followed?[{id:'pst_followed',author_id:'usr_other',handle:'other',display_name:'Other',text:'Newly followed author',media:[]}]:[]});
        }""")
        self.page.locator('#Profile .profileEdit').click()
        self.page.wait_for_function("!!document.querySelector('#feed [data-server-post=\"pst_followed\"]')")
        self.navigate('Home')
        self.assertIn('Newly followed author', self.page.locator('#feed').inner_text())

    def test_follow_from_search_refreshes_home_without_reloading_the_page(self):
        self.navigate('Search')
        self.page.evaluate("""()=>{
          window.searchFollowed=false;window.searchFeedReloaded=false;
          window.PNGEA_API.follow=async()=>{window.searchFollowed=true};
          window.PNGEA_API.feed=async()=>{window.searchFeedReloaded=true;return {items:[]}};
        }""")
        self.page.locator('#globalSearchInput').fill('other')
        self.page.locator('#s-for-you [data-live-user-id="usr_other"]').click()
        self.page.wait_for_function('window.searchFollowed&&window.searchFeedReloaded')
        self.assertEqual(self.page.locator('#s-for-you [data-live-user-id="usr_other"]').inner_text(), 'Following')


if __name__ == '__main__':
    unittest.main(verbosity=2)
