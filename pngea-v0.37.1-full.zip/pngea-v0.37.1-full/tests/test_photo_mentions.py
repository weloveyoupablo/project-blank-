"""Photo workflow, mention and interaction regressions using local fixtures."""
import struct
import unittest
import zlib
try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture

class PhotoMentions(unittest.TestCase):
    setUpClass=classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass=classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp=fixture.Reliability.setUp
    tearDown=fixture.Reliability.tearDown
    route=fixture.Reliability.route
    navigate=fixture.Reliability.navigate

    def select_photo(self,camera=False,text=''):
        self.page.locator('.compose').click()
        if text:self.page.locator('#postText').fill(text)
        def chunk(kind,body):return struct.pack('>I',len(body))+kind+body+struct.pack('>I',zlib.crc32(kind+body)&0xffffffff)
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',320,240,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\0'+bytes([130,140,150])*320)*240))+chunk(b'IEND',b'')
        with self.page.expect_file_chooser() as chosen:
            self.page.locator('#composerLayer [data-attach="camera"],#composerLayer [data-attach="gallery"]').nth(1 if camera else 0).click()
        chosen.value.set_files(dict(name='photo.png',mimeType='image/png',buffer=png))

    def render_photo(self):
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>({items:[{id:'pst_real',author_id:'usr_other',handle:'other',display_name:'Other',content_kind:'gallery',text:'Photo caption @tester',viewer_saved:false,media:[{id:'photo',mimeType:'image/png'}]}]});window.PNGEA_API.mediaAccess=async()=>({mimeType:'image/png',url:'http://localhost/other.svg'})}")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.page.wait_for_selector('#feed .liveMediaRail img')

    def test_photo_next_caption_followers_and_actual_crop_upload(self):
        self.select_photo()
        self.assertEqual(self.page.locator('#send').inner_text(),'Next')
        self.assertFalse(self.page.locator('#postText').is_visible())
        self.page.locator('#send').click()
        self.assertTrue(self.page.locator('#pngeaPhotoReview').is_visible())
        self.assertEqual(self.page.locator('#send').inner_text(),'Post')
        self.page.locator('#postText').fill('Caption after selecting a photo')
        self.page.locator('#pngeaPhotoAudience').select_option('followers')
        self.page.evaluate("()=>{window.createdPhoto=null;window.PNGEA_API.createMediaUpload=async()=>({mediaId:'med_photo',uploadUrl:'http://localhost/upload',headers:{}});window.PNGEA_API.completeMedia=async()=>({ok:true});window.PNGEA_API.media=async()=>({status:'ready'});window.PNGEA_API.createPost=async body=>{window.createdPhoto=body;return {id:'pst_new'}};window.XMLHttpRequest=class{constructor(){this.upload={}}open(){}setRequestHeader(){}send(file){window.uploadedPhoto=file;this.status=200;setTimeout(()=>this.onload(),0)}}}")
        self.page.locator('#send').click()
        self.page.wait_for_function('window.createdPhoto!==null')
        created=self.page.evaluate('window.createdPhoto')
        self.assertEqual(created['visibility'],'followers')
        self.assertEqual(created['contentKind'],'gallery')
        self.assertEqual(created['text'],'Caption after selecting a photo')
        dimensions=self.page.evaluate('async()=>{const img=await createImageBitmap(window.uploadedPhoto);return [img.width,img.height]}')
        self.assertAlmostEqual(dimensions[0]/dimensions[1],.8,places=2)

    def test_camera_uses_the_same_next_review_flow(self):
        self.select_photo(camera=True)
        self.assertEqual(self.page.locator('#send').inner_text(),'Next')
        self.page.locator('#send').click()
        self.assertTrue(self.page.locator('#pngeaPhotoReview').is_visible())

    def test_cancel_restore_preserves_photo_draft_audience_caption_and_crop(self):
        self.select_photo();self.page.locator('#send').click()
        self.page.locator('#postText').fill('A followers-only photo draft')
        self.page.locator('#pngeaPhotoAudience').select_option('followers')
        self.page.locator('#pngeaPhotoReviewThumbs button').click()
        self.page.wait_for_function("document.querySelector('#pngeaEditorStage canvas').height>0")
        self.page.locator('#pngeaMediaEditorTools button').get_by_text('1:1',exact=True).click()
        self.page.locator('#pngeaMediaEditorDone').click()
        self.page.locator('#closeComposer').click()
        self.page.locator('#closeComposer').click()
        self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.page.wait_for_function("""async()=>{
            const db=await new Promise(resolve=>{const request=indexedDB.open('pngea-resilience-v1',1);request.onsuccess=()=>resolve(request.result)});
            const drafts=await new Promise(resolve=>{const request=db.transaction('kv').objectStore('kv').get('drafts.v2');request.onsuccess=()=>resolve(request.result||[])});db.close();
            return !!drafts.length;
        }""")
        draft=self.page.evaluate("""async()=>{
            const db=await new Promise(resolve=>{const request=indexedDB.open('pngea-resilience-v1',1);request.onsuccess=()=>resolve(request.result)});
            const drafts=await new Promise(resolve=>{const request=db.transaction('kv').objectStore('kv').get('drafts.v2');request.onsuccess=()=>resolve(request.result||[])});db.close();
            const draft=drafts[0];return {contentKind:draft.contentKind,visibility:draft.visibility,text:draft.text,files:draft.files.map(file=>({crop:file.crop}))};
        }""")
        self.assertEqual(draft['contentKind'],'gallery')
        self.assertEqual(draft['visibility'],'followers')
        self.assertEqual(draft['text'],'A followers-only photo draft')
        self.assertEqual(draft['files'][0]['crop']['aspect'],'1:1')
        self.page.locator('.compose').click();self.page.locator('#pngeaDraftsBtn').click()
        self.page.locator('.pngeaDraftCopy').first.click()
        self.assertEqual(self.page.locator('#composerLayer').get_attribute('data-post-kind'),'gallery')
        self.assertEqual(self.page.locator('#pngeaPhotoAudience').input_value(),'followers')
        self.assertEqual(self.page.locator('#postText').input_value(),'A followers-only photo draft')
        self.assertEqual(self.page.locator('#send').inner_text(),'Next')

    def test_publish_snapshot_survives_cancel_and_new_draft_during_upload(self):
        self.select_photo();self.page.locator('#send').click()
        self.page.locator('#postText').fill('Original followers photo')
        self.page.locator('#pngeaPhotoAudience').select_option('followers')
        self.page.evaluate("""()=>{
            window.publishedSnapshot=null;window.releasePhotoUpload=null;
            window.PNGEA_API.createMediaUpload=async()=>{await new Promise(resolve=>window.releasePhotoUpload=resolve);return {mediaId:'med_snapshot',uploadUrl:'http://localhost/upload',headers:{}}};
            window.PNGEA_API.completeMedia=async()=>({ok:true});window.PNGEA_API.media=async()=>({status:'ready'});
            window.PNGEA_API.createPost=async body=>{window.publishedSnapshot=body;return {id:'pst_snapshot'}};
            window.XMLHttpRequest=class{constructor(){this.upload={}}open(){}setRequestHeader(){}send(file){window.snapshotUpload=file;this.status=200;setTimeout(()=>this.onload(),0)}};
        }""")
        self.page.locator('#send').click()
        self.page.wait_for_function("typeof window.releasePhotoUpload==='function'")
        self.page.locator('#closeComposer').click();self.page.locator('#closeComposer').click()
        self.page.locator('[data-draft-exit="discard"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.page.locator('.compose').click()
        self.page.locator('#postText').fill('Keep this new draft')
        self.page.locator('#pngeaPhotoAudience').select_option('public',force=True)
        self.page.evaluate('window.releasePhotoUpload()')
        self.page.wait_for_function('window.publishedSnapshot!==null')
        self.page.wait_for_function("!document.querySelector('#send').disabled")
        created=self.page.evaluate('window.publishedSnapshot')
        self.assertEqual(created['contentKind'],'gallery')
        self.assertEqual(created['visibility'],'followers')
        self.assertEqual(created['text'],'Original followers photo')
        self.assertEqual(created['mediaIds'],['med_snapshot'])
        dimensions=self.page.evaluate('async()=>{const image=await createImageBitmap(window.snapshotUpload);return [image.width,image.height]}')
        self.assertAlmostEqual(dimensions[0]/dimensions[1],.8,places=2)
        self.assertEqual(self.page.locator('#postText').input_value(),'Keep this new draft')
        self.assertTrue(self.page.locator('#composerLayer').is_visible())

    def test_text_first_photo_stays_in_text_bubble(self):
        self.select_photo(text='Text comes first')
        self.assertEqual(self.page.locator('#send').inner_text(),'↑')
        result=self.page.evaluate("()=>{const p={id:'typed',content_kind:'text',handle:'other',display_name:'Other',text:'Text first',media:[{id:'image',mimeType:'image/png'}]},host=document.createElement('div');host.innerHTML=window.PNGEA_CORE.renderPost(p,p);document.body.appendChild(host);const row=host.firstElementChild;return [row.dataset.postFormat,getComputedStyle(row).borderTopWidth,[...row.querySelectorAll('[data-live-action]')].map(e=>e.dataset.liveAction)]}")
        self.assertEqual(result,['text','1px',['reply','repost','like','share']])

    def test_crop_grid_save_and_back_preserve_review(self):
        self.select_photo();self.page.locator('#send').click()
        self.page.locator('#pngeaPhotoReviewThumbs button').click()
        self.page.wait_for_selector('.pngeaCropGrid')
        self.page.wait_for_function("document.querySelector('#pngeaEditorStage canvas').height>0")
        self.page.locator('#pngeaMediaEditorTools button').get_by_text('1:1',exact=True).click()
        self.page.locator('#pngeaMediaEditorDone').click()
        self.assertFalse(self.page.locator('#pngeaMediaEditor').is_visible())
        self.assertTrue(self.page.locator('#pngeaPhotoReview').is_visible())
        self.page.locator('#pngeaPhotoReviewThumbs button').click()
        self.page.locator('#pngeaMediaEditorCancel').click()
        self.assertTrue(self.page.locator('#pngeaPhotoReview').is_visible())
        self.page.locator('#closeComposer').click()
        self.assertEqual(self.page.locator('#send').inner_text(),'Next')

    def test_photo_actions_are_ordered_and_save_toggles(self):
        self.render_photo()
        row=self.page.locator('#feed .pngeaPhotoActions')
        self.assertEqual(row.locator('[data-live-action]').evaluate_all('(els)=>els.map(e=>e.dataset.liveAction)'),['like','reply','repost','share','save'])
        self.page.evaluate("()=>{window.saved=0;window.PNGEA_API.bookmarkPost=async()=>{window.saved++;return {ok:true}};window.PNGEA_API.unbookmarkPost=async()=>{window.saved--;return {ok:true}}}")
        save=row.locator('[data-live-action="save"]')
        save.evaluate("el=>el.scrollIntoView({block:'center'})")
        self.assertTrue(save.evaluate("el=>{const box=el.getBoundingClientRect();return el.contains(document.elementFromPoint(box.x+box.width/2,box.y+box.height/2))}"))
        save.click();self.page.wait_for_function('window.saved===1')
        self.assertEqual(save.get_attribute('aria-pressed'),'true')
        save.click();self.page.wait_for_function('window.saved===0')
        self.assertEqual(save.get_attribute('aria-pressed'),'false')
        image=self.page.locator('#feed .liveMediaRail img').bounding_box();caption=self.page.locator('#feed .xPostText').bounding_box()
        self.assertGreater(caption['y'],image['y']+image['height'])
        self.assertLessEqual(image['height'],430)

    def test_photo_avatar_and_detail_menu_work(self):
        self.render_photo();self.page.locator('#feed .xAvatar').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'&&window.PNGEA.parseRoute().detail==='other'")
        self.navigate('Home');self.page.locator('#feed .xPostText').click();self.page.wait_for_selector('#pngeaPostBody .more')
        self.page.locator('#pngeaPostBody .more').click()
        self.assertTrue(self.page.locator('#pnActionSheet').is_visible())
        self.assertEqual(self.page.locator('#pnActionSheet').evaluate('(e)=>e.parentElement.tagName'),'BODY')
        self.assertTrue(self.page.locator('[data-pngea516-action="send"]').is_visible())
        self.page.locator('#pnActionClose').click()
        self.page.locator('#pngeaPostBody .pngeaDetailAvatar').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'&&window.PNGEA.parseRoute().detail==='other'")
        self.assertFalse(self.page.locator('#pngeaPostPage').is_visible())

    def test_mentions_autocomplete_and_stable_header(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('Hello @ot')
        self.page.locator('#pngeaMentionSuggestions [data-mention-handle="other"]').click()
        self.assertEqual(self.page.locator('#postText').input_value(),'Hello @other ')
        self.assertEqual(self.page.locator('#detected').inner_text(),'New posts')
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="discard"]').click();self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_function("document.querySelector('#pngeaReplyingTo').textContent.includes('@other')")
        self.assertTrue(self.page.locator('#pngeaReplyingTo [data-profile="other"]').is_visible())

    def test_connection_avatar_closes_list_and_opens_profile(self):
        self.navigate('Profile','tester')
        self.page.locator('#Profile .profileStats span').nth(1).click()
        self.page.locator('#pngeaConnectionsList .xAvatar').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'&&window.PNGEA.parseRoute().detail==='other'")
        self.assertFalse(self.page.locator('#pngeaConnectionsPage').is_visible())

    def test_community_photo_avatar_closes_overlay_and_opens_profile(self):
        self.page.evaluate("window.PNGEA_API.communityFeed=async()=>({items:[{id:'community_photo',author_id:'usr_other',handle:'other',display_name:'Other',content_kind:'gallery',text:'Community photo',media:[]}]})")
        self.navigate('Communities')
        self.page.locator('#pngeaCommunitiesList [data-community-id]').first.click()
        self.page.locator('#pngeaCommunityFeed .xAvatar').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'&&window.PNGEA.parseRoute().detail==='other'")
        self.assertFalse(self.page.locator('#pngeaCommunityPage').is_visible())

    def test_profile_likes_tab_removed_but_history_likes_remain(self):
        self.navigate('Profile','other')
        self.assertEqual(self.page.locator('#Profile [data-tab="p-likes"]').count(),0)
        self.navigate('History')
        self.assertEqual(self.page.locator('#History [data-library-tab="likes"]').count(),1)

    def test_realtime_public_posts_cannot_bypass_following_feed(self):
        self.page.add_init_script("window.testSockets=[];window.WebSocket=class{constructor(){window.testSockets.push(this)}close(){}}")
        self.page.reload();self.page.wait_for_function('window.PNGEA_LIVE?.state?.active&&window.testSockets.length>0')
        self.page.evaluate("()=>{window.postFetches=0;window.PNGEA_API.feed=async()=>({items:[]});window.PNGEA_API.post=async()=>{window.postFetches++;return {id:'not_followed',author_id:'stranger',handle:'stranger',text:'Unfollowed post',media:[]}};window.testSockets.at(-1).onmessage({data:JSON.stringify({type:'post.created',data:{postId:'not_followed'}})})}")
        self.page.wait_for_timeout(300)
        self.assertEqual(self.page.evaluate('window.postFetches'),0)
        self.assertEqual(self.page.locator('#feed [data-server-post="not_followed"]').count(),0)

if __name__=='__main__':unittest.main(verbosity=2)
