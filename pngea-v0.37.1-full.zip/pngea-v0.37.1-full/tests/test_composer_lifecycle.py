"""Local browser checks for explicit drafts, caption edits and video uploads."""
import unittest
from pathlib import Path
from . import browser_reliability as fixture
from . import test_photo_mentions as photo_fixture


class ComposerLifecycle(unittest.TestCase):
    setUpClass=classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass=classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp=fixture.Reliability.setUp
    tearDown=fixture.Reliability.tearDown
    route=fixture.Reliability.route
    navigate=fixture.Reliability.navigate
    select_photo=photo_fixture.PhotoMentions.select_photo

    def drafts(self):
        return self.page.evaluate("""async()=>{const db=await new Promise(resolve=>{const r=indexedDB.open('pngea-resilience-v1',1);r.onsuccess=()=>resolve(r.result)});const rows=await new Promise(resolve=>{const r=db.transaction('kv').objectStore('kv').get('drafts.v2');r.onsuccess=()=>resolve(r.result||[])});db.close();return rows.map(({files,...rest})=>({...rest,fileCount:files.length}))}""")

    def test_empty_close_needs_no_decision(self):
        self.page.locator('.compose').click();self.page.locator('#closeComposer').click()
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertFalse(self.page.locator('#pngeaDraftExit').is_visible())

    def test_exit_keeps_draft_only_after_explicit_save(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('Keep this')
        self.page.locator('#closeComposer').click()
        self.assertTrue(self.page.locator('#pngeaDraftExit').is_visible())
        self.assertEqual(self.drafts(),[])
        self.page.locator('[data-draft-exit="cancel"]').click()
        self.assertEqual(self.page.locator('#postText').input_value(),'Keep this')
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.assertEqual(self.drafts()[0]['text'],'Keep this')
        self.assertIn('hasDrafts',self.page.locator('#pngeaDraftsBtn').get_attribute('class'))
        self.page.locator('.compose').click();self.page.locator('#pngeaDraftsBtn').click()
        self.page.locator('.pngeaDraftCopy').first.click()
        self.assertEqual(self.page.locator('#postText').input_value(),'Keep this')

    def test_drafts_back_preserves_unsaved_without_saving(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('Unsent')
        self.page.locator('#pngeaDraftsBtn').click();self.page.locator('#pngeaDraftsClose').click()
        self.assertEqual(self.drafts(),[])
        self.assertEqual(self.page.locator('#postText').input_value(),'Unsent')
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="discard"]').click()
        self.page.locator('.compose').click();self.assertEqual(self.page.locator('#postText').input_value(),'')

    def test_published_draft_is_removed_and_icon_dims(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('Publish saved draft')
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.page.locator('.compose').click();self.page.locator('#pngeaDraftsBtn').click();self.page.locator('.pngeaDraftCopy').first.click()
        self.page.evaluate("window.PNGEA_API.createPost=async()=>({id:'published_draft'})")
        self.page.locator('#send').click();self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.assertEqual(self.drafts(),[])
        self.assertNotIn('hasDrafts',self.page.locator('#pngeaDraftsBtn').get_attribute('class') or '')

    def test_failed_publish_preserves_saved_draft(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('Try again')
        self.page.evaluate("()=>{window.PNGEA_API.createPost=async()=>{throw new Error('Offline fixture')}}")
        self.page.locator('#send').click()
        self.page.wait_for_function("document.querySelector('#pngeaDraftsBtn').dataset.draftCount==='1'")
        self.assertEqual(self.drafts()[0]['text'],'Try again')
        self.assertEqual(self.page.locator('#postText').input_value(),'Try again')

    def test_storage_failure_keeps_unsaved_post_in_composer(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('Must not disappear')
        self.page.evaluate("""()=>{const put=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(value,key){if(key==='drafts.v2')throw new DOMException('Fixture quota exceeded','QuotaExceededError');return put.call(this,value,key)}}""")
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("!document.querySelector('[data-draft-exit=save]').disabled")
        self.assertTrue(self.page.locator('#composerLayer').is_visible())
        self.assertTrue(self.page.locator('#pngeaDraftExit').is_visible())
        self.assertEqual(self.page.locator('#postText').input_value(),'Must not disappear')

    def render_owned(self,kind='gallery',mime='image/png'):
        self.page.evaluate("""({kind,mime})=>{window.ownedCaption={id:'owned_caption',author_id:'usr_self',handle:'tester',display_name:'Tester',content_kind:kind,text:'Before caption',media:[{id:'owned_media',mimeType:mime,durationMs:mime.startsWith('video/')?2000:undefined}]};window.PNGEA_API.post=async()=>window.ownedCaption;window.PNGEA_API.mediaAccess=async()=>({mimeType:mime,url:mime.startsWith('video/')?'http://localhost/tests/fixtures/reel.mp4':'http://localhost/owned.svg'});window.PNGEA_API.feed=async()=>({items:[window.ownedCaption]});window.PNGEA_LIVE.loadFeed()}""",dict(kind=kind,mime=mime))
        self.page.wait_for_selector('#feed [data-server-post="owned_caption"]')

    def test_caption_edits_work_from_timeline_and_detail(self):
        self.render_owned()
        self.page.evaluate("""()=>{const request=window.PNGEA_API.request;window.captionPatches=[];window.PNGEA_API.request=async(path,options)=>{if(options?.method==='PATCH'&&path.endsWith('/owned_caption')){const body=JSON.parse(options.body);window.captionPatches.push(body);window.ownedCaption={...window.ownedCaption,text:body.text,edited_at:new Date().toISOString()};return window.ownedCaption}return request(path,options)}}""")
        for detail in (False,True):
            if detail:self.page.locator('#feed .xPostText').click();self.page.wait_for_selector('#pngeaPostBody .more')
            target='#pngeaPostBody' if detail else '#feed'
            self.page.locator(target+' .more').click();self.page.locator('[data-pngea516-action="edit"]').click()
            self.page.wait_for_function("!document.querySelector('#pngeaCaptionSave').disabled")
            self.page.locator('#pngeaCaptionText').fill('Edited '+str(detail));self.page.locator('#pngeaCaptionSave').click()
            self.page.wait_for_function("!document.querySelector('#pngeaCaptionEditor').classList.contains('show')")
            self.assertIn('Edited '+str(detail),self.page.locator(target).inner_text())
        self.assertEqual(len(self.page.evaluate('window.captionPatches')),2)
        self.assertTrue(self.page.locator('#pngeaPostPage').is_visible())

    def test_text_image_bubble_has_no_edit_option(self):
        self.render_owned('text')
        self.page.locator('#feed .more').click()
        self.assertEqual(self.page.locator('[data-pngea516-action="edit"]').count(),0)
        self.assertEqual(self.page.locator('[data-pngea516-action="delete"]').count(),1)

    def test_video_publishes_with_real_file_metadata(self):
        self.page.locator('.compose').click()
        with self.page.expect_file_chooser() as chooser:self.page.locator('#composerLayer [data-attach="gallery"]').click()
        chooser.value.set_files(str(Path(__file__).parent/'fixtures'/'reel.mp4'))
        self.page.locator('#send').click()
        self.page.locator('#postText').fill('Real video caption')
        self.page.evaluate("""()=>{window.videoPublished=null;window.completedMetadata=null;window.PNGEA_API.createMediaUpload=async()=>({mediaId:'real_video',uploadUrl:'http://localhost/upload',headers:{}});window.PNGEA_API.completeMedia=async(id,body)=>{window.completedMetadata=body;return {status:'ready'}};window.PNGEA_API.media=async()=>({status:'ready'});window.PNGEA_API.createPost=async body=>{window.videoPublished=body;return{id:'new_video'}};window.XMLHttpRequest=class{constructor(){this.upload={}}open(){}setRequestHeader(){}send(){this.status=200;setTimeout(()=>this.onload(),0)}}}""")
        self.page.locator('#send').click();self.page.wait_for_function('window.videoPublished!==null',timeout=10000)
        self.assertEqual(self.page.evaluate('window.videoPublished.mediaIds'),['real_video'])
        metadata=self.page.evaluate('window.completedMetadata')
        self.assertGreater(metadata['width'],0);self.assertGreater(metadata['height'],0)
        self.assertGreater(metadata['durationMs'],1000);self.assertLess(metadata['durationMs'],90000)

    def test_short_and_long_video_format_boundary(self):
        formats=self.page.evaluate("[89999,90000,120000].map(durationMs=>window.PNGEA_CORE.postFormat({content_kind:'gallery',media:[{mimeType:'video/mp4',durationMs}]}))")
        self.assertEqual(formats,['reel','video','video'])

    def test_successful_video_opens_saved_post_outside_following_feed(self):
        self.page.locator('.compose').click()
        with self.page.expect_file_chooser() as chooser:self.page.locator('#composerLayer [data-attach="gallery"]').click()
        chooser.value.set_files(str(Path(__file__).parent/'fixtures'/'reel.mp4'))
        self.page.locator('#send').click();self.page.locator('#postText').fill('Visible saved video')
        self.page.evaluate("""()=>{
            window.savedVideo=null;window.createdPostReads=0;
            window.PNGEA_API.createMediaUpload=async()=>({mediaId:'visible_video',uploadUrl:'http://localhost/upload',headers:{}});
            window.PNGEA_API.completeMedia=async()=>({status:'ready'});window.PNGEA_API.media=async()=>({status:'ready'});
            window.PNGEA_API.createPost=async body=>{window.savedVideo={id:'saved_video',author_id:'usr_self',handle:'tester',display_name:'Tester',text:body.text,content_kind:body.contentKind,media:[{id:body.mediaIds[0],mimeType:'video/mp4',durationMs:2000,width:180,height:320}]};return{id:window.savedVideo.id}};
            const readPost=window.PNGEA_API.post;window.PNGEA_API.post=async id=>{if(id==='saved_video'){window.createdPostReads++;return window.savedVideo}return readPost(id)};
            window.PNGEA_API.feed=async()=>({items:[]});window.PNGEA_API.mediaAccess=async()=>({mimeType:'video/mp4',url:'http://localhost/tests/fixtures/reel.mp4'});
            window.XMLHttpRequest=class{constructor(){this.upload={}}open(){}setRequestHeader(){}send(){this.status=200;setTimeout(()=>this.onload(),0)}};
        }""")
        self.page.locator('#send').click()
        self.page.wait_for_selector('#pngeaPostBody [data-server-post="saved_video"] video')
        self.assertIn('Visible saved video',self.page.locator('#pngeaPostBody').inner_text())
        self.assertTrue(self.page.locator('#pngeaPostPage').is_visible())
        self.assertGreater(self.page.evaluate('window.createdPostReads'),0)
        self.assertTrue(self.page.evaluate("location.hash==='#/post/saved_video'"))
        self.assertEqual(self.page.locator('#feed [data-server-post="saved_video"]').count(),0)
        self.page.locator('#pngeaPostBack').click()
        self.assertFalse(self.page.locator('#pngeaPostPage').is_visible())
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'),'Home')

    def test_older_publish_does_not_cover_a_new_composer_draft(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('Older post in flight')
        self.page.evaluate("""()=>{window.releaseOlderPost=null;window.olderPostFinished=false;window.PNGEA_API.createPost=async()=>{await new Promise(resolve=>window.releaseOlderPost=resolve);window.olderPostFinished=true;return{id:'older_saved'}}}""")
        self.page.locator('#send').click();self.page.wait_for_function("typeof window.releaseOlderPost==='function'")
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="discard"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.page.locator('.compose').click();self.page.locator('#postText').fill('New draft remains here')
        self.page.evaluate('window.releaseOlderPost()')
        self.page.wait_for_function("window.olderPostFinished&&!document.querySelector('#send').disabled")
        self.assertEqual(self.page.locator('#postText').input_value(),'New draft remains here')
        self.assertTrue(self.page.locator('#composerLayer').is_visible())
        self.assertFalse(self.page.locator('#pngeaPostPage').is_visible())
        self.assertFalse(self.page.evaluate("location.hash.startsWith('#/post/')"))

    def test_video_detail_caption_stays_below_video(self):
        self.render_owned('gallery','video/mp4')
        self.page.locator('#feed .xPostText').click()
        self.page.wait_for_selector('#pngeaPostBody .pngeaDetailMedia video')
        order=self.page.locator('#pngeaPostBody .pngeaDetailPost').evaluate("card=>{const children=[...card.children];return[children.indexOf(card.querySelector('.pngeaDetailMedia')),children.indexOf(card.querySelector('.pngeaDetailText'))]}")
        self.assertGreaterEqual(order[0],0)
        self.assertGreater(order[1],order[0])

    def test_video_with_missing_browser_mime_still_attaches(self):
        self.page.locator('.compose').click()
        with self.page.expect_file_chooser() as chooser:self.page.locator('#composerLayer [data-attach="gallery"]').click()
        chooser.value.set_files(dict(name='phone-video.mp4',mimeType='application/octet-stream',buffer=(Path(__file__).parent/'fixtures'/'reel.mp4').read_bytes()))
        self.assertEqual(self.page.locator('#send').inner_text(),'Next')
        self.assertEqual(self.page.locator('#pngeaComposerMediaGrid video').count(),1)

    def test_video_draft_restores_trim_and_mute(self):
        self.page.locator('.compose').click()
        with self.page.expect_file_chooser() as chooser:self.page.locator('#composerLayer [data-attach="gallery"]').click()
        chooser.value.set_files(str(Path(__file__).parent/'fixtures'/'reel.mp4'))
        self.page.locator('.pngeaMediaEdit').click()
        self.page.wait_for_function("Number(document.querySelector('#pngeaMediaEditorTools input').max)>1")
        self.page.locator('#pngeaMediaEditorTools input').nth(0).evaluate("e=>{e.value=.5;e.dispatchEvent(new Event('input',{bubbles:true}))}")
        self.page.locator('#pngeaMediaEditorTools input').nth(1).evaluate("e=>{e.value=1.5;e.dispatchEvent(new Event('input',{bubbles:true}))}")
        self.page.locator('#pngeaMediaEditorTools button').get_by_text('Mute',exact=True).click()
        self.page.locator('#pngeaMediaEditorDone').click()
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.page.locator('.compose').click();self.page.locator('#pngeaDraftsBtn').click();self.page.locator('.pngeaDraftCopy').first.click()
        self.page.locator('.pngeaMediaEdit').click()
        self.page.wait_for_function("Number(document.querySelector('#pngeaMediaEditorTools input').max)>1")
        self.assertEqual(float(self.page.locator('#pngeaMediaEditorTools input').nth(0).input_value()),.5)
        self.assertEqual(float(self.page.locator('#pngeaMediaEditorTools input').nth(1).input_value()),1.5)
        self.assertTrue(self.page.locator('#pngeaMediaEditorTools button').get_by_text('Unmute',exact=True).is_visible())


if __name__=='__main__':unittest.main(verbosity=2)
