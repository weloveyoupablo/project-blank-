"""Word/reply composition uses the shared publisher and viewport controller."""
import unittest
from . import browser_reliability as fixture
from . import test_photo_mentions as photo_fixture
from . import test_chat_keyboard as keyboard_fixture


class WordComposer(unittest.TestCase):
    setUpClass=classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass=classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp=fixture.Reliability.setUp
    tearDown=fixture.Reliability.tearDown
    route=fixture.Reliability.route
    navigate=fixture.Reliability.navigate
    select_photo=photo_fixture.PhotoMentions.select_photo
    open_keyboard=keyboard_fixture.ChatKeyboard.open_keyboard
    touch_drag_prevented=keyboard_fixture.ChatKeyboard.touch_drag_prevented

    def test_word_counter_thresholds_and_overflow_block_real_publish_handler(self):
        self.page.locator('.compose').click()
        field=self.page.locator('#postText');counter=self.page.locator('#pngeaWordCounter')
        field.fill('a'*259)
        self.assertEqual(counter.locator('span').inner_text(),'')
        self.assertEqual(counter.get_attribute('data-state'),'normal')
        field.fill('a'*260)
        self.assertEqual(counter.locator('span').inner_text(),'20')
        self.assertEqual(counter.get_attribute('data-state'),'warning')
        field.fill('a'*280)
        self.assertEqual(counter.locator('span').inner_text(),'0')
        self.assertEqual(counter.get_attribute('data-state'),'overflow')
        self.assertFalse(self.page.locator('#send').is_disabled())
        field.fill('a'*280+'EXTRA')
        self.assertEqual(counter.locator('span').inner_text(),'-5')
        self.assertEqual(self.page.locator('#pngeaWordOverflow mark').inner_text(),'EXTRA')
        self.assertTrue(self.page.locator('#send').is_disabled())
        self.page.evaluate("()=>{window.overLimitWrites=0;window.PNGEA_API.createPost=async()=>{window.overLimitWrites++;return{id:'invalid'}};document.querySelector('#send').dispatchEvent(new MouseEvent('click',{bubbles:true}))}")
        self.assertEqual(self.page.evaluate('window.overLimitWrites'),0)
        self.assertEqual(field.input_value(),'a'*280+'EXTRA')

    def test_unicode_limit_counts_codepoints_without_truncating_emoji(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('😀'*280)
        self.assertEqual(self.page.locator('#pngeaWordCounter span').inner_text(),'0')
        self.assertFalse(self.page.locator('#send').is_disabled())
        self.page.locator('#postText').fill('😀'*281)
        self.assertEqual(self.page.locator('#pngeaWordCounter span').inner_text(),'-1')
        self.assertEqual(self.page.locator('#pngeaWordOverflow mark').inner_text(),'😀')
        self.assertEqual(self.page.locator('#postText').input_value(),'😀'*281)

    def test_gallery_caption_and_long_form_keep_their_unlimited_bodies(self):
        self.select_photo();self.page.locator('#send').click();self.page.locator('#postText').fill('Caption '*100)
        self.assertFalse(self.page.locator('#send').is_disabled())
        self.assertFalse(self.page.locator('#pngeaWordMeta').is_visible())
        self.page.locator('#closeComposer').click();self.page.locator('#closeComposer').click()
        self.page.locator('#composerLayer [data-attach="longform"]').click()
        self.page.locator('#pngeaLongTitleInput').fill('Unlimited article')
        self.assertFalse(self.page.locator('#send').is_disabled())
        self.assertFalse(self.page.locator('#pngeaWordMeta').is_visible())

    def test_word_audience_survives_draft_restore_and_publishes_followers_only(self):
        self.page.locator('.compose').click();self.page.locator('#postText').fill('For followers')
        self.page.locator('#pngeaWordAudience').select_option('followers')
        self.page.locator('#closeComposer').click();self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("!document.querySelector('#composerLayer').classList.contains('show')")
        self.page.locator('.compose').click();self.page.locator('#pngeaDraftsBtn').click();self.page.locator('.pngeaDraftCopy').first.click()
        self.assertEqual(self.page.locator('#pngeaWordAudience').input_value(),'followers')
        self.page.evaluate("()=>{window.wordPublished=null;window.PNGEA_API.createPost=async body=>{window.wordPublished=body;return{id:'word_saved'}}}")
        self.page.locator('#send').click();self.page.wait_for_function('window.wordPublished!==null')
        self.assertEqual(self.page.evaluate('window.wordPublished.visibility'),'followers')
        self.assertEqual(self.page.evaluate('window.wordPublished.contentKind'),'text')

    def word_parent(self):
        self.page.evaluate("""()=>{
            window.replyParent={id:'pst_real',author_id:'usr_other',handle:'other',display_name:'Other',content_kind:'text',text:'Original word post with a photo',media:[{id:'reply_original_photo',mimeType:'image/png'}]};
            window.PNGEA_API.post=async()=>window.replyParent;
            window.PNGEA_API.mediaAccess=async()=>({mimeType:'image/png',url:'http://localhost/reply-original.svg'});
        }""")

    def test_timeline_word_reply_has_original_thumbnail_self_and_same_publisher(self):
        self.word_parent();self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_selector('#composerLayer.pngeaWordReply .pngeaWordReplyThumb')
        self.assertIn('Original word post with a photo',self.page.locator('#pngeaWordReplyPreview').inner_text())
        self.assertIn('@other',self.page.locator('#pngeaWordReplyingTo').inner_text())
        self.assertTrue(self.page.locator('#pngeaWordReplyIdentity .selfAvatarFallback').is_visible())
        self.assertEqual(self.page.locator('#send').inner_text(),'Post')
        with self.page.expect_file_chooser() as chooser:self.page.locator('#composerLayer [data-attach="gallery"]').click()
        chooser.value.set_files(str(fixture.ROOT/'icon-192 2.png'))
        self.assertEqual(self.page.locator('#composerLayer').get_attribute('data-post-kind'),'text')
        self.assertEqual(self.page.locator('#send').inner_text(),'Post')
        self.page.locator('#postText').fill('Reply in a word bubble')
        self.page.evaluate("""()=>{window.wordReplyPublished=null;window.PNGEA_API.createMediaUpload=async()=>({mediaId:'word_reply_photo',uploadUrl:'http://localhost/upload',headers:{}});window.PNGEA_API.completeMedia=async()=>({status:'ready'});window.PNGEA_API.media=async()=>({status:'ready'});window.PNGEA_API.createPost=async body=>{window.wordReplyPublished=body;return{id:'reply_saved'}};window.XMLHttpRequest=class{constructor(){this.upload={}}open(){}setRequestHeader(){}send(){this.status=200;setTimeout(()=>this.onload(),0)}}}""")
        self.page.locator('#send').click();self.page.wait_for_function('window.wordReplyPublished!==null')
        body=self.page.evaluate('window.wordReplyPublished')
        self.assertEqual(body['replyToId'],'pst_real');self.assertEqual(body['contentKind'],'text')
        self.assertEqual(body['mediaIds'],['word_reply_photo'])

    def test_detail_reply_uses_same_page_and_cancel_restores_original_context(self):
        self.word_parent();self.page.locator('#feed .xPostText').first.click()
        self.page.wait_for_selector('#pngeaPostBody [data-live-action="reply"]')
        original_url=self.page.url
        self.page.locator('#pngeaPostBody [data-live-action="reply"]').click()
        self.page.wait_for_selector('#composerLayer.pngeaWordReply')
        self.assertTrue(self.page.locator('#pngeaPostPage').evaluate('(element)=>element.inert'))
        self.assertEqual(self.page.locator('#pngeaReplyPage').count(),0)
        self.page.locator('#closeComposer').click()
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertTrue(self.page.locator('#pngeaPostPage').is_visible())
        self.assertFalse(self.page.locator('#pngeaPostPage').evaluate('(element)=>element.inert'))
        self.assertEqual(self.page.url,original_url)

    def test_empty_reply_avatar_opens_profile_and_closes_reply_context(self):
        self.word_parent();self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_selector('#pngeaWordReplyPreview .xAvatar')
        self.page.locator('#pngeaWordReplyPreview .xAvatar').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'&&window.PNGEA.parseRoute().detail==='other'")
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertFalse(self.page.locator('#pngeaDraftExit').is_visible())
        self.assertIsNone(self.page.evaluate('window.PNGEA_LIVE.state.replyToId'))
        self.assertNotIn('pngeaWordReply',self.page.locator('#composerLayer').get_attribute('class'))

    def test_reply_avatar_uses_existing_save_discard_cancel_decision(self):
        self.word_parent();self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_selector('#pngeaWordReplyPreview .xAvatar')
        self.page.locator('#postText').fill('Save before viewing this profile')
        original_url=self.page.url
        self.page.locator('#pngeaWordReplyPreview .xAvatar').click()
        self.assertTrue(self.page.locator('#pngeaDraftExit').is_visible())
        self.assertEqual(self.page.url,original_url)
        self.page.locator('[data-draft-exit="cancel"]').click()
        self.assertEqual(self.page.locator('#postText').input_value(),'Save before viewing this profile')
        self.assertTrue(self.page.locator('#composerLayer.pngeaWordReply').is_visible())
        self.page.locator('#pngeaWordReplyPreview .xAvatar').click();self.page.locator('[data-draft-exit="save"]').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'&&window.PNGEA.parseRoute().detail==='other'")
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertEqual(self.page.locator('#postText').input_value(),'')
        self.assertEqual(self.page.locator('#pngeaDraftsBtn').get_attribute('data-draft-count'),'1')
        self.page.locator('#Profile .xTop .xBack').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Home'")
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.page.locator('.compose').click();self.page.locator('#pngeaDraftsBtn').click();self.page.locator('.pngeaDraftCopy').first.click()
        self.page.wait_for_selector('#pngeaWordReplyPreview .xAvatar')
        self.assertEqual(self.page.locator('#postText').input_value(),'Save before viewing this profile')
        self.assertEqual(self.page.evaluate('window.PNGEA_LIVE.state.replyToId'),'pst_real')
        self.page.locator('#pngeaWordReplyPreview .xAvatar').click();self.page.locator('[data-draft-exit="discard"]').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().screen==='Profile'")
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertEqual(self.page.locator('#pngeaDraftsBtn').get_attribute('data-draft-count'),'0')

    def test_expired_reply_is_saved_for_its_account_and_hidden_from_another(self):
        self.word_parent();self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_selector('#pngeaWordReplyingTo .pngeaMention')
        self.page.locator('#postText').fill('Private reply draft belonging to A')
        account_a=self.page.evaluate('window.PNGEA_API.getActiveAccountKey()')
        self.page.evaluate("()=>{window.savedComposerAccount={...window.PNGEA_LIVE.state.me};window.dispatchEvent(new CustomEvent('pngea:session-expired'))}")
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertTrue(self.page.locator('#pngeaLiveAuth').is_visible())
        self.assertFalse(self.page.locator('#pngeaDraftExit').is_visible())
        self.page.wait_for_function("""async account=>{const db=await new Promise(resolve=>{const request=indexedDB.open('pngea-resilience-v1',1);request.onsuccess=()=>resolve(request.result)});const rows=await new Promise(resolve=>{const request=db.transaction('kv').objectStore('kv').get('drafts.v3:'+account);request.onsuccess=()=>resolve(request.result||[])});db.close();return rows.some(row=>row.text==='Private reply draft belonging to A'&&row.replyToId==='pst_real')}""",arg=account_a)
        self.page.locator('#liveIdentifier').focus();self.open_keyboard()
        self.assertFalse(self.page.evaluate("document.documentElement.classList.contains('pngeaThreadViewport')"))
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:844});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.evaluate("""()=>{localStorage.setItem('pngea:activeAccountKey','bbbbbbbbbbbbbbbb');window.PNGEA_API.setAccessToken('fixture-b');window.PNGEA_LIVE.state.me={...window.savedComposerAccount,id:'usr_b',account_key:'bbbbbbbbbbbbbbbb',handle:'second'};window.PNGEA_LIVE.state.active=true;document.documentElement.dataset.session='signed-in';document.querySelector('#pngeaLiveAuth').classList.remove('show');document.querySelector('.app').classList.remove('authOpen');window.dispatchEvent(new CustomEvent('pngea:session-ready'))}""")
        self.page.locator('.compose').click();self.assertEqual(self.page.locator('#postText').input_value(),'')
        self.page.locator('#pngeaDraftsBtn').click();self.page.wait_for_selector('#pngeaDraftList .profileEmpty')
        self.assertEqual(self.page.locator('#pngeaDraftList .pngeaDraftCopy').count(),0)
        self.page.locator('#pngeaDraftsClose').click();self.page.locator('#closeComposer').click()
        self.page.evaluate("""account=>{localStorage.setItem('pngea:activeAccountKey',account);window.PNGEA_API.setAccessToken('fixture-a');window.PNGEA_LIVE.state.me=window.savedComposerAccount;window.dispatchEvent(new CustomEvent('pngea:session-ready'))}""",account_a)
        self.page.locator('.compose').click();self.page.locator('#pngeaDraftsBtn').click();self.page.locator('.pngeaDraftCopy').first.click()
        self.page.wait_for_selector('#composerLayer.pngeaWordReply')
        self.assertEqual(self.page.locator('#postText').input_value(),'Private reply draft belonging to A')
        self.assertEqual(self.page.evaluate('window.PNGEA_LIVE.state.replyToId'),'pst_real')

    def test_expiry_storage_failure_keeps_unsent_text_in_hidden_memory(self):
        self.word_parent();self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.locator('#postText').fill('Keep this when local storage is full')
        self.page.evaluate("""()=>{const put=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(value,key){if(String(key).startsWith('drafts.v3:')){window.expiryDraftWriteFailed=true;throw new DOMException('Fixture quota','QuotaExceededError')}return put.call(this,value,key)};window.dispatchEvent(new CustomEvent('pngea:session-expired'))}""")
        self.page.wait_for_function('window.expiryDraftWriteFailed===true')
        self.assertTrue(self.page.locator('#pngeaLiveAuth').is_visible())
        self.assertFalse(self.page.locator('#composerLayer').is_visible())
        self.assertFalse(self.page.locator('#pngeaDraftExit').is_visible())
        self.assertEqual(self.page.locator('#postText').input_value(),'Keep this when local storage is full')

    def test_word_reply_keyboard_locks_frame_but_allows_native_canvas_scroll(self):
        self.word_parent();self.page.locator('#feed [data-live-action="reply"]').first.click()
        self.page.wait_for_selector('#pngeaWordReplyingTo .pngeaMention')
        self.open_keyboard(height=460,offset=35)
        header=self.page.locator('#composerLayer .composerTop').bounding_box()
        toolbar=self.page.locator('#composerLayer .capture').bounding_box()
        self.assertAlmostEqual(toolbar['y']+toolbar['height'],495,delta=2)
        self.assertTrue(self.touch_drag_prevented('#composerLayer .composerTop',60))
        self.assertEqual(self.page.locator('#composerLayer .composerTop').bounding_box(),header)
        self.page.locator('#composerLayer .canvas').evaluate("element=>{const block=document.createElement('div');block.style.height='800px';block.style.flex='none';element.appendChild(block);element.scrollTop=100}")
        self.assertFalse(self.touch_drag_prevented('#composerLayer .canvas',-40))
        self.assertEqual(self.page.locator('#composerLayer .capture').bounding_box(),toolbar)

    def test_subpage_back_preserves_caption_crop_title_body_and_attachment(self):
        self.select_photo();self.page.locator('#send').click();self.page.locator('#postText').fill('Keep photo caption')
        self.page.locator('#pngeaPhotoReviewThumbs button').click()
        self.page.wait_for_function("document.querySelector('#pngeaEditorStage canvas').height>0")
        self.page.locator('#pngeaMediaEditorTools button').get_by_text('1:1',exact=True).click();self.page.locator('#pngeaMediaEditorDone').click()
        self.page.locator('#closeComposer').click();self.page.locator('#closeComposer').click()
        self.assertTrue(self.page.locator('#composerLayer').is_visible())
        self.assertEqual(self.page.locator('#postText').input_value(),'Keep photo caption')
        self.assertEqual(self.page.locator('#pngeaComposerMediaGrid img').count(),1)
        self.page.locator('#composerLayer [data-attach="longform"]').click();self.page.locator('#pngeaLongTitleInput').fill('Preserved title')
        self.page.locator('#postText').fill('Article body stays while going back')
        self.page.locator('#closeComposer').click()
        self.assertEqual(self.page.locator('#composerLayer').get_attribute('data-post-kind'),'text')
        self.assertEqual(self.page.locator('#postText').input_value(),'Article body stays while going back')
        self.assertEqual(self.page.locator('#pngeaComposerMediaGrid img').count(),1)
        self.page.locator('#composerLayer [data-attach="longform"]').click()
        self.assertEqual(self.page.locator('#pngeaLongTitleInput').input_value(),'Preserved title')


if __name__=='__main__':unittest.main(verbosity=2)
