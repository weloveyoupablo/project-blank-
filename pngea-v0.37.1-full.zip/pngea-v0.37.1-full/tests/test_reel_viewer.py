"""Reel presentation and real video playback using local API/media fixtures."""
import unittest
from . import browser_reliability as fixture


class ReelViewer(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp = fixture.Reliability.setUp
    tearDown = fixture.Reliability.tearDown
    route = fixture.Reliability.route
    navigate = fixture.Reliability.navigate

    def install_video(self, duration=2000, edit=None):
        self.page.evaluate("""async ({duration,edit})=>{
            window.reelPost={id:'pst_reel',author_id:'usr_other',handle:'other',display_name:'Other',text:'A real reel caption',created_at:'2026-10-16T12:00:00Z',content_kind:'gallery',viewer_liked:false,viewer_saved:false,likes:2,reposts:1,replies:3,media:[{id:'media_reel',mimeType:'video/mp4',width:160,height:284,durationMs:duration,...(edit?{edit}:{})}]};
            window.PNGEA_API.feed=async()=>({items:[window.reelPost]});
            window.PNGEA_API.post=async()=>window.reelPost;
            window.PNGEA_API.mediaAccess=async()=>({mimeType:'video/mp4',url:'http://localhost/tests/fixtures/reel.mp4'});
            window.PNGEA_API.likePost=async()=>({});window.PNGEA_API.unlikePost=async()=>({});
            window.PNGEA_API.repost=async()=>({});window.PNGEA_API.unrepost=async()=>({});
            window.PNGEA_API.bookmarkPost=async()=>({});window.PNGEA_API.unbookmarkPost=async()=>({});
            return window.PNGEA_LIVE.loadFeed();
        }""", dict(duration=duration,edit=edit))
        self.page.wait_for_selector('#feed video')

    def expand(self):
        self.page.locator('#feed video').click(position=dict(x=30,y=90))
        self.page.wait_for_selector('#pngeaMediaViewer.pngeaReelViewer.show')
        self.page.wait_for_function("document.querySelector('#pngeaMediaViewer video').readyState>=1")

    def test_inline_reel_preserves_ratio_and_overlay_at_small_sizes(self):
        self.install_video()
        for width,height in ((390,844),(320,568),(430,932)):
            self.page.set_viewport_size(dict(width=width,height=height))
            self.page.wait_for_timeout(80)
            slot=self.page.locator('#feed .pngeaReelSlot').bounding_box()
            self.assertLess(abs(slot['width']/slot['height']-9/16),.01)
            self.assertLessEqual(slot['height'],620.5)
            header=self.page.locator('#feed .pngeaCardHeader').bounding_box()
            self.assertLessEqual(abs(slot['x']-header['x']),1)
            self.assertLessEqual(abs(slot['width']-header['width']),1)
        self.assertEqual(self.page.locator('#feed video').evaluate('(v)=>[v.muted,v.autoplay,v.loop,v.controls]'),[True,True,True,False])
        self.page.locator('#feed .pngeaReelMute').click()
        self.assertFalse(self.page.locator('#feed video').evaluate('(v)=>v.muted'))

    def test_fullscreen_has_author_caption_vertical_actions_and_real_seek(self):
        self.install_video();self.expand()
        self.assertEqual(self.page.locator('.pngeaReelAuthor span').inner_text(),'Other')
        self.assertEqual(self.page.locator('.pngeaReelCaption').inner_text(),'A real reel caption')
        self.assertEqual(self.page.locator('.pngeaReelActions [data-live-action]').evaluate_all('(rows)=>rows.map(row=>row.dataset.liveAction)'),['like','reply','repost','share','save'])
        self.assertEqual(self.page.locator('.pngeaReelActions [data-live-action]').evaluate_all('(rows)=>rows.map(row=>getComputedStyle(row).color)'),['rgb(255, 255, 255)']*5)
        self.assertTrue(self.page.locator('.app').evaluate('(el)=>el.inert'))
        self.page.locator('.pngeaReelPlay').click()
        self.page.wait_for_function("document.querySelector('#pngeaMediaViewer video').paused&&document.querySelector('.pngeaReelPlay').dataset.playState==='paused'")
        self.assertTrue(self.page.locator('.pngeaReelPlay').evaluate("button=>{const icon=button.querySelector('svg'),sound=document.querySelector('.pngeaReelSound svg');document.querySelector('#pngeaMediaViewer video').dispatchEvent(new Event('timeupdate'));return !!icon&&button.querySelector('svg')===icon&&document.querySelector('.pngeaReelSound svg')===sound}"))
        self.page.locator('.pngeaReelSeek').evaluate('(input)=>{input.value="650";input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}))}')
        self.page.wait_for_function("(()=>{const video=document.querySelector('#pngeaMediaViewer video');return !video.seeking&&Math.abs(video.currentTime/video.duration-.65)<.03})()")
        state=self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>({time:v.currentTime,duration:v.duration})')
        self.assertLess(abs(state['time']/state['duration']-.65),.03)
        self.page.locator('.pngeaReelSeek').evaluate('(input)=>{input.value="150";input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}))}')
        self.page.wait_for_function("(()=>{const video=document.querySelector('#pngeaMediaViewer video');return !video.seeking&&Math.abs(video.currentTime/video.duration-.15)<.03})()")
        self.assertLess(self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>v.currentTime'),state['time'])
        self.page.locator('#pngeaMediaViewerClose').click()
        self.assertFalse(self.page.locator('.app').evaluate('(el)=>el.inert'))
        self.assertEqual(self.errors,[])

    def test_fullscreen_actions_update_same_post_and_share_internally(self):
        self.install_video();self.expand()
        self.page.locator('.pngeaReelActions [data-live-action="like"]').click()
        self.assertIn('activeAction',self.page.locator('#feed [data-live-action="like"]').get_attribute('class'))
        self.page.locator('.pngeaReelActions [data-live-action="save"]').click()
        self.assertEqual(self.page.locator('.pngeaReelActions [data-live-action="save"]').get_attribute('aria-pressed'),'true')
        self.page.locator('.pngeaReelActions [data-live-action="share"]').click()
        self.assertFalse(self.page.locator('#pngeaMediaViewer').is_visible())
        self.assertTrue(self.page.locator('#pngeaSendPostPage').is_visible())

    def test_reel_comment_returns_to_original_feed(self):
        self.install_video();self.expand()
        self.page.locator('.pngeaReelActions [data-live-action="reply"]').click()
        self.assertFalse(self.page.locator('#pngeaMediaViewer').is_visible())
        self.assertTrue(self.page.locator('#pngeaPostPage').is_visible())
        self.page.locator('#pngeaPostBack').click()
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'),'Home')

    def test_long_video_keeps_native_player_and_landscape_stage(self):
        self.install_video(90000)
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_reel"]').get_attribute('data-post-format'),'video')
        self.assertTrue(self.page.locator('#feed video').evaluate('(v)=>v.controls'))
        slot=self.page.locator('#feed .pngeaMediaSlot').bounding_box()
        self.assertLess(abs(slot['width']/slot['height']-16/9),.01)
        self.page.locator('#feed video').click(position=dict(x=30,y=40))
        self.assertTrue(self.page.locator('#pngeaMediaViewer').is_visible())
        self.assertNotIn('pngeaReelViewer',self.page.locator('#pngeaMediaViewer').get_attribute('class'))
        self.assertTrue(self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>v.controls'))

    def test_fullscreen_trimmed_seek_uses_posted_range(self):
        self.install_video(edit=dict(trimStartMs=400,trimEndMs=1400))
        self.expand();self.page.locator('.pngeaReelPlay').click()
        self.page.locator('.pngeaReelSeek').evaluate('(input)=>{input.value="500";input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}))}')
        self.page.wait_for_function("(()=>{const video=document.querySelector('#pngeaMediaViewer video');return !video.seeking&&Math.abs(video.currentTime-.9)<.08})()")
        self.assertLess(abs(self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>v.currentTime')-.9),.08)


if __name__=='__main__':
    unittest.main()
