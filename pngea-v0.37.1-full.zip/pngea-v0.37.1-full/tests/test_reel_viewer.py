"""Reel presentation and real video playback using local API/media fixtures."""
import io
import unittest
from PIL import Image
from . import browser_reliability as fixture


class ReelViewer(unittest.TestCase):
    setUpClass = classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp = fixture.Reliability.setUp
    tearDown = fixture.Reliability.tearDown
    route = fixture.Reliability.route
    navigate = fixture.Reliability.navigate

    def install_video(self, duration=2000, edit=None, width=160, height=284, file='reel.mp4', metadata=True):
        self.page.evaluate("""async ({duration,edit,width,height,file,metadata})=>{
            window.reelPost={id:'pst_reel',author_id:'usr_other',handle:'other',display_name:'Other',text:'A real reel caption',created_at:'2026-10-16T12:00:00Z',content_kind:'gallery',viewer_liked:false,viewer_saved:false,likes:2,reposts:1,replies:3,media:[{id:'media_reel_'+file,mimeType:'video/mp4',...(metadata?{width,height}:{}),durationMs:duration,...(edit?{edit}:{})}]};
            window.PNGEA_API.feed=async()=>({items:[window.reelPost]});
            window.PNGEA_API.post=async()=>window.reelPost;
            window.PNGEA_API.mediaAccess=async()=>({mimeType:'video/mp4',url:'http://localhost/tests/fixtures/'+file});
            window.PNGEA_API.likePost=async()=>({});window.PNGEA_API.unlikePost=async()=>({});
            window.PNGEA_API.repost=async()=>({});window.PNGEA_API.unrepost=async()=>({});
            window.PNGEA_API.bookmarkPost=async()=>({});window.PNGEA_API.unbookmarkPost=async()=>({});
            return window.PNGEA_LIVE.loadFeed();
        }""", dict(duration=duration,edit=edit,width=width,height=height,file=file,metadata=metadata))
        self.page.wait_for_selector('#feed video')
        self.page.wait_for_function("document.querySelector('#feed video').readyState>=1")

    def expand(self):
        self.page.locator('#feed video').click(position=dict(x=30,y=90))
        self.page.wait_for_selector('#pngeaMediaViewer.pngeaReelViewer.show')
        self.page.wait_for_function("document.querySelector('#pngeaMediaViewer video').readyState>=1")

    def test_inline_reel_preserves_ratio_and_overlay_at_small_sizes(self):
        self.install_video()
        for width,height in ((390,844),(320,568),(430,932)):
            self.page.set_viewport_size(dict(width=width,height=height))
            self.page.wait_for_timeout(80)
            slot=self.page.locator('#feed .pngeaReelSlot').bounding_box()
            self.assertLess(abs(slot['width']/slot['height']-160/284),.005)
            self.assertLessEqual(slot['height'],620.5)
            header=self.page.locator('#feed .pngeaCardHeader').bounding_box()
            self.assertLessEqual(abs(slot['x']-header['x']),1)
            self.assertLessEqual(abs(slot['width']-header['width']),1)
        self.assertEqual(self.page.locator('#feed video').evaluate('(v)=>[v.muted,v.autoplay,v.loop,v.controls]'),[True,True,True,False])
        self.page.locator('#feed .pngeaReelMute').click()
        self.assertFalse(self.page.locator('#feed video').evaluate('(v)=>v.muted'))

    def test_fullscreen_has_author_caption_vertical_actions_and_real_seek(self):
        self.install_video();self.expand()
        self.assertEqual(self.page.locator('.pngeaReelAuthor span').inner_text(),'Other')
        self.assertEqual(self.page.locator('.pngeaReelCaption').inner_text(),'A real reel caption')
        self.assertEqual(self.page.locator('.pngeaReelActions [data-live-action]').evaluate_all('(rows)=>rows.map(row=>row.dataset.liveAction)'),['like','reply','repost','share','save'])
        self.assertEqual(self.page.locator('.pngeaReelActions [data-live-action]').evaluate_all('(rows)=>rows.map(row=>getComputedStyle(row).color)'),['rgb(255, 255, 255)']*5)
        self.assertTrue(self.page.locator('.app').evaluate('(el)=>el.inert'))
        self.page.locator('.pngeaReelPlay').click()
        self.page.wait_for_function("document.querySelector('#pngeaMediaViewer video').paused&&document.querySelector('.pngeaReelPlay').dataset.playState==='paused'")
        self.assertTrue(self.page.locator('.pngeaReelPlay').evaluate("button=>{const icon=button.querySelector('svg'),sound=document.querySelector('.pngeaReelSound svg');document.querySelector('#pngeaMediaViewer video').dispatchEvent(new Event('timeupdate'));return !!icon&&button.querySelector('svg')===icon&&document.querySelector('.pngeaReelSound svg')===sound}"))
        self.page.locator('.pngeaReelSeek').evaluate('(input)=>{input.value="650";input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}))}')
        self.page.wait_for_function("(()=>{const video=document.querySelector('#pngeaMediaViewer video');return !video.seeking&&Math.abs(video.currentTime/video.duration-.65)<.03})()")
        state=self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>({time:v.currentTime,duration:v.duration})')
        self.assertLess(abs(state['time']/state['duration']-.65),.03)
        self.page.locator('.pngeaReelSeek').evaluate('(input)=>{input.value="150";input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}))}')
        self.page.wait_for_function("(()=>{const video=document.querySelector('#pngeaMediaViewer video');return !video.seeking&&Math.abs(video.currentTime/video.duration-.15)<.03})()")
        self.assertLess(self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>v.currentTime'),state['time'])
        self.page.locator('#pngeaMediaViewerClose').click()
        self.assertFalse(self.page.locator('.app').evaluate('(el)=>el.inert'))
        self.assertEqual(self.errors,[])

    def test_fullscreen_actions_update_same_post_and_share_internally(self):
        self.install_video();self.expand()
        self.page.locator('.pngeaReelActions [data-live-action="like"]').click()
        self.assertIn('activeAction',self.page.locator('#feed [data-live-action="like"]').get_attribute('class'))
        self.page.locator('.pngeaReelActions [data-live-action="save"]').click()
        self.assertEqual(self.page.locator('.pngeaReelActions [data-live-action="save"]').get_attribute('aria-pressed'),'true')
        self.page.locator('.pngeaReelActions [data-live-action="share"]').click()
        self.assertFalse(self.page.locator('#pngeaMediaViewer').is_visible())
        self.assertTrue(self.page.locator('#pngeaSendPostPage').is_visible())

    def test_reel_comment_returns_to_original_feed(self):
        self.install_video();self.expand()
        self.page.locator('.pngeaReelActions [data-live-action="reply"]').click()
        self.assertFalse(self.page.locator('#pngeaMediaViewer').is_visible())
        self.assertTrue(self.page.locator('#pngeaPostPage').is_visible())
        self.page.locator('#pngeaPostBack').click()
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'),'Home')

    def test_long_video_keeps_native_player_and_original_stage(self):
        self.install_video(90000)
        self.assertEqual(self.page.locator('#feed [data-server-post="pst_reel"]').get_attribute('data-post-format'),'video')
        self.assertTrue(self.page.locator('#feed video').evaluate('(v)=>v.controls'))
        slot=self.page.locator('#feed .pngeaMediaSlot').bounding_box()
        self.assertLess(abs(slot['width']/slot['height']-160/284),.005)
        self.page.locator('#feed video').click(position=dict(x=30,y=40))
        self.assertTrue(self.page.locator('#pngeaMediaViewer').is_visible())
        self.assertNotIn('pngeaReelViewer',self.page.locator('#pngeaMediaViewer').get_attribute('class'))
        self.assertTrue(self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>v.controls'))

    def test_square_and_landscape_videos_keep_complete_original_frames(self):
        for width,height,file in ((160,160,'video-square.mp4'),(320,180,'video-landscape.mp4')):
            with self.subTest(file=file):
                self.install_video(width=width,height=height,file=file,edit=dict(aspect='4:5'))
                video=self.page.locator('#feed video')
                self.assertEqual(video.evaluate('(video)=>[video.videoWidth,video.videoHeight]'),[width,height])
                slot=self.page.locator('#feed .pngeaVideoSlot').bounding_box()
                self.assertLess(abs(slot['width']/slot['height']-width/height),.005)
                self.assertEqual(video.evaluate('(video)=>getComputedStyle(video).objectFit'),'contain')
                header=self.page.locator('#feed .pngeaCardHeader').bounding_box()
                self.assertAlmostEqual(header['width'],slot['width'],delta=1)
                self.expand()
                self.assertEqual(self.page.locator('#pngeaMediaViewer video').evaluate('(video)=>getComputedStyle(video).objectFit'),'contain')
                self.assertEqual(self.page.locator('#pngeaMediaViewer video').evaluate('(video)=>getComputedStyle(video).backgroundColor'),'rgb(0, 0, 0)')
                self.assertEqual(self.page.locator('.pngeaReelAuthor span').inner_text(),'Other')
                self.assertEqual(self.page.locator('.pngeaReelCaption').inner_text(),'A real reel caption')
                self.assertEqual(self.page.locator('.pngeaReelActions [data-live-action]').count(),5)
                self.page.wait_for_function("document.querySelector('#pngeaMediaViewer video').readyState>=2")
                frame=Image.open(io.BytesIO(self.page.screenshot())).convert('RGB')
                self.assertEqual(frame.getpixel((5,100)),(0,0,0))
                self.assertEqual(frame.getpixel((5,frame.height-100)),(0,0,0))
                self.assertTrue(all(110<=channel<=145 for channel in frame.getpixel((frame.width//2,frame.height//2))))
                self.page.locator('#pngeaMediaViewerClose').click()

    def test_missing_dimensions_resolve_from_intrinsic_video_metadata(self):
        self.install_video(width=160,height=160,file='video-square.mp4',metadata=False)
        self.page.wait_for_function("Number(document.querySelector('#feed .pngeaVideoSlot').style.getPropertyValue('--pn-media-ratio'))===1")
        slot=self.page.locator('#feed .pngeaVideoSlot').bounding_box()
        self.assertAlmostEqual(slot['width'],slot['height'],delta=1)

    def test_dimensions_reserve_original_ratio_before_video_access_finishes(self):
        self.page.evaluate("""async()=>{
            window.PNGEA_API.mediaAccess=()=>new Promise(resolve=>window.releaseSquareVideo=resolve);
            window.PNGEA_API.feed=async()=>({items:[{id:'pending_square',handle:'other',display_name:'Other',text:'A square video',content_kind:'gallery',media:[{id:'pending_square_media',mimeType:'video/mp4',width:160,height:160,durationMs:2000}]}]});
            return window.PNGEA_LIVE.loadFeed();
        }""")
        self.page.wait_for_selector('#feed .pngeaVideoSlot')
        before=self.page.locator('#feed .pngeaVideoSlot').bounding_box()
        self.assertAlmostEqual(before['width'],before['height'],delta=1)
        self.assertEqual(self.page.locator('#feed video').count(),0)
        self.page.evaluate("window.releaseSquareVideo({mimeType:'video/mp4',url:'http://localhost/tests/fixtures/video-square.mp4'})")
        self.page.wait_for_function("document.querySelector('#feed video')?.readyState>=1")
        after=self.page.locator('#feed .pngeaVideoSlot').bounding_box()
        self.assertAlmostEqual(before['width'],after['width'],delta=1)
        self.assertAlmostEqual(before['height'],after['height'],delta=1)

    def test_fullscreen_trimmed_seek_uses_posted_range(self):
        self.install_video(edit=dict(trimStartMs=400,trimEndMs=1400))
        self.expand();self.page.locator('.pngeaReelPlay').click()
        self.page.locator('.pngeaReelSeek').evaluate('(input)=>{input.value="500";input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}))}')
        self.page.wait_for_function("(()=>{const video=document.querySelector('#pngeaMediaViewer video');return !video.seeking&&Math.abs(video.currentTime-.9)<.08})()")
        self.assertLess(abs(self.page.locator('#pngeaMediaViewer video').evaluate('(v)=>v.currentTime')-.9),.08)


if __name__=='__main__':
    unittest.main()
