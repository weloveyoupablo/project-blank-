"""Photo comments stay over the timeline; media and reactions keep stable nodes."""
import unittest
try:
    from . import browser_reliability as fixture
except ImportError:
    import browser_reliability as fixture


class PhotoCommentsStability(unittest.TestCase):
    setUpClass=classmethod(fixture.Reliability.setUpClass.__func__)
    tearDownClass=classmethod(fixture.Reliability.tearDownClass.__func__)
    setUp=fixture.Reliability.setUp
    tearDown=fixture.Reliability.tearDown
    route=fixture.Reliability.route
    navigate=fixture.Reliability.navigate

    def photo(self):
        self.page.evaluate("""()=>{
          window.photoFixture={id:'photo_sheet',author_id:'usr_other',handle:'other',display_name:'Other',content_kind:'gallery',text:'A photo caption',likes:1,media:[{id:'sheet_image',mimeType:'image/png',width:400,height:500}]};
          window.PNGEA_API.feed=async()=>({items:[window.photoFixture]});
          window.PNGEA_API.post=async()=>window.photoFixture;
          window.PNGEA_API.mediaAccess=async()=>({url:'http://localhost/other.svg',mimeType:'image/png'});
          window.PNGEA_API.postReplies=async id=>({items:id==='comment_a'?[{id:'nested_a',handle:'tester',display_name:'Tester',text:'A nested reply',replies:0,media:[]}]:[{id:'comment_a',handle:'other',display_name:'Other',text:'Original comment',replies:1,media:[]}]});
        }""")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.page.wait_for_selector('#feed [data-server-post="photo_sheet"]')

    def open_comments(self):
        self.photo()
        self.page.locator('#feed [data-live-action="reply"]').click()
        self.page.wait_for_selector('#pngeaPostPage.pngeaPhotoComments #pngeaReplyList [data-comment-thread]')

    def test_comments_stay_on_timeline_and_lock_background(self):
        before=self.page.url
        self.open_comments()
        self.assertEqual(self.page.url,before)
        self.assertTrue(self.page.locator('.app').evaluate('(e)=>e.inert'))
        self.assertTrue(self.page.locator('#pngeaCommentsShade').is_visible())
        self.assertGreater(self.page.locator('#pngeaPostPage').bounding_box()['y'],100)
        self.page.locator('#pngeaPostBack').click()
        self.assertFalse(self.page.locator('.app').evaluate('(e)=>e.inert'))
        self.assertFalse(self.page.locator('#pngeaPostPage').is_visible())
        self.assertEqual(self.page.url,before)

    def test_comments_expand_and_keyboard_keeps_editor_at_boundary(self):
        self.open_comments()
        self.page.locator('#pngeaCommentsHandle').click()
        self.page.wait_for_function("document.querySelector('#pngeaPostPage').dataset.commentsExpanded==='true'")
        self.page.wait_for_function("document.querySelector('#pngeaPostPage').getBoundingClientRect().top<=2")
        self.assertAlmostEqual(self.page.locator('#pngeaPostPage').bounding_box()['y'],0,delta=2)
        self.page.locator('#pngeaPostReplyInput').focus()
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        bar=self.page.locator('#pngeaPostReplyBar').bounding_box()
        self.assertAlmostEqual(bar['y']+bar['height'],460,delta=2)

    def test_nested_replies_are_collapsed_and_reply_targets_comment(self):
        self.open_comments()
        self.assertFalse(self.page.locator('.pngeaCommentChildren').is_visible())
        self.page.locator('[data-comment-expand="comment_a"]').click()
        self.page.wait_for_selector('[data-server-post="nested_a"]')
        self.page.locator('[data-server-post="comment_a"] [data-live-action="reply"]').click()
        self.page.locator('#pngeaPostReplyInput').fill('Reply to the comment')
        self.page.evaluate("()=>{window.createdComment=null;window.PNGEA_API.createPost=async body=>{window.createdComment=body;return {id:'new_reply'}}}")
        self.page.locator('#pngeaPostReplySend').click()
        self.page.wait_for_function('window.createdComment!==null')
        self.assertEqual(self.page.evaluate('window.createdComment.replyToId'),'comment_a')
        self.assertIn('#/home',self.page.url)

    def test_feed_refresh_preserves_image_and_heart_nodes(self):
        self.photo()
        self.page.wait_for_selector('#feed .pngeaMediaSlot img')
        self.page.evaluate("()=>{window.retainedImage=document.querySelector('#feed .pngeaMediaSlot img');window.retainedHeart=document.querySelector('#feed [data-live-action=like] svg');window.photoFixture.likes=2}")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.assertTrue(self.page.evaluate("window.retainedImage===document.querySelector('#feed .pngeaMediaSlot img')"))
        self.assertTrue(self.page.evaluate("window.retainedHeart===document.querySelector('#feed [data-live-action=like] svg')"))
        self.assertEqual(self.page.locator('#feed [data-live-action="like"]').get_attribute('data-count'),'2')

    def test_grey_placeholder_reserves_media_space_before_access_finishes(self):
        self.page.evaluate("()=>{window.PNGEA_API.feed=async()=>({items:[{id:'reserved',handle:'other',display_name:'Other',content_kind:'gallery',text:'Caption',media:[{id:'slow_image',mimeType:'image/png',width:400,height:500}]}]});window.PNGEA_API.mediaAccess=()=>new Promise(resolve=>window.finishImageAccess=resolve)}")
        self.page.evaluate('window.PNGEA_LIVE.loadFeed()')
        self.page.wait_for_selector('#feed .pngeaMediaSlot')
        self.page.wait_for_function("typeof window.finishImageAccess==='function'")
        before=self.page.locator('#feed .pngeaMediaSlot').bounding_box()
        self.assertGreater(before['height'],100)
        self.assertEqual(self.page.locator('#feed .pngeaMediaSlot img').count(),0)
        self.page.evaluate("window.finishImageAccess({url:'http://localhost/other.svg',mimeType:'image/png'})")
        self.page.wait_for_selector('#feed .pngeaMediaSlot img')
        self.assertEqual(self.page.locator('#feed .pngeaMediaSlot').bounding_box(),before)


if __name__=='__main__':unittest.main(verbosity=2)
