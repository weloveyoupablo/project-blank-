"""One chat menu and floating canonical conversation regressions."""
import unittest
try:
    from . import browser_reliability as fixtures
except ImportError:
    import browser_reliability as fixtures


class Chatheads(unittest.TestCase):
    setUpClass = classmethod(fixtures.Reliability.setUpClass.__func__)
    tearDownClass = classmethod(fixtures.Reliability.tearDownClass.__func__)
    setUp = fixtures.Reliability.setUp
    tearDown = fixtures.Reliability.tearDown
    route = fixtures.Reliability.route
    navigate = fixtures.Reliability.navigate

    def create_head(self):
        self.navigate('Inbox')
        self.page.locator('[data-live-conversation="cnv_a"]').dispatch_event('contextmenu')
        self.page.locator('[data-chat-action="head"]').click()
        self.page.wait_for_selector('.pngeaChatHead[data-conversation-id="cnv_a"]')

    def open_mini(self):
        self.create_head()
        self.navigate('Home')
        self.page.locator('.pngeaChatHead').click()
        self.page.wait_for_selector('#dmThread.pngeaMiniChat.show')
        self.page.wait_for_timeout(100)

    def test_inbox_touch_hold_and_native_contextmenu_use_one_chat_menu(self):
        self.navigate('Inbox')
        row=self.page.locator('[data-live-conversation="cnv_a"]')
        row.evaluate("""target=>{const touch=new Touch({identifier:1,target,clientX:150,clientY:200,pageX:150,pageY:200,screenX:150,screenY:200});target.dispatchEvent(new TouchEvent('touchstart',{bubbles:true,cancelable:true,touches:[touch],changedTouches:[touch]}))}""")
        self.page.wait_for_timeout(650)
        prevented=row.evaluate("target=>{const e=new MouseEvent('contextmenu',{bubbles:true,cancelable:true});target.dispatchEvent(e);return e.defaultPrevented}")
        row.dispatch_event('touchend', {'touches': [], 'changedTouches': []})
        self.assertTrue(prevented)
        self.assertEqual(self.page.locator('#pnActionSheet.show').count(), 1)
        self.assertEqual(self.page.locator('#pnSheetActions b').all_text_contents(), ['Open chat', 'Create chathead'])
        row.locator('.xAvatar').dispatch_event('click')
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'), 'Inbox')
        self.assertFalse(self.page.locator('#dmThread').is_visible())

    def test_message_menu_targets_the_actual_message(self):
        self.navigate('Inbox', 'cnv_a')
        self.page.locator('#dmMessages [data-message-id]').dispatch_event('contextmenu')
        self.assertEqual(self.page.locator('#pnSheetActions b').all_text_contents(), ['Remember', 'Create event', 'Create community', 'Ask about this'])
        self.page.locator('[data-object-action="remember"]').click()
        memory=self.page.evaluate('window.PNGEA.state.memory[0]')
        self.assertEqual(memory['key'], 'msg_cnv_a')
        self.assertEqual(memory['type'], 'message')
        self.assertEqual(memory['context'], 'Message cnv_a')

    def test_mini_chat_reuses_input_outbox_and_canonical_messages(self):
        self.page.evaluate("""()=>{
          window.existingDmInput=document.querySelector('#dmInput');window.sentMini=[];window.miniMessages=[];
          window.PNGEA_API.messages=async()=>({items:window.miniMessages});
          window.PNGEA_API.sendMessage=async(id,body)=>{window.sentMini.push({id,...body});window.miniMessages.push({id:'mini_sent',sender_id:'usr_self',text:body.text,media:[]});return{id:'mini_sent'}};
        }""")
        self.open_mini()
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'), 'Home')
        self.assertEqual(self.page.locator('#dmThread').count(), 1)
        self.assertEqual(self.page.locator('#dmInput').count(), 1)
        self.assertTrue(self.page.evaluate('window.existingDmInput===document.querySelector("#dmInput")'))
        self.assertTrue(self.page.locator('#pngeaDmPlus').is_visible())
        self.page.locator('#dmInput').fill('Sent from the same outbox')
        self.page.locator('#dmSend').click()
        self.page.wait_for_function("document.querySelector('#dmMessages').textContent.includes('Sent from the same outbox')")
        sent=self.page.evaluate('window.sentMini')
        self.assertEqual(len(sent), 1)
        self.assertEqual(sent[0]['id'], 'cnv_a')
        self.assertTrue(sent[0]['clientId'])
        self.assertEqual(self.page.locator('#dmInput').input_value(), '')
        self.page.locator('[data-mini-chat="full"]').click()
        self.page.wait_for_function("window.PNGEA.parseRoute().detail==='cnv_a'")
        self.assertFalse(self.page.locator('#dmThread').evaluate("e=>e.classList.contains('pngeaMiniChat')"))

    def test_mini_chat_leaves_app_navigation_and_badges_working(self):
        self.open_mini()
        self.assertFalse(self.page.evaluate("document.documentElement.classList.contains('pngeaThreadViewport')"))
        self.navigate('History')
        self.assertTrue(self.page.locator('#History.active').is_visible())
        self.assertTrue(self.page.locator('#dmThread.pngeaMiniChat').is_visible())
        self.page.evaluate("""()=>{const rows=window.PNGEA_LIVE.state.conversations.map(c=>({...c,unread:c.id==='cnv_a'?4:0}));window.PNGEA_LIVE.state.conversations=rows;window.dispatchEvent(new CustomEvent('pngea:conversations',{detail:rows}))}""")
        self.assertEqual(self.page.locator('.pngeaChatHeadUnread').inner_text(), '4')
        self.page.locator('[data-mini-chat="minimize"]').click()
        self.assertFalse(self.page.locator('#dmThread').is_visible())
        self.assertTrue(self.page.locator('.pngeaChatHead').is_visible())
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'), 'History')

    def test_dragging_a_chathead_does_not_open_chat_or_drag_the_app(self):
        self.create_head()
        self.navigate('Home')
        head=self.page.locator('.pngeaChatHead')
        before=head.bounding_box()
        self.page.mouse.move(before['x']+26, before['y']+26)
        self.page.mouse.down()
        self.page.mouse.move(before['x']-90, before['y']+100, steps=6)
        self.page.mouse.up()
        after=head.bounding_box()
        self.assertGreater(after['y'], before['y']+30)
        self.assertFalse(self.page.locator('#dmThread').is_visible())
        self.assertEqual(self.page.evaluate('window.scrollY'), 0)
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'), 'Home')

    def test_removed_conversation_and_account_switch_clear_heads(self):
        self.open_mini()
        self.page.evaluate("""()=>{const rows=window.PNGEA_LIVE.state.conversations.filter(c=>c.id!=='cnv_a');window.PNGEA_LIVE.state.conversations=rows;window.dispatchEvent(new CustomEvent('pngea:conversations',{detail:rows}))}""")
        self.assertEqual(self.page.locator('.pngeaChatHead').count(), 0)
        self.assertFalse(self.page.locator('#dmThread').is_visible())
        self.create_head()
        self.page.evaluate("""()=>{window.PNGEA_API.getActiveAccountKey=()=> 'another_account';window.dispatchEvent(new CustomEvent('pngea:conversations',{detail:window.PNGEA_LIVE.state.conversations}))}""")
        self.assertEqual(self.page.locator('.pngeaChatHead').count(), 0)

    def test_mini_composer_meets_keyboard_inside_one_frame(self):
        self.open_mini()
        self.page.locator('#dmInput').focus()
        self.page.evaluate("Object.defineProperty(window.visualViewport,'height',{configurable:true,value:460});window.visualViewport.dispatchEvent(new Event('resize'))")
        self.page.wait_for_function("document.documentElement.classList.contains('pngeaKeyboardOpen')")
        self.page.wait_for_timeout(80)
        frame=self.page.locator('#dmThread').bounding_box()
        bar=self.page.locator('.dmCompose').bounding_box()
        self.assertAlmostEqual(frame['y']+frame['height'], 460, delta=2)
        self.assertAlmostEqual(bar['y']+bar['height'], 460, delta=2)
        self.assertLessEqual(frame['height'], 422)
        self.assertTrue(self.page.evaluate("document.documentElement.classList.contains('pngeaThreadViewport')"))

    def test_shared_post_back_restores_mini_and_original_page(self):
        self.page.evaluate("()=>{window.PNGEA_API.messages=async()=>({items:[{id:'mini_share',sender_id:'usr_other',text:'http://localhost/#/post/pst_real',media:[]}]})}")
        self.open_mini()
        self.page.locator('#dmInput').fill('Mini draft stays')
        self.page.locator('.pngeaSharedPreview').click()
        self.page.wait_for_selector('#pngeaPostPage.show')
        self.page.locator('#pngeaPostBack').click()
        self.page.wait_for_selector('#dmThread.pngeaMiniChat.show')
        self.assertEqual(self.page.evaluate('window.PNGEA.parseRoute().screen'), 'Home')
        self.assertEqual(self.page.locator('#dmInput').input_value(), 'Mini draft stays')


if __name__ == '__main__':
    unittest.main(verbosity=2)
