// Local integration server for the real browser upload path. This uses the
// production route bodies, validation and AWS presigner with embedded PostgreSQL.
// Only authentication, Redis delivery and S3's remote storage service are replaced.
// Run from the root tool with local networking enabled; never point at production.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const moduleRoot=process.env.PNGEA_TEST_MODULE_ROOT;
if(!moduleRoot)throw new Error('Set PNGEA_TEST_MODULE_ROOT to the temporary test node_modules directory.');
const require=createRequire(path.resolve(moduleRoot,'../package.json'));
const Fastify=require('fastify'),{z,ZodError}=require('zod');
const sdk=require('@aws-sdk/client-s3'),{getSignedUrl}=require('@aws-sdk/s3-request-presigner');
const {PGlite}=await import(`${moduleRoot}/@electric-sql/pglite/dist/index.js`);
const {pgcrypto}=await import(`${moduleRoot}/@electric-sql/pglite/dist/contrib/pgcrypto.js`);

class ApiError extends Error {constructor(statusCode,code,message,details){super(message);Object.assign(this,{statusCode,code,details})}}
const strip=source=>source.replace(/^import[\s\S]*?;\s*\n/gm,'').replace(/^export \{[^}]*\};?\s*$/gm,'').replace(/\bexport\s+/g,'');
function factory(relative,context,result){
  const source=fs.readFileSync(path.join(root,'backend/src',relative),'utf8');
  return new Function(...Object.keys(context),strip(source)+`;return ${result};`)(...Object.values(context));
}
function crc32(bytes){
  let result=0xffffffff;
  for(const byte of bytes){result^=byte;for(let bit=0;bit<8;bit++)result=(result>>>1)^((result&1)?0xedb88320:0)}
  const out=Buffer.alloc(4);out.writeUInt32BE((result^0xffffffff)>>>0);return out.toString('base64');
}
function corsHeaders(origin){return {
  'Access-Control-Allow-Origin':origin||'*','Access-Control-Allow-Credentials':'true',
  'Access-Control-Allow-Methods':'GET,HEAD,PUT,POST,PATCH,DELETE,OPTIONS',
  'Access-Control-Expose-Headers':'Content-Length,Content-Type,Content-Range,ETag'
}}

export async function startHarness({apiPort=0,storagePort=0}={}){
  const pg=new PGlite({extensions:{pgcrypto}}),objects=new Map(),storageTrace=[],apiTrace=[],events=[];
  const adapt=result=>({...result,rowCount:result.rows.length||result.affectedRows||0});
  const db={query:async(sql,args)=>adapt(await pg.query(sql,args))};
  const tx=fn=>pg.transaction(c=>fn({query:async(sql,args)=>adapt(await c.query(sql,args))}));
  for(const file of fs.readdirSync(path.join(root,'backend/sql')).filter(name=>name.endsWith('.sql')).sort())await pg.exec(fs.readFileSync(path.join(root,'backend/sql',file),'utf8'));
  for(const [id,handle,name] of [['usr_self','tester','Tester'],['usr_other','other','Other'],['usr_viewer','viewer','Viewer']]){
    await pg.query(`insert into users(id,email,password_hash) values($1,$2,'local-test-only')`,[id,`${handle}@example.test`]);
    await pg.query(`insert into profiles(user_id,handle,display_name) values($1,$2,$3)`,[id,handle,name]);
    await pg.query(`insert into user_settings(user_id) values($1)`,[id]);
  }
  await pg.exec(`insert into follows(follower_id,followee_id) values('usr_self','usr_other'),('usr_other','usr_self'),('usr_viewer','usr_self');`);

  const bucket='pngea-local-media';
  const storage=http.createServer(async(req,res)=>{
    const url=new URL(req.url,'http://127.0.0.1'),headers=corsHeaders(req.headers.origin);
    headers['Access-Control-Allow-Headers']=req.headers['access-control-request-headers']||'*';
    const error=(status,code,message)=>{res.writeHead(status,{...headers,'Content-Type':'application/xml'});res.end(`<Error><Code>${code}</Code><Message>${message}</Message></Error>`)};
    if(req.method==='OPTIONS'){res.writeHead(204,headers);res.end();return;}
    let decoded;try{decoded=decodeURIComponent(url.pathname)}catch{return error(400,'InvalidURI','Invalid object path')}
    if(decoded===`/${bucket}`||decoded===`/${bucket}/`){res.writeHead(200,headers);res.end();return;}
    if(!decoded.startsWith(`/${bucket}/`))return error(404,'NoSuchBucket','Unknown test bucket');
    const key=decoded.slice(bucket.length+2);
    if(req.method==='PUT'){
      const chunks=[];let size=0;
      for await(const chunk of req){size+=chunk.length;if(size>64*1024*1024){req.resume();return error(413,'EntityTooLarge','Local test upload exceeds 64 MiB')}chunks.push(chunk)}
      const bytes=Buffer.concat(chunks),checksum=url.searchParams.get('x-amz-checksum-crc32')||req.headers['x-amz-checksum-crc32'];
      const valid=!checksum||checksum===crc32(bytes);
      storageTrace.push({method:'PUT',key,bytes:bytes.length,signedCrc32:checksum||null,actualCrc32:crc32(bytes),validChecksum:valid});
      // This catches the SDK's automatic empty-body CRC32 on a presigned PUT.
      // Accepting every PUT here would hide the actual browser upload failure.
      if(!valid)return error(400,'BadDigest','The signed CRC32 does not match the uploaded file');
      const etag=`"${crypto.createHash('md5').update(bytes).digest('hex')}"`;
      objects.set(key,{bytes,mime:req.headers['content-type']||'application/octet-stream',etag});
      res.writeHead(200,{...headers,ETag:etag});res.end();return;
    }
    const object=objects.get(key);storageTrace.push({method:req.method,key,found:!!object});
    if(!object)return error(404,'NoSuchKey','Object is unavailable');
    if(req.method==='DELETE'){objects.delete(key);res.writeHead(204,headers);res.end();return;}
    const match=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range||''),start=match?Number(match[1]):0,end=match&&match[2]?Math.min(Number(match[2]),object.bytes.length-1):object.bytes.length-1;
    if(start>end||start>=object.bytes.length)return error(416,'InvalidRange','Range outside object');
    res.writeHead(match?206:200,{...headers,'Content-Type':object.mime,'Content-Length':end-start+1,'Accept-Ranges':'bytes',ETag:object.etag,...(match?{'Content-Range':`bytes ${start}-${end}/${object.bytes.length}`}:{})});
    res.end(req.method==='HEAD'?undefined:object.bytes.subarray(start,end+1));
  });
  await new Promise((resolve,reject)=>{storage.once('error',reject);storage.listen(storagePort,'127.0.0.1',resolve)});
  const storageBase=`http://127.0.0.1:${storage.address().port}`;
  const config={objectStorageRegion:'us-east-1',objectStorageEndpoint:storageBase,objectStorageForcePathStyle:true,objectStorageBucket:bucket,objectStorageAccessKey:'local-test-key',objectStorageSecretKey:'local-test-secret',objectStoragePublicBaseUrl:''};
  const storageContext={config,getSignedUrl,...Object.fromEntries(['S3Client','CreateBucketCommand','HeadBucketCommand','HeadObjectCommand','DeleteObjectCommand','GetObjectCommand','PutObjectCommand'].map(name=>[name,sdk[name]]))};
  const storageApi=factory('lib/object-storage.js',storageContext,'({objectStorage,createUploadUrl,createDownloadUrl,headMediaObject,deleteMediaObject})');
  const publishGlobal=async(type,data)=>events.push({type,data});
  const publishToUsers=async(userIds,type,data)=>events.push({userIds,type,data});
  const notify=factory('lib/notify.js',{db,publishToUsers},'notify');
  const audit=factory('lib/audit.js',{db},'audit');
  const context={z,path,db,tx,ApiError,opaqueId:prefix=>`${prefix}_${crypto.randomUUID().replaceAll('-','')}`,audit,notify,publishGlobal,publishToUsers,...storageApi};
  const app=Fastify({logger:false,bodyLimit:2_000_000});
  app.addHook('onRequest',async(req,reply)=>{
    for(const [name,value] of Object.entries(corsHeaders(req.headers.origin)))reply.header(name,value);
    reply.header('Access-Control-Allow-Headers',req.headers['access-control-request-headers']||'Content-Type,Authorization,X-PNGEA-Test-User');
    if(req.method==='OPTIONS')return reply.code(204).send();
  });
  app.addHook('onResponse',async(req,reply)=>{apiTrace.push({method:req.method,path:req.url,status:reply.statusCode})});
  const authenticate=async req=>{
    const id=String(req.headers['x-pngea-test-user']||'usr_self');
    if(!['usr_self','usr_other','usr_viewer'].includes(id))throw new ApiError(401,'AUTH_REQUIRED','Unknown local test user');
    req.user={sub:id};
  };
  app.decorate('authenticate',authenticate);app.decorate('optionalAuth',authenticate);
  for(const [file,name] of [['media.js','registerMedia'],['posts.js','registerPosts'],['feed.js','registerFeed'],['users.js','registerUsers'],['messages.js','registerMessages'],['notifications.js','registerNotifications'],['history.js','registerHistory'],['search.js','registerSearch'],['settings.js','registerSettings']])await factory(`modules/${file}`,context,name)(app);
  const fetchVisiblePost=factory('modules/posts.js',context,'fetchVisiblePost');
  await factory('modules/social.js',{...context,fetchVisiblePost},'registerSocial')(app);
  app.get('/health',async()=>({ok:true,version:'local-0.53.1',features:{followingFeed:true,postFormats:true,verifiedMediaUploads:true},time:new Date().toISOString()}));
  app.get('/v1/me',{preHandler:[authenticate]},async req=>{
    const {rows}=await db.query(`select u.id,u.email,p.handle,p.display_name,p.bio,p.avatar_url,p.banner_url,p.avatar_media_id,p.banner_media_id,
      (select count(*)::int from follows where follower_id=u.id) following,(select count(*)::int from follows where followee_id=u.id) followers,
      (select count(*)::int from posts where author_id=u.id and deleted_at is null and reply_to_id is null) posts_count from users u join profiles p on p.user_id=u.id where u.id=$1`,[req.user.sub]);
    return {...rows[0],account_key:req.user.sub==='usr_self'?'0123456789abcdef':req.user.sub};
  });
  app.get('/v1/ticker',async()=>({items:[],generatedAt:new Date().toISOString()}));
  app.get('/v1/now',async()=>({items:[]}));
  app.post('/v1/auth/refresh',async()=>({accessToken:'local-test-token',accountKey:'0123456789abcdef'}));
  app.post('/v1/realtime/ticket',async(req,reply)=>reply.code(503).send({error:{code:'LOCAL_POLLING_ONLY',message:'The local harness uses polling'}}));
  app.get('/__test/state',async()=>({
    objects:[...objects].map(([key,value])=>({key,bytes:value.bytes.length,mime:value.mime,crc32:crc32(value.bytes)})),storageTrace,apiTrace,events,
    posts:(await db.query('select id,author_id,text,content_kind,created_at from posts order by created_at,id')).rows,
    media:(await db.query('select id,owner_user_id,post_id,mime_type,byte_size,status,width,height,duration_ms from media order by created_at,id')).rows
  }));
  const asset=(file,mime)=>async(req,reply)=>reply.type(mime).send(fs.readFileSync(path.join(root,file)));
  app.get('/',async(req,reply)=>{
    const base=`http://${req.headers.host}`,boot=`<script>localStorage.setItem('pngea:apiBase',${JSON.stringify(base)});localStorage.setItem('pngea:accessToken','local-test-token');</script>`;
    return reply.type('text/html').send(fs.readFileSync(path.join(root,'index.html'),'utf8').replace('<head>','<head>'+boot));
  });
  app.get('/pngea-core.js',asset('pngea-core.js','text/javascript'));app.get('/pngea-v0.40.8-basic-ui-fix.js',asset('pngea-v0.40.8-basic-ui-fix.js','text/javascript'));
  app.get('/pngea-v0.40.9-profile-weixin.js',async(req,reply)=>reply.type('text/javascript').send(fs.existsSync(path.join(root,'pngea-v0.40.9-profile-weixin.js'))?fs.readFileSync(path.join(root,'pngea-v0.40.9-profile-weixin.js')):''));
  app.setErrorHandler((error,req,reply)=>{
    if(error instanceof ZodError)return reply.code(400).send({error:{code:'VALIDATION_ERROR',message:'Invalid request.',details:error.flatten()}});
    return reply.code(error.statusCode||500).send({error:{code:error.code||'INTERNAL_ERROR',message:error.message}});
  });
  await app.listen({port:apiPort,host:'127.0.0.1'});
  const apiBase=`http://127.0.0.1:${app.server.address().port}`;
  return {app,pg,apiBase,storageBase,close:async()=>{await app.close();await new Promise(resolve=>storage.close(resolve));storageApi.objectStorage.destroy();await pg.close()}};
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const setting=name=>{const at=process.argv.indexOf(name);return at<0?0:Number(process.argv[at+1])};
  const harness=await startHarness({apiPort:setting('--api-port'),storagePort:setting('--storage-port')});
  console.log(`PNGEA_HARNESS ${JSON.stringify({apiBase:harness.apiBase,storageBase:harness.storageBase,defaultUser:'usr_self',follower:'usr_viewer'})}`);
  let closing=false;const close=async()=>{if(closing)return;closing=true;await harness.close();process.exit(0)};
  process.once('SIGTERM',close);process.once('SIGINT',close);
}
