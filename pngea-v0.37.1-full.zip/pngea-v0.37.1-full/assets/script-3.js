(() => {
  const api=window.PNGEA;
  if(!api)return;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  // Generic tabs
  document.querySelectorAll('.xTabs').forEach(group => {
    group.querySelectorAll('.xTab').forEach(tab => tab.addEventListener('click', () => {
      const target=tab.dataset.tab;
      group.querySelectorAll('.xTab').forEach(t=>t.classList.toggle('active',t===tab));
      const screen=group.closest('.screen');if(!screen)return;
      screen.querySelectorAll('.xPanel').forEach(p=>p.classList.toggle('active',p.id===target));
    }));
  });

  // Shared follow adapter. Works for static + dynamically-rendered people rows.
  function isFollowing(handle){return api.state.social.following.includes(handle)}
  function syncFollowButton(btn){
    const handle=btn.dataset.handle||btn.dataset.followId;if(!handle)return;
    const on=isFollowing(handle);btn.textContent=on?'Following':'Follow';
    btn.style.background=on?'#151515':'#eee';btn.style.color=on?'#eee':'#080808';btn.style.border=on?'1px solid #333':'0';
  }
  document.querySelectorAll('.peopleRow').forEach((row,i)=>{
    const btn=row.querySelector('.followBtn');if(!btn)return;
    btn.dataset.handle=row.querySelector('small')?.textContent.trim()||`person-${i}`;syncFollowButton(btn);
  });
  document.addEventListener('click',e=>{
    const btn=e.target.closest('.followBtn');if(!btn)return;
    e.stopPropagation();
    const handle=btn.dataset.handle||btn.dataset.followId;if(!handle)return;
    const list=api.state.social.following,idx=list.indexOf(handle);
    if(idx>=0)list.splice(idx,1);else list.push(handle);
    api.save();document.querySelectorAll('.followBtn').forEach(syncFollowButton);api.toast(idx>=0?'Unfollowed':'Following');
  });

  // Messages: routed deep-link state + local persistence.
  const thread=document.getElementById('dmThread');
  const dmTitle=document.getElementById('dmTitle');
  const dmHandle=document.getElementById('dmHandle');
  const dmMessages=document.getElementById('dmMessages');
  const dmInput=document.getElementById('dmInput');
  const names={alex:['Alex Rivera','@alexrivera'],maya:['Maya Kim','@mayak'],crew:['Launch Crew','5 people'],news:['Nia Wells','@niawells']};
  let activeDm=null;
  function renderThread(key){
    activeDm=key;const data=names[key]||['Message',''];dmTitle.textContent=data[0];dmHandle.textContent=data[1];
    dmMessages.innerHTML='<div class="msgDay">TODAY</div>';
    const msgs=api.state.messages[key]||[];
    if(!msgs.length){const empty=document.createElement('div');empty.className='uiState';empty.innerHTML='<div><b>No messages yet</b><small>Start the conversation.</small></div>';dmMessages.appendChild(empty)}
    msgs.forEach(msg=>{const b=document.createElement('div');b.className='msgBubble '+(msg.from==='me'?'me':'them');b.textContent=msg.text;dmMessages.appendChild(b)});
    dmMessages.scrollTop=dmMessages.scrollHeight;
  }
  api.renderThreadRoute=route=>{
    if(route.screen==='Inbox'&&route.detail){renderThread(route.detail);thread.classList.add('show')}
    else thread.classList.remove('show');
  };
  document.querySelectorAll('[data-dm]').forEach(row=>row.addEventListener('click',()=>api.navigate('Inbox',row.dataset.dm)));
  document.getElementById('dmBack').addEventListener('click',()=>api.navigate('Inbox'));
  document.getElementById('dmSend').addEventListener('click',()=>{
    const text=dmInput.value.trim();if(!text||!activeDm)return;
    if(!api.state.messages[activeDm])api.state.messages[activeDm]=[];
    api.state.messages[activeDm].push({from:'me',text,at:Date.now()});api.save();dmInput.value='';renderThread(activeDm);
  });
  dmInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('dmSend').click()}});

  // ---------------- SEARCH ----------------
  const SEARCH_BASE={
    trends:[
      {title:'Transit agreement',category:'Politics · Trending',meta:'611K posts'},
      {title:'Film festival',category:'Film · Trending',meta:'188K posts'},
      {title:'Labor data',category:'Business & finance',meta:'143K posts'},
      {title:'Opening night',category:'Entertainment · Trending',meta:'97K posts'},
      {title:'Design systems',category:'Technology · Trending',meta:'72K posts'}
    ],
    people:[
      {name:'Alex Rivera',handle:'@alexrivera',initials:'AR',bio:'Product design, technology, and cities.'},
      {name:'Maya Kim',handle:'@mayak',initials:'MK',bio:'Film, photography, and culture.'},
      {name:'Nia Wells',handle:'@niawells',initials:'NW',bio:'News and public affairs.'},
      {name:'Amara King',handle:'@amaraking',initials:'AK',bio:'Writing about media and the internet.'},
      {name:'Frame by Frame',handle:'@framebyframe',initials:'FF',bio:'Movies, craft, and visual storytelling.'}
    ],
    posts:[
      {name:'The Dispatch Desk',handle:'@dispatch',text:'Transit workers reach a tentative agreement after an overnight bargaining session.'},
      {name:'Amara King',handle:'@amaraking',text:'The social feed should be infrastructure, not a collection of apps.'},
      {name:'Frame by Frame',handle:'@framebyframe',text:'Why the 1970s newsroom thriller suddenly feels modern again.'},
      {name:'Labor Channel',handle:'@laborchannel',text:'Union members react to the tentative deal live from outside the bargaining hall.'}
    ],
    media:[
      {title:'Why the 1970s newsroom thriller suddenly feels modern again',meta:'Frame by Frame · Video',kind:'VIDEO'},
      {title:'Opening night: first reactions',meta:'Film desk · Short video',kind:'CLIP'},
      {title:'Union members react to the tentative deal',meta:'Labor Channel · Live replay',kind:'LIVE'}
    ]
  };
  const searchInput=document.getElementById('globalSearchInput');
  const searchPill=document.getElementById('searchPill');
  const searchClear=document.getElementById('searchClear');
  const searchRecent=document.getElementById('searchRecent');
  const searchPanels={all:document.getElementById('s-for-you'),trends:document.getElementById('s-trending'),people:document.getElementById('s-people'),media:document.getElementById('s-media')};
  function norm(s){return String(s||'').toLowerCase()}
  function matches(obj,q){return Object.values(obj).some(v=>norm(v).includes(q))}
  function currentPosts(){return [...SEARCH_BASE.posts,...(api.state.posts||[]).map(p=>({name:api.state.user.name,handle:api.state.user.handle,text:p.text||('Shared '+(p.attachment||'a post'))}))]}
  function trendHTML(t){return `<div class="trendRow" data-search-term="${esc(t.title)}"><div class="trendTop">${esc(t.category)}</div><div class="trendTitle">${esc(t.title)}</div><div class="trendMeta">${esc(t.meta)}</div></div>`}
  function personHTML(p){const ph=String(p.handle||'').replace(/^@/,'');return `<div class="peopleRow"><div class="xAvatar" data-profile="${esc(ph)}">${esc(p.initials)}</div><div class="peopleCopy" data-profile="${esc(ph)}"><b>${esc(p.name)}</b><small>${esc(p.handle)}</small>${p.bio?`<div class="trendMeta">${esc(p.bio)}</div>`:''}</div><button class="followBtn" data-handle="${esc(p.handle)}">Follow</button></div>`}
  function postHTML(p){return `<div class="searchResultPost"><div class="srWho"><b>${esc(p.name)}</b><span>${esc(p.handle)}</span></div><div class="srText">${esc(p.text)}</div></div>`}
  function mediaHTML(m){return `<div class="mediaResult"><div class="mediaThumb">${esc(m.kind)}</div><div class="mediaCopy"><b>${esc(m.title)}</b><small>${esc(m.meta)}</small></div></div>`}
  function emptyHTML(q){return `<div class="searchEmpty"><div><b>No results</b><p>Nothing in the local PNGEA prototype matches “${esc(q)}” yet.</p></div></div>`}
  function renderRecent(){
    const h=api.state.search.history||[];
    if(searchInput.value.trim()||!h.length){searchRecent.innerHTML='';searchRecent.style.display='none';return}
    searchRecent.style.display='block';
    searchRecent.innerHTML=`<div class="searchRecentHead"><b>Recent</b><button id="clearSearchHistory">Clear all</button></div>`+h.map(q=>`<div class="recentRow" data-recent-query="${esc(q)}"><span class="recentIcon">◷</span><span class="recentQuery">${esc(q)}</span><button class="recentRemove" data-remove-query="${esc(q)}">×</button></div>`).join('');
  }
  function commitSearch(q){
    q=q.trim();if(!q)return;
    const h=api.state.search.history||[];api.state.search.history=[q,...h.filter(x=>norm(x)!==norm(q))].slice(0,12);api.save();renderRecent();
  }
  function renderSearch(){
    const raw=searchInput.value.trim(),q=norm(raw);searchPill.classList.toggle('hasText',!!raw);renderRecent();
    let trends=SEARCH_BASE.trends,people=SEARCH_BASE.people,posts=currentPosts(),media=SEARCH_BASE.media;
    if(q){trends=trends.filter(x=>matches(x,q));people=people.filter(x=>matches(x,q));posts=posts.filter(x=>matches(x,q));media=media.filter(x=>matches(x,q))}
    const total=trends.length+people.length+posts.length+media.length;
    if(!raw){
      searchPanels.all.innerHTML='<div class="kicker">TRENDING NOW</div>'+trends.slice(0,4).map(trendHTML).join('')+'<div class="kicker">WHO TO FOLLOW</div>'+people.slice(0,3).map(personHTML).join('');
    }else{
      searchPanels.all.innerHTML=total?`<div class="searchCount">${total} LOCAL RESULTS</div>`+trends.slice(0,3).map(trendHTML).join('')+people.slice(0,3).map(personHTML).join('')+posts.slice(0,5).map(postHTML).join('')+media.slice(0,3).map(mediaHTML).join(''):emptyHTML(raw);
    }
    searchPanels.trends.innerHTML=trends.length?trends.map(trendHTML).join(''):emptyHTML(raw||'trends');
    searchPanels.people.innerHTML=people.length?people.map(personHTML).join(''):emptyHTML(raw||'people');
    searchPanels.media.innerHTML=(media.length||posts.length)?media.map(mediaHTML).join('')+posts.slice(0,8).map(postHTML).join(''):emptyHTML(raw||'media');
    document.querySelectorAll('.followBtn').forEach(syncFollowButton);
  }
  if(searchInput){
    searchInput.addEventListener('input',renderSearch);
    searchInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const q=searchInput.value.trim();if(q){commitSearch(q);renderSearch();api.toast(`Search saved: “${q}”`)}}});
    searchClear.addEventListener('click',()=>{searchInput.value='';searchInput.focus();renderSearch()});
    searchRecent.addEventListener('click',e=>{
      const remove=e.target.closest('[data-remove-query]');if(remove){e.stopPropagation();api.state.search.history=(api.state.search.history||[]).filter(q=>q!==remove.dataset.removeQuery);api.save();renderRecent();return}
      if(e.target.id==='clearSearchHistory'){api.state.search.history=[];api.save();renderRecent();return}
      const row=e.target.closest('[data-recent-query]');if(row){searchInput.value=row.dataset.recentQuery;commitSearch(searchInput.value);renderSearch();searchInput.focus()}
    });
    document.getElementById('Search').addEventListener('click',e=>{const row=e.target.closest('[data-search-term]');if(row){searchInput.value=row.dataset.searchTerm;commitSearch(searchInput.value);renderSearch();searchInput.focus()}});
    renderSearch();
  }

  // ---------------- SETTINGS ----------------
  const detail=document.getElementById('settingsDetail'),detailTitle=document.getElementById('settingsDetailTitle'),detailBody=document.getElementById('settingsDetailBody');
  const PAGE_TITLES={account:'Account information',security:'Security and access',privacy:'Privacy and safety',display:'Display and accessibility',notifications:'Notifications',feed:'Feed preferences',help:'Help center',about:'About PNGEA'};
  function toggleRow(key,title,desc){const on=!!api.state.settings[key];return `<div class="prefRow"><div class="prefCopy"><b>${esc(title)}</b><small>${esc(desc)}</small></div><div class="toggle ${on?'on':''}" data-setting-toggle="${esc(key)}" role="switch" aria-checked="${on}"></div></div>`}
  function choiceRow(key,title,choices){const current=api.state.settings[key];return `<div class="choiceRow"><b>${esc(title)}</b><div class="choiceSet">${choices.map(([v,l])=>`<button class="choice ${current===v?'active':''}" data-setting-choice="${esc(key)}" data-value="${esc(v)}">${esc(l)}</button>`).join('')}</div></div>`}
  function pageMarkup(page){
    const s=api.state.settings;
    if(page==='account') return `<div class="settingsIntro"><b>Your identity</b><p>These values update locally now and are ready to map to the account service later.</p></div><div class="settingsField"><label>DISPLAY NAME</label><input id="accountName" value="${esc(api.state.user.name)}" maxlength="50"></div><div class="settingsField"><label>HANDLE</label><input id="accountHandle" value="${esc(api.state.user.handle)}" maxlength="30"></div><button class="settingsSave" id="saveAccount">Save changes</button>`;
    if(page==='security') return `<div class="settingsIntro"><b>Security</b><p>The UI contract is in place. Password, passkeys, sessions, and two-factor authentication will connect when authentication is added.</p></div><div class="staticSetting"><b>Password</b><small>Account backend not connected yet.</small></div><div class="staticSetting"><b>Passkeys</b><small>Ready for backend implementation.</small></div><div class="staticSetting"><b>Active sessions</b><small>This device only in the prototype.</small></div>`;
    if(page==='privacy') return `<div class="settingsIntro"><b>Control your presence</b><p>Preferences persist locally now; network enforcement comes with the account backend.</p></div>${toggleRow('privateAccount','Private account','Only approved followers can see protected posts.')}${toggleRow('readReceipts','Read receipts','Let people know when you have read their messages.')}${toggleRow('discoverability','Discoverability','Allow your account to appear in people recommendations.')}`;
    if(page==='display') return `<div class="settingsIntro"><b>Make PNGEA comfortable</b><p>These preferences take effect immediately on this device.</p></div>${toggleRow('reducedMotion','Reduce motion','Minimize nonessential interface animation.')}${toggleRow('compactUI','Compact interface','Tighten conventional social screens without changing PNGEA core navigation.')}`;
    if(page==='notifications') return `<div class="settingsIntro"><b>Notifications</b><p>Choose what the prototype considers notification-worthy.</p></div>${toggleRow('notifications','Allow notifications','Master notification preference.')}${toggleRow('messageNotifications','Messages','Direct messages and conversation activity.')}${toggleRow('mentionNotifications','Mentions and replies','Activity involving your account.')}${toggleRow('followNotifications','New followers','Notify when someone follows you.')}`;
    if(page==='feed') return `<div class="settingsIntro"><b>The Stream</b><p>Set default feed behavior without changing the one-stream PNGEA concept.</p></div>${toggleRow('autoplay','Autoplay video','Automatically begin muted video playback in the feed.')}${toggleRow('personalizedFeed','Personalized ranking','Use relevance signals when ordering the stream.')}${choiceRow('feedMode','Default ordering',[['balanced','Balanced'],['latest','Latest'],['following','Following first']])}`;
    if(page==='help') return `<div class="settingsIntro"><b>Help center</b><p>Baseline support surfaces are ready for real documentation and reporting flows.</p></div><div class="staticSetting"><b>Using PNGEA</b><small>Navigation, posting, messages, communities, and media.</small></div><div class="staticSetting"><b>Safety and reporting</b><small>Reporting and moderation flows will plug in here.</small></div><div class="staticSetting"><b>Contact support</b><small>Support backend not connected yet.</small></div>`;
    if(page==='about') return `<div class="aboutMark">PNGEA</div><div class="aboutCopy">One stream for conversation, media, live events, communities, and everything around them.<br><br>Prototype foundation v0.36.</div>`;
    return '';
  }
  function applyDisplayPrefs(){document.body.classList.toggle('reduceMotion',!!api.state.settings.reducedMotion);document.body.classList.toggle('compactUI',!!api.state.settings.compactUI)}
  function refreshIdentity(){
    document.querySelectorAll('.sideName').forEach(x=>x.textContent=api.state.user.name);document.querySelectorAll('.sideHandle').forEach(x=>x.textContent=api.state.user.handle);
    document.querySelectorAll('#Profile .profileName').forEach(x=>x.textContent=api.state.user.name);document.querySelectorAll('#Profile .profileHandle').forEach(x=>x.textContent=api.state.user.handle);
    const top=document.querySelector('#Profile .xTopTitle b');if(top)top.textContent=api.state.user.name;
    document.querySelectorAll('#Profile .xPostWho b').forEach(x=>x.textContent=api.state.user.name);document.querySelectorAll('#Profile .xPostWho span').forEach(x=>x.textContent=x.textContent.replace(/^@you/,api.state.user.handle));
  }
  function renderSettingsPage(page){
    detailTitle.textContent=PAGE_TITLES[page]||'Settings';detailBody.innerHTML=pageMarkup(page);detail.classList.add('show');
  }
  api.renderSettingsRoute=route=>{if(route.screen==='Settings'&&route.detail){renderSettingsPage(route.detail)}else detail.classList.remove('show')};
  document.querySelectorAll('[data-setting-page]').forEach(row=>row.addEventListener('click',()=>api.navigate('Settings',row.dataset.settingPage)));
  document.getElementById('settingsBack').addEventListener('click',()=>api.navigate('Settings'));
  detailBody.addEventListener('click',e=>{
    const t=e.target.closest('[data-setting-toggle]');
    if(t){const key=t.dataset.settingToggle;api.state.settings[key]=!api.state.settings[key];api.save();applyDisplayPrefs();renderSettingsPage(api.parseRoute().detail);api.toast(api.state.settings[key]?'On':'Off');return}
    const c=e.target.closest('[data-setting-choice]');
    if(c){api.state.settings[c.dataset.settingChoice]=c.dataset.value;api.save();renderSettingsPage(api.parseRoute().detail);api.toast('Preference saved');return}
    if(e.target.id==='saveAccount'){
      const name=document.getElementById('accountName').value.trim()||'You';let handle=document.getElementById('accountHandle').value.trim()||'@you';if(!handle.startsWith('@'))handle='@'+handle;handle='@'+handle.slice(1).replace(/[^a-zA-Z0-9_]/g,'').slice(0,29);
      api.state.user.name=name;api.state.user.handle=handle||'@you';api.save();refreshIdentity();api.toast('Account updated');renderSettingsPage('account');
    }
  });
  applyDisplayPrefs();refreshIdentity();

  // Re-apply current route after feature hooks exist.
  const r=api.parseRoute();api.renderThreadRoute(r);api.renderSettingsRoute(r);
})();
