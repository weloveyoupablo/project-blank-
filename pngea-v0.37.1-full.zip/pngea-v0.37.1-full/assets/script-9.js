/* PNGEA v0.37 — NOW dispenser + universal identity routing */
(() => {
  const ui=window.PNGEA;if(!ui)return;
  const $=(s,r=document)=>r.querySelector(s);
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const you=$('#youButton'),dock=$('#pnNowDock'),dockText=$('#pnNowDockText'),profile=$('#Profile');
  let retractTimer=null,lastNowText='';

  const currentHandle=()=>String(window.PNGEA_LIVE?.state?.me?.handle||ui.state.user?.handle||'you').replace(/^@/,'').toLowerCase();
  const normalize=h=>String(h||'').trim().replace(/^@/,'').toLowerCase();
  const initials=name=>String(name||'?').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase();

  function openSidebar(){
    $('#sidebar')?.classList.add('show');
    $('#sidebarShade')?.classList.add('show');
  }
  function closeSidebar(){
    $('#sidebar')?.classList.remove('show');
    $('#sidebarShade')?.classList.remove('show');
  }

  // The persistent top-left avatar is the menu handle. Once the drawer is open,
  // its identity header (avatar/name/handle) routes to your Profile like every other identity.
  // script-1 owns the #youButton click -> sidebar behavior; do not intercept it here.
  let edgeStart=null;
  document.addEventListener('touchstart',e=>{const x=e.touches?.[0]?.clientX;if(Number.isFinite(x)&&x<18)edgeStart=x},{passive:true});
  document.addEventListener('touchend',e=>{if(edgeStart===null)return;const x=e.changedTouches?.[0]?.clientX||0;if(x-edgeStart>64)openSidebar();edgeStart=null},{passive:true});

  function startNowRollout(){
    if(!dock||!you||!dock.classList.contains('show'))return;
    clearTimeout(retractTimer);
    you.classList.remove('hasNowAlert');
    you.classList.add('nowDispensing');
    dock.classList.remove('retracted');
    // force a collapsed frame so repeated events visibly dispense again
    dock.classList.remove('rollout');
    requestAnimationFrame(()=>requestAnimationFrame(()=>dock.classList.add('rollout')));
    retractTimer=setTimeout(()=>{
      dock.classList.remove('rollout');dock.classList.add('retracted');
      you.classList.remove('nowDispensing');you.classList.add('hasNowAlert');
    },5000);
  }
  function clearNowAlert(){you?.classList.remove('hasNowAlert')}
  dock?.addEventListener('click',clearNowAlert,true);
  const observeNow=()=>{
    if(!dock)return;
    const t=(dockText?.textContent||'').trim();
    if(!dock.classList.contains('show')){clearTimeout(retractTimer);dock.classList.remove('rollout','retracted');you?.classList.remove('nowDispensing','hasNowAlert');lastNowText='';return}
    if(t!==lastNowText||(!dock.classList.contains('rollout')&&!dock.classList.contains('retracted'))){
      lastNowText=t;startNowRollout();
    }
  };
  new MutationObserver(observeNow).observe(dock||document.body,{attributes:true,attributeFilter:['class'],subtree:false});
  if(dockText)new MutationObserver(observeNow).observe(dockText,{characterData:true,childList:true,subtree:true});
  observeNow();

  const DEMO={
    you:{name:'You',bio:'Building PNGEA. Media, ideas, film, politics, and whatever else is worth putting into the world.',followers:1842,following:241,meta:['◎ Columbus, OH','⌁ pngea.app','◷ Joined 2026']},
    dispatch:{name:'The Dispatch Desk',bio:'Breaking news, reporting, and live dispatches from the PNGEA newsroom.',followers:611000,following:328,meta:['◎ Newsroom','◷ Joined 2026']},
    mayachen:{name:'Maya Chen',bio:'Technology, networks, culture, and the politics of how software shapes people.',followers:128400,following:611,meta:['◎ San Francisco','◷ Joined 2026']},
    arilewis:{name:'Ari Lewis',bio:'Photography, cities, weather, and whatever the light is doing.',followers:42300,following:729,meta:['◎ Columbus, OH','◷ Joined 2026']},
    jules:{name:'Jules Rivera',bio:'Labor reporter. Video from the street, the meeting room, and everywhere in between.',followers:97300,following:540,meta:['◎ New York','◷ Joined 2026']},
    framebyframe:{name:'Frame by Frame',bio:'Film criticism, visual language, production design, and long-form video.',followers:1900000,following:214,meta:['⌁ framebyframe.media','◷ Joined 2026']},
    laborchannel:{name:'Labor Channel',bio:'Live labor coverage, union news, bargaining updates, and worker voices.',followers:804000,following:402,meta:['● Live often','◷ Joined 2026']},
    amaraking:{name:'Amara King',bio:'Essays on media, technology, cities, and public life.',followers:287000,following:389,meta:['◷ Joined 2026']},
    mina:{name:'Mina',bio:'Film, design, and comments that somehow become essays.',followers:9600,following:488,meta:['◷ Joined 2026']},
    ruben:{name:'Ruben',bio:'Movies, interfaces, and making the internet feel human again.',followers:4200,following:615,meta:['◷ Joined 2026']}
  };

  function profileHandleFrom(el){
    const explicit=el.closest('[data-profile]')?.dataset.profile;if(explicit)return normalize(explicit);
    const row=el.closest('.authorRow,.xPost,.creatorLine,.byline,.longMeta');
    const text=row?.querySelector('.meta,.xPostWho span,.creatorText small,.videoMeta')?.textContent||row?.textContent||'';
    const m=text.match(/@([a-zA-Z0-9_]+)/);return m?normalize(m[1]):'';
  }
  document.addEventListener('click',e=>{
    const target=e.target.closest('.authorRow .avatar,.authorRow .authorCopy,.xPost .xAvatar,.xPostWho,.creatorLine .avatar,.creatorText,.byline .avatar,.byline>div,.longMeta .avatar,.longMeta>div:nth-child(2),.dmRow .xAvatar,.notifText [data-profile],[data-profile]');
    if(!target||target.closest('#youButton'))return;
    const h=profileHandleFrom(target);if(!h)return;
    e.preventDefault();e.stopImmediatePropagation();ui.navigate('Profile',h);
  },true);

  function setProfileChrome(p,{self=false,loading=false}={}){
    if(!profile)return;
    profile.classList.toggle('profileRouteLoading',loading);
    const name=p.name||p.display_name||p.handle||'Profile',handle=normalize(p.handle||p.routeHandle||'');
    $('#Profile .xTopTitle b') && ($('#Profile .xTopTitle b').textContent=name);
    $('#Profile .xTopTitle small') && ($('#Profile .xTopTitle small').textContent=p.postLabel||'Profile');
    $('#Profile .profileName') && ($('#Profile .profileName').textContent=name);
    $('#Profile .profileHandle') && ($('#Profile .profileHandle').textContent='@'+handle);
    $('#Profile .profileBio') && ($('#Profile .profileBio').textContent=p.bio||'');
    const av=$('#Profile .xAvatar.big');if(av)av.textContent=initials(name);
    const meta=$('#Profile .profileMeta');if(meta)meta.innerHTML=(p.meta||[]).map(x=>`<span>${esc(x)}</span>`).join('');
    const stats=$('#Profile .profileStats');if(stats)stats.innerHTML=`<span><b>${Number(p.following||0).toLocaleString()}</b>Following</span><span><b>${Number(p.followers||0).toLocaleString()}</b>Followers</span>`;
    const action=$('#Profile .profileEdit');if(action){action.dataset.profileAction=self?'edit':'follow';action.dataset.userId=p.id||'';action.dataset.viewerFollowing=p.viewer_following?'1':'0';action.textContent=self?'Edit profile':(p.viewer_following?'Following':'Follow');action.classList.toggle('following',!!p.viewer_following)}
  }
  function demoProfile(handle){
    const h=normalize(handle)||'you',p=DEMO[h]||{name:'@'+h,bio:'PNGEA profile',followers:0,following:0,meta:['◷ PNGEA']};
    setProfileChrome({...p,handle:h,routeHandle:h,postLabel:h==='you'?'1,842 posts':'Profile'},{self:h===currentHandle()||h==='you'});
    const posts=$('#p-posts'),replies=$('#p-replies'),media=$('#p-media'),likes=$('#p-likes');
    if(h==='you'){
      posts.innerHTML='<div class="xPost"><div class="xAvatar" data-profile="you">YOU</div><div class="xPostBody"><div class="xPostWho" data-profile="you"><b>You</b><span>@you · 12m</span></div><div class="xPostText">The feed should feel like one continuous public square, not six apps stapled together.</div><div class="xPostActions"><span>◯ 18</span><span>⇄ 41</span><span>♡ 291</span><span>↗</span></div></div></div><div class="xPost"><div class="xAvatar" data-profile="you">YOU</div><div class="xPostBody"><div class="xPostWho" data-profile="you"><b>You</b><span>@you · 4h</span></div><div class="xPostText">Testing a different visual language for messages.</div><div class="xPostMedia">PNGEA</div><div class="xPostActions"><span>◯ 32</span><span>⇄ 66</span><span>♡ 517</span><span>↗</span></div></div></div>';
    } else if(posts){posts.innerHTML=`<div class="placeholder"><div><h2>${esc(p.name)}</h2><p>Demo profile. Live posts populate here from the network backend.</p></div></div>`}
    if(replies)replies.innerHTML='<div class="placeholder"><div><h2>Replies</h2><p>Replies populate here.</p></div></div>';
    if(media)media.innerHTML='<div class="placeholder"><div><h2>Media</h2><p>Photos and video from this account.</p></div></div>';
    if(likes)likes.innerHTML=h==='you'?'<div class="placeholder"><div><h2>Likes</h2><p>Posts you have liked.</p></div></div>':'<div class="placeholder"><div><h2>Likes are private</h2><p>This account’s likes are not shown here.</p></div></div>';
  }
  function renderProfileRoute(){
    const r=ui.parseRoute();if(r.screen!=='Profile')return;
    const h=normalize(r.detail)||currentHandle();
    if(window.PNGEA_LIVE?.state?.active){window.PNGEA_LIVE.loadProfile?.(h);return}
    demoProfile(h);
  }
  window.addEventListener('hashchange',renderProfileRoute);
  window.addEventListener('popstate',renderProfileRoute);
  renderProfileRoute();

  // Non-self Profile action becomes follow/unfollow. Self retains the existing edit-profile layer.
  document.addEventListener('click',async e=>{
    const action=e.target.closest('#Profile .profileEdit');if(!action||action.dataset.profileAction!=='follow')return;
    e.preventDefault();e.stopImmediatePropagation();
    if(!window.PNGEA_LIVE?.state?.active){action.classList.toggle('following');action.textContent=action.classList.contains('following')?'Following':'Follow';return}
    const api=window.PNGEA_API,id=action.dataset.userId;if(!api||!id)return;
    try{const following=action.dataset.viewerFollowing==='1';await (following?api.unfollow(id):api.follow(id));action.dataset.viewerFollowing=following?'0':'1';action.classList.toggle('following',!following);action.textContent=following?'Follow':'Following'}catch(err){ui.toast(err.message||'Could not update follow')}
  },true);

  // On your own profile, the top-right menu remains the fast path to the global drawer.
  document.addEventListener('click',e=>{
    const x=e.target.closest('#Profile .xTop>.xAction');if(!x)return;
    const r=ui.parseRoute(),h=normalize(r.detail)||currentHandle();if(h!==currentHandle()&&h!=='you')return;
    e.preventDefault();e.stopImmediatePropagation();openSidebar();
  },true);
})();
