# PNGEA backend companion for frontend 0.51.3

Changes:
- GET /v1/posts/:id/replies for real post-detail reply threads.
- Keeps reaction counts/viewer state/media on replies.
- Ticker reads up to 18 hours of current news and can return up to 20 items.
- Benzinga news is filtered from ingestion and ticker output.
- Adds a server-side RSS news adapter. Default direct source: Al Jazeera.
- NEWS_RSS_FEEDS supports additional permitted/licensed RSS sources.
- Existing Alpaca stock quote stream remains in place for major-market prices.
- Existing auth/profile/media hotfixes remain included.

No database migration is required for this patch.
