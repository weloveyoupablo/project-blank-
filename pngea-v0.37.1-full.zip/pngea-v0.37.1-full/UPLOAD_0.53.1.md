# PNGEA 0.53.1 recovery and reels

Replace these four files in the existing repository root:

1. index.html
2. pngea-core.js
3. pngea-v0.40.8-basic-ui-fix.js
4. pngea-v0.37.1-full.zip — keep this archive intact.

Deploy the uploaded backend ZIP on the existing Render Free service using its current build/start commands. No new migration or paid service is needed. The live service already has AWS_REQUEST_CHECKSUM_CALCULATION=WHEN_REQUIRED applied; this archive also sets the corresponding client option so future deployments keep the video upload fix.

Expected frontend build: 0.53.1-recovery-reels.
Expected backend health version: 0.53.1.
Open https://weloveyoupablo.github.io/project-blank-/?v=5311 after publication.

Videos are verified through the real app upload path rather than a mocked successful post: file selection, signed PUT, stored-byte verification, actual post creation, canonical follower feed, reel playback and seeking. An approved followers-only production upload also saved and played in the published app; the candidate frontend expanded and sought that real production video successfully. Test posts and media were deleted afterward. Home still contains only followed authors; after publishing, the author sees the saved post directly.

This release also fixes sender-side chat photos, attachment-only Inbox previews and timestamps, Safari session restoration/cold-start retries, global signed-out access, self-profile Share/Edit buttons and following-only profile sharing. Time reminders now scroll within the ticker instead of occupying a permanent side panel.

Short videos use a bounded 9:16 reel with author overlay. Fullscreen adds author/caption, a seek bar, playback/sound controls, and Like/Comment/Repost/Send/Save down the right. Long videos retain their landscape player.

Safari restores the session on return, retries transient connection failures without erasing saved credentials, and checks for newer frontend releases. Unsent editing sessions defer an update reload to preserve content. Render Free cold starts can still delay the server; the app shows a reconnecting screen rather than an inactive feed.

Rollback restores the prior four files. Keep the checksum environment setting and existing additive database migrations.
