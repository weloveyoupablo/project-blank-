# PNGEA 0.53.0 social and messaging release

Built from the inspected live 0.52.2 frontend, the existing backend archive and repository. The Render Free service, storage and archive extraction contract remain in place. Verification uses isolated fixtures and PostgreSQL; it creates no production accounts, posts or messages.

## Chat

The existing single visual-viewport controller owns the header, scrollable message list, attachment row and composer. The composer meets the keyboard without lifting the main navigation or letting gestures drag the document. Message scroll position and the latest-message anchor survive keyboard transitions. Read receipts remain limited to the latest outgoing message.

Shared post and profile URLs render compact previews from authenticated canonical APIs; inaccessible content stays unavailable. Post and profile Back restore the originating chat, draft and scroll, including the nested chat → post → author profile path. Arbitrary external links do not trigger metadata fetches.

Typing has a six-second database lease, throttled heartbeats and realtime updates. It stops on send, blur, exit or expiry. New mutual-follow conversations open directly. Other new conversations offer Request/Close, then show a waiting state; recipients receive one notification and Accept/Decline controls. Disabled message-request preferences are respected. Historical conversations remain accepted.

Idempotent sends, automatic transient retries and the existing durable outbox remain in the consolidated messaging implementation. Pending requests cannot send messages, receipts, typing events or attachments. Reciprocal blocks hide conversations and prevent historical blocked group senders leaking through message previews, history, unread counts or media access.

## Posts, drafts and media

Photo/video captions can be edited by their author at any age through the same three-dot menu on Home and post detail. Text bubbles, text-first image attachments, replies, audio and long-form posts cannot be edited. Delete remains owner-only and available in both contexts.

Leaving an unsent composer offers Save draft, Discard and Keep editing. Draft writes must complete before the composer closes; storage failure preserves the unsent post. The draft icon reflects saved content, drafts restore audience/media edits, successful publication removes the posted draft, and a failed publication preserves it. Existing immutable upload snapshots protect a new draft from an older in-flight upload.

A real uploaded object's byte count must match before completion. Verified originals become ready immediately, so publication does not depend on the inspection worker. Completion retries publish once and queue once. Inspection can read actual file metadata with optional ffprobe, or retain bounded browser-provided metadata. Restarted workers reclaim expired leases; retries are bounded at five. Optional inspection failure cannot invalidate an already-ready original.

Short videos below 90 seconds retain the 9:16 reel presentation, autoplay and fullscreen seek controls; longer videos use the long-video format. Media captions stay below the video in detail as well as Home. Playback uses the original codec; this Free release does not add mandatory transcoding.

Photo comment actions open a compact bottom sheet over the current timeline without navigating. The background is inert; the sheet expands, collapses and closes through its handle. Nested replies stay collapsed until requested and new replies target the selected comment. The sheet uses the same keyboard controller as full post detail.

## Profiles, privacy and stable rendering

Follow and Message appear below profile counts. The original control area contains account-notification and internal-share icons. Notification modes are None, All posts and All posts and replies. Delivery requires following, respects audiences/blocks and avoids duplicate reply/mention notifications. Profile menus support external Share, Mute and Block. Muting hides that author from Home without removing the follow; blocking prevents reciprocal discovery, messaging and interaction.

Connection lists include independent Follow buttons. Close Friends uses smaller horizontal chips; tapping a chip opens Remove/Close. Avatar and banner editors apply real pan/zoom crops to uploaded files, with Save and Back.

Feed/profile/Close Friends rendering reuses unchanged post and media nodes. Reaction updates preserve icon nodes. Reserved grey media slots hold the final aspect ratio and bounded height while access URLs and bytes load. Banner artwork is decoded before replacement and keyed to avoid repainting an unchanged image. Network delays and Free cold starts still exist; placeholders keep those delays from rearranging the page.

## Ticker

The approved agencies are Al Jazeera English, CNN, MSNBC, AP, Bloomberg and Reuters. Defaults remain enabled even when an older deployment specifies only Al Jazeera. Official RSS feeds are preferred; Google News publisher feeds are fallbacks and must match both the approved agency name and publisher host. Stories older than 24 hours are excluded and feeds refresh every two hours. An unavailable feed is omitted, with no invented headlines.

Ticker selection interleaves real news, eligible notifications and market quotes. Real large-cap/index quotes mix with available daily movers; missing prices are never fabricated. Animation progress and unchanged ticker nodes survive navigation and refreshes. A stationary clock starts Eastern and rotates through six US IANA zones, observing daylight-saving time. It advances using a monotonic clock and synchronizes to backend time when available; it is not an external paid clock service.

## Validation and deployment

Baseline tests ran before changes. Release checks cover browser behavior, real MP4 upload/probe/storage flow, migrations 001–009, post-format persistence, following feeds, caption permissions, social privacy, notifications, message requests, typing and retry behavior. Device keyboard geometry is simulated in Chromium; no physical iPhone keyboard was operated.

Upload instructions are in UPLOAD_0.53.0.md. Both frontend and backend must be deployed together. The frontend build is 0.53.0-social-messaging and backend health version is 0.53.0. The companion archive retains its exact pngea-v0.37.1-full.zip filename and root directory. Rollback restores the previous files; additive schema objects can remain.
