# PNGEA 0.51.9 posting experience

Based on the inspected 0.51.8 frontend and companion backend, retaining the existing Render free-tier service and extraction contract. No production user messages, posts, or account data were created during verification.

## Navigation and actions

The live action box now links to Dating instead of Messages. Delegated back navigation handles replaced headers on Communities, Close Friends, History, Dating, and other sidebar screens. Create Community is on the plus button beside community search. Post menus offer Send post, Save, and Delete post for the author. The backend still enforces author ownership for deletion. Post share icons open a PNGEA recipient picker, using current conversations or people search; they do not open native phone sharing. Sent posts appear as an internal post link in messages. Private post visibility is checked when the recipient opens the post.

The self-profile alias `you` resolves to the signed-in user. Canonical post counts exclude replies and soft-deleted posts. Other-user counts respect post visibility. When the new backend count is absent, the frontend uses loaded original posts as a compatibility fallback, limited by the existing list page size.

## One post renderer and comment view

Home, profile posts, History library, Communities, and Close Friends share the same post-card renderer and media hydration. Photo frames use a shared 4:5 container, contain-fit to preserve the whole photo, and a 430px maximum height. Profile media-grid thumbnails remain thumbnails.

- Text-first posts show text above attached media inside a bubble.
- Gallery posts show media without the outer bubble border, with captions below it. The Home gallery button opens the system photo/video picker; an empty composer's Gallery button uses the gallery style too. Typing first and then attaching media preserves the text-post style.
- Videos shorter than 90 seconds use a 9:16 reel layout, muted inline autoplay when visible, author overlay with a gradient, and fullscreen expansion with native seek controls. Browser autoplay restrictions still apply.
- Videos at least 90 seconds use a 16:9 player with playback controls and caption below.
- Long-form posts have a title and body editor without bottom attachment icons or a UI word limit. Titles are capped at 300 characters; the API retains its existing 2 MB request-body limit. Timeline cards show the title and a smaller author header, loading the full body only when opened.

Existing photos cannot be retrospectively classified by their original posting source; they retain the text style. Existing videos with duration metadata can use the new duration-based layout. New source/title fields persist through migration 007 and are included in all relevant feed/list endpoints. Long-form text is omitted from list responses and returned by the post-detail endpoint.

All post bodies/photo taps open the shared post/comment view. Video taps expand the media player. The old separate reply composer was removed. Replies have smaller avatars, text, and spacing while keeping the common dividers and action layout.

## Keyboard and badges

Reply and message composers follow the visual viewport boundary while headers remain in place. Scrollable content is constrained to the visible space and recent content sits immediately above the composer; the empty spacer under short threads is removed. Reply attachment tools hide while the keyboard is open. Unread badges are anchored to the icon corners. Composer icons are explicit 24px outline gallery, camera, microphone, and paragraph glyphs. The old capture hint and fourth-icon hiding rule were removed.

## Verification

Baseline tests ran before implementation. Validation includes 45 isolated Chromium browser regressions, existing backend unit tests, JavaScript syntax checks, archive integrity, and an embedded PostgreSQL integration check using PGlite with pgcrypto. The SQL check applies migrations 001–007, reruns the additive migration, and exercises format/title persistence, long-form validation, feed/library SQL, profile counts, and author-only deletion. Browser fixtures include a real two-second video to verify reel playback. Fixtures are test-only and do not populate the product.

Physical Safari/iOS and Android keyboard/picker behavior still require device verification. PostgreSQL checks use an isolated embedded engine, not the production database or an authenticated production end-to-end session. Gallery UI is the operating system's picker; a web page cannot force a particular Photos album.

## Deployment

Upload index.html, pngea-core.js, and pngea-v0.37.1-full.zip to the existing repository root. Deploy the latest commit on the current Render service. The archive name and internal pngea-v0.37.1-full root intentionally remain unchanged so the existing build/start commands work. Migration 007 runs through the existing start command. Confirm frontend build 0.51.9-posting-experience and migration 007 success before accepting the release. Keep the instance on Free.

Rollback requires the prior frontend files and archive. The additive columns can remain in the database; do not drop them or rerun older data-repair migrations.
