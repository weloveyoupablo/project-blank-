# PNGEA 0.53.2 compose and sports release

Built from the inspected live 0.53.1 frontend and its matching backend archive. The existing Render Free service, object storage and exact archive extraction contract remain. The release adds no paid service or mandatory video transcoder.

## Replies and posting

Timeline and detail reply actions on word/image bubbles use one shared full-page composer. It shows the canonical original post, a small attached-photo preview, thread line, self avatar and replying-to handle. Its text canvas and attachment row use the existing viewport controller. Photo comments retain their timeline sheet, while voice-only posts retain their waveform and inline reply view.

Text posts and replies have a consistent 280 Unicode code-point limit on the client and server. The filling ring stays white without a number, shows an amber 20–1 countdown, and turns red at zero with negative overflow counts. Overflow text is highlighted and publishing is blocked above the limit. Everyone/Followers selection persists in drafts and the actual post request. Gallery captions and long-form bodies remain exempt from the 280-character rule; historical longer posts remain readable.

Back returns through gallery review, selection and the base composer, or from long form to the base composer, without discarding text/media edits. Leaving the base composer uses the existing Save draft/Discard/Keep editing decision. Reply avatar navigation uses that same decision before opening a profile. Drafts use one account-scoped store with atomic legacy migration. Session expiry saves an unsent post for its captured account and immediately releases the reply keyboard frame for sign-in.

## Media, Saved and profiles

All video formats reserve bounded space using original dimensions; intrinsic metadata corrects missing dimensions after loading. Fullscreen contains the complete frame with black remaining space. Reel author/caption overlays, seek controls and five social actions remain. Video editing retains trim/mute and no longer offers an aspect control that would conflict with original proportions.

Saved displays a square gallery across photo, video, word, long-form and voice posts. Text tiles show a text preview; their attached images are fetched after opening the complete post. Other History tabs keep their existing layouts.

Migration 010 persists location and website. Canonical profile data supplies the optional location pill, safe blue website link and real account joined month/year. Share profile uses a plain label. Follow responses and realtime events return current counts for both affected accounts; profile and sidebar apply the same snapshots.

## Startup and refresh

A single connection screen owns startup and Retry. Retry aborts the pending attempt and starts a new one, including when a response body or refresh is stalled. Authentication gates the app, then secondary data loads in the background. Core JavaScript preloads earlier. Active sessions retain their interface during a transient reconnect rather than returning to a full startup screen.

The API has one generation-aware owner for tokens, refresh flights, account switching and full-response deadlines. Late responses cannot restore a logged-out account or sign out a newly selected one. Live data reads and WebSocket tickets also check session ownership before applying results. Signed-out users see sign-in, with private overlays hidden.

Home has an accessible Refresh button and a contained pull-to-refresh gesture at the top of its own scroller. Refresh reuses the canonical following feed, preserves existing posts on failure and does not reload the browser.

## Chat heads and actions

Inbox long-press uses one existing action sheet with Open chat/Create chathead. An in-app floating avatar head shows unread badges and opens a mini view of the same DM node, input, message state and send/outbox pipeline. It supports dragging, minimizing, removal and return navigation through shared posts/profiles. Account changes and removed/blocked conversations clear heads.

The existing four intelligence actions now target actual messages when long-pressed inside chat. Touch/native context events cannot open duplicate sheets. Existing post, community and other object actions remain.

## Ticker

Approved news adds NBC News, MS NOW and NPR to Al Jazeera English, CNN, MSNBC, AP, Bloomberg and Reuters. Sports adds ESPN, The Athletic, Sports Illustrated, Fox Sports, CBS Sports, Bleacher Report, Yahoo Sports and official NFL, NCAA football/basketball, NBA, NHL and MLB publishers. Headlines refresh every two hours. Strict publisher URL checks and worker-side cached resolution keep redirect work out of taps.

Migration 011 stores real ESPN scoreboards for seven competitions, including men's/women's NCAA basketball. Polling is bounded and runs each minute; stale live scores, cancelled games and unavailable data are omitted. Scheduled games do not invent zero scores. The ticker gives markets a smaller allocation and retains news/sports, notifications and scrolling US clock reminders. Stock rows omit "last known"; outbound article/quote items use native HTTPS anchors.

## Verification and deployment

Baseline tests passed before edits. Final validation covers 207 unique browser cases, all 80 backend tests, migrations 001–011 and the actual browser upload/S3 signing/storage/PostgreSQL path. See RELEASE_0.53.2_CHECKS.md for the exact full-run and targeted rerun results. Mobile viewport/gesture tests cannot operate a physical iPhone keyboard.

The candidate is not deployed by creating this package. Upload instructions are in UPLOAD_0.53.2.md. Frontend build is 0.53.2-compose-sports, backend health is 0.53.2 and asset keys are 5321. Keep pngea-v0.37.1-full.zip and its pngea-v0.37.1-full directory intact. Rollback restores the prior four files; additive migrations can remain.
