# PNGEA 0.51.7 reliability candidate

Inspected baseline: `weloveyoupablo/project-blank-`, main commit
`4156b6483f21f9ea2a62eafcdf547a8aeffc9633`, frontend
`0.51.6-core-reliability`. The recursive tree contains 22 files: active shell,
historical HTML and patch scripts, PWA assets, recovery page, and backend ZIP.
All entries were inventoried; executable sources, historical build structure,
and loaded dependencies were inspected. No AGENTS.md is present in that tree.

The supplied `pngea-v0.37.1-full.zip` contains 78 entries, including 68 files.
Its SHA-256 is
`5bf42d23cd52e2f1183195bc418150ed14c557c268ca4811c6841119088b8eee`.
Its Git blob SHA is `078c1a4e8e7b65c02043726ae7b6a58154a3f9fb`, matching the
repository archive. Its bundled frontend is older than the active repo frontend;
the candidate uses the active repo frontend as its starting point.

## Live deployment evidence

Render workspace: My Workspace (`tea-db3ena6i0phs739s7o0g`), confirmed by the owner.
Production service: `pngea-api-production` (`srv-db3fh8tg1s2s73a88rpg`).
Latest observed deployment: `dep-db76pbom7kps73c7hs0g`, status `live`, commit
`4156b6483f21f9ea2a62eafcdf547a8aeffc9633`. The configured build extracts
`pngea-v0.37.1-full.zip`; start runs migrations and then the API.
Main-branch automatic deploy is enabled, so the candidate must remain on a review
branch until release. No Render deployment, settings, or production data was changed.

Creating a review branch through the GitHub connector was rejected with HTTP 403
(`Resource not accessible by integration`). No draft PR could be opened; source
and a Git patch are provided as local review artifacts.

Recent error-log samples contain repeated rate-limit errors. The existing error
handler translated Fastify's HTTP 429 into generic HTTP 500 responses. The candidate
preserves HTTP 429 and uses `RATE_LIMITED` as the API code.

The database is listed as available, but its empty external-IP allowlist prevents
the hosted connector from running read-only queries. Migration readiness and real
Postgres execution could not be verified. The allowlist was left unchanged.

## Changes

- Replace the growing numbered core patch with one `pngea-core.js` entry point.
  Retire inactive historical builds; the recovered baseline is retained separately
  in the local inspection workspace and remains available in Git history.
- Load each shell dependency once. Retire the older profile-save/read pipeline.
  The existing live adapter delegates thread, profile, and ticker work to the core.
- One message controller handles route changes, realtime, polling, media, and
  receipts. Failed sends retain text/files and their retry ID. Uploaded media IDs
  are reused on retry. Replies from a previous thread cannot paint the active one.
  Unchanged messages retain DOM nodes; older message pages can be loaded explicitly.
- Message insertion uses the existing unique client-ID index with conflict-safe
  insertion. Concurrent retries reuse one canonical message and emit one event.
  Message reads return the latest page in chronological order with a stable
  timestamp/ID cursor, instead of only the oldest 500 messages.
- Avatars and banners use the viewed profile's canonical artwork. Media IDs take
  precedence over stale direct URLs; removal clears painted images. Signed-avatar
  access requests are coalesced and cached within their expiry. Publicly referenced,
  ready profile images are accessible to other authenticated users.
- Reaction reconciliation checks request generation and pending writes before
  applying a result. Decoration is idempotent, preventing repeated observer-driven
  DOM writes. Backend reaction/bookmark creation uses canonical post visibility.
- History's activity log has its own tab within the same library controller.
  Saved/Videos/Articles/Likes no longer lose their host to a competing renderer.
  Videos and Articles are scoped to authored, viewed, or saved posts. Library and
  community reads respect blocks and post visibility. Invalid History limits fail
  before SQL, and deduplication distinguishes object type and label.
- Community discovery, joining, and opening use real API responses and report
  action errors. Close Friends can be removed; nested action buttons no longer
  navigate to profiles instead of performing their action.
- Followers/following/Close Friends responses join the shared avatar pipeline.
  Renamed handles resolve consistently for profile posts.
- One ticker controller owns fetching, state, and rendering. Navigation leaves
  unchanged ticker nodes in place. Cached state is account-scoped and bounded on
  restoration; successful responses replace the eligible pool, including empty
  responses. Source attribution and stale labels are retained.
- Remove static demo feeds, market prices, social counts, communities, viewing
  history, messages, search fixtures, and NOW events from the active frontend.
  Failed profile saves retain canonical identity and keep the editor open.
- Repair the PWA manifest's icon paths to match the existing assets.

## Validation

Before implementation: existing backend tests and source syntax passed; the first
browser regression suite reproduced nine failures out of eleven checks. Tests
were run before each implementation batch and after relevant changes.

Final validation:

- 21 Chromium browser regressions passed using intercepted API fixtures.
- 6 backend route/error regressions passed with isolated DB/event adapters.
- 11 existing ticker-ranker tests passed.
- All JavaScript, inline-script syntax, loaded script references, manifest icon
  references, and `git diff --check` passed.

Reproduce from the repo root:

```sh
npm test --prefix backend
node backend/test/reliability.test.js
node backend/test/ticker-ranker.test.js
python tests/browser_reliability.py
python scripts/package_backend.py
```

Browser checks require Python Playwright and Chromium at `/usr/bin/chromium`.
These are not authenticated production end-to-end tests. DB adapters in route tests
are controlled mocks; real concurrent Postgres transactions, Redis fanout, object
storage uploads, and multi-device delivery require a staging integration pass.
Existing follower/following, community, and Close Friends endpoints retain their
existing list limits; full graph/feed pagination remains separate work.

## Release compatibility

`scripts/package_backend.py` rebuilds the archive consumed by the current Render
commands. It retains the required internal directory `pngea-v0.37.1-full` and writes
`pngea-v0.37.1-full.zip`, despite the candidate version being 0.51.7.
Backend source is now also available directly under `backend/` for review.
No new SQL migration files were added. The runtime expects migrations 001–006;
verify these are already applied before any production release.

Deploy only after a staging integration check. Main-branch merge would trigger
the existing Render auto-deploy; no merge or deployment was attempted.
