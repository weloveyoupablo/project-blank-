# PNGEA 0.52.1 following feed, messaging and post creation

Built from the inspected 0.52.0 live frontend and companion backend. The Render service remains on Free, with its existing archive name and extraction commands. Verification creates no production messages, posts or accounts.

## Following feed

Home now requires a follow relationship to the post author in addition to existing visibility and block checks. Public posts from strangers no longer enter Home through realtime events: those events reload the canonical following feed. Your own posts remain available on your profile; Home follows the requested rule of showing only followed authors. Empty feeds explain how to populate them. Follow/unfollow requests a fresh canonical feed after any older request completes, and delayed reaction responses cannot reinsert removed rows.

## Chat and keyboard

One viewport controller places the message/reply composer and attachment controls immediately above the keyboard. The main Home, Inbox and Notifications navigation stays at its normal position beneath the keyboard. The chat header stays stable when browsers resize both the layout and visual viewports. Native vertical message scrolling preserves the reader's position; an already-bottomed conversation keeps the latest message visible as keyboard geometry changes. Normal viewport scroll events no longer force a jump to the bottom.

Opening a profile from a chat records the originating conversation, draft and scroll position. Profile Back restores that chat. Return state is scoped to the signed-in account. Read receipts remain limited to the latest outgoing message.

## Photo creation and shared post rendering

Gallery-first and camera-first posts use Next, then a review page with caption, small media thumbnails and Everyone/Followers only selection. Post submits from the review page. Tapping a photo thumbnail opens a black crop editor with a thirds grid, drag positioning, zoom, rotation and aspect choices. Save retains the crop; Back cancels the edit. The chosen crop is applied to the uploaded image, defaulting to 4:5. Drafts and uploads capture audience, format, caption and media before asynchronous work, preserving followers-only visibility through Cancel/restore and composer changes during upload.

Gallery posts have the author above the image, like/comment/repost/send grouped left, Save at the right and caption below. Text-first posts with attached images retain their bubble, text above the image and comment/repost/like/send order. Existing posts use stored source metadata; posts without it retain the text style because their original intent cannot be reconstructed reliably. Common image rules cover the frame without letterboxing and cap media height at 430px or 62svh, whichever is smaller.

Home, profiles, History, Communities and Close Friends continue to use the shared post renderer. Post detail shares the photo actions and compact reply appearance. Avatar links open profiles and the shared three-dot menu works above page overlays. Post sharing uses the internal PNGEA recipient picker. The profile Likes tab is removed; liked posts remain in History.

Composer headings remain centered as New posts during selection and upload. Existing reel, long-video and long-form formats remain available through the same composer.

## Mentions and voice

Posts and comments support clickable @handles and account-search suggestions. The reply composer displays Replying to @originalposter above the input. The backend resolves up to 20 distinct valid handles and sends notifications only to eligible active recipients, respecting blocks and both reply/parent audiences. The parent author receives one reply notification when also mentioned. Notification delivery failure is logged without making an already-saved post appear to fail.

Posts, replies and messages share one audio-note player with play/pause, seek, time and grey-to-white waveform progress. Amplitude bars are decoded from the real audio on first playback, within bounded fetch/cache limits. If decoding is unavailable, uniform neutral bars retain normal playback. Only one voice note plays at a time.

## Validation

Baseline browser and backend tests ran before implementation. New browser checks cover keyboard geometry/scrolling, chat return state, photo review/crop upload, action order, mentions, realtime feed filtering and real-WAV playback/seeking. The complete suite contains 82 browser regressions and 22 backend route/ticker unit tests. JavaScript syntax and archive contents are checked separately.

The isolated PGlite PostgreSQL integration applies migrations 001–007 and verifies format/title persistence, following-only feeds, saved state, profile counts, author-only deletion, History queries and mention audience protection. No production database or authenticated production end-to-end session is used. Browser test fixtures do not populate the product.

Physical iPhone Safari and Android keyboard/picker behavior still need device verification. A web page uses the operating system's photo picker and cannot force a particular Photos album.

## Deployment and rollback

Replace index.html, pngea-core.js, pngea-v0.40.8-basic-ui-fix.js and pngea-v0.37.1-full.zip at the existing repository root. Deploy that commit on the current Render service. The archive root remains pngea-v0.37.1-full. No new migration is added; migration 007 from the prior release must be present. Keep Free and the current build/start commands.

Confirm frontend build 0.52.1-following-chat and backend /health version 0.52.1 with features.followingFeed true. Frontend cache keys are 5211. The backend deployment is required for following filtering, saved state and mentions.

Rollback uses the prior frontend files and backend archive. Additive schema columns can remain; do not drop them or rerun older repair migrations.
