# PNGEA 0.53.1 verification

- Baseline: 51 focused browser cases passed before implementation; backend reliability 11 and real media/storage 12 passed before the corresponding changes.
- Browser regression coverage: 160 unique cases validated. The 159-case full run passed 158; its one failure checked an asynchronous draft list before rendering finished. All four update/ticker cases passed after correcting that wait. The additional fresh-offline visitor case passed with the seven-case session suite. The fullscreen visual/seek case passed again after the contrast/icon refinement.
- Backend: 64 tests passed, including the actual AWS SDK presigner, message preview SQL, media recovery, social privacy, source allowlist and US clock rules.
- Migrations 001–009 and post formats/counts/following feed/bookmarks/deletion/History/mention audiences passed in isolated PostgreSQL.
- Syntax: nine inline scripts, core, UI bridge and all backend JavaScript passed. git diff --check passed.

## Actual app video path

The new test selects the real MP4 in the app's gallery picker. It uses the real XMLHttpRequest PUT, actual AWS SDK presigner, checksum-validating local HTTP object storage, production Fastify route bodies, Zod validation and PGlite PostgreSQL. It does not replace upload/completion/post creation with mocked success responses. It verifies saved followers-only visibility, canonical post content and metadata, playback in a following viewer's Home feed, 9:16 presentation, fullscreen actions, and seeking forward and backward.

Before the storage fix, the actual SDK signed x-amz-checksum-crc32=AAAAAA== for a bodyless PUT. The regression failed against the expected absence of that empty-file constraint. With requestChecksumCalculation=WHEN_REQUIRED it passes. The environment-only equivalent was independently confirmed with the default SDK client and applied to the current production Render service; deployment dep-db8p47on74is73caigu0 is live, still Free.

## Production verification

On 2026-10-16, with explicit user approval, a clearly named test account with zero followers posted a followers-only MP4 through the published 0.53.0 app's actual gallery → Next → caption/audience → Post flow. Production returned upload-slot 201, completion 200 and post-creation 201. The canonical post retained gallery format, followers-only visibility and 2000 ms video metadata. Playback loaded in the published app.

The 0.53.1 candidate frontend was then loaded only in the test browser while retaining the real production API and object storage. Its uploaded video displayed at 9:16, expanded to fullscreen with the caption and five action buttons, and sought forward to 1.4 seconds and backward to 0.4 seconds. No API or storage response was mocked, TLS verification remained enabled, and there were no page errors. Both test posts and their video media were deleted after the checks; the final profile list confirmed their absence. Evidence is recorded in production-video-check.json in the release artifacts.

The new frontend/backend files are not yet deployed. Physical iPhone Safari keyboard operation remains unverified; automated viewport/gesture checks cover the retained controller.

## Commands

Full browser modules: tests.browser_reliability plus every tests/test_*.py module, with PNGEA_INTEGRATION_BASE set to the local harness URL.

Harness: PNGEA_TEST_MODULE_ROOT=<temporary node_modules> node tests/live_backend_harness.mjs

Backend: import all backend/test/*.test.js with PNGEA_TEST_MODULE_ROOT containing @electric-sql/pglite, zod, Fastify and AWS S3/presigner packages. Run tests/postgres_formats.mjs separately. Local storage tests need local HTTP and ffprobe. All test data stays in the isolated harness database/storage.
