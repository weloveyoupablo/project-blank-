# PNGEA v0.37.1 — Market + News Intelligence

v0.37 connects the Home ticker to a real backend ranking system instead of static market/news copy.

### Added
- real-time market-data worker
- real-time financial-news worker
- Alpaca WebSocket + snapshot adapter
- market quote canonical store
- external-news canonical store
- source/URL/timestamp/feed provenance
- delayed/stale labeling
- news verification states
- per-user ticker symbols/topics/categories
- ticker relevance + freshness + diversity ranker
- live `ticker.updated` events over PNGEA realtime
- dynamic frontend ticker
- secure ingest endpoint for future licensed general-news sources
- no fake market/news fallback in authenticated live mode

### Run
See `backend/README.md` and `.env.example`.


## v0.37 interaction update
- NOW no longer floats as a center pill. It dispenses from the top-left profile avatar for 5 seconds, retracts, then leaves a flashing red live dot.
- Top-left avatar opens the sidebar. From the sidebar, tapping your avatar/name/handle opens your Profile. Everywhere else, tapping an identity opens that user's profile.
- Backend exposes privacy-aware public/user profile post retrieval.

## v0.38 worker supervisor
Production now supervises the media-processing and market/news workers from the API service itself. They inherit the API's Postgres, Redis, object-storage, and market-provider environment variables and automatically restart if a worker exits. `/health` reports worker status. Set `EMBEDDED_WORKERS=false` later when moving workers to dedicated paid services.
