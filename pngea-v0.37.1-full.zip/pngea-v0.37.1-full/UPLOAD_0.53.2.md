# PNGEA 0.53.2 compose and sports

Extract the release and replace these four files in the existing repository root:

1. index.html
2. pngea-core.js
3. pngea-v0.40.8-basic-ui-fix.js
4. pngea-v0.37.1-full.zip — upload intact, without unpacking this companion archive.

Keep the existing Render Free service, build command, start command, archive name and extraction directory. Startup applies the additive migrations 010_profile_details.sql and 011_sports_scores.sql. No paid service or new credential is needed. Retain AWS_REQUEST_CHECKSUM_CALCULATION=WHEN_REQUIRED.

Expected frontend: 0.53.2-compose-sports. Expected backend health: 0.53.2.
After publication, open https://weloveyoupablo.github.io/project-blank-/?v=5321 .

Word-post replies now use the existing composer as a full page with the original post/image preview, thread line, self avatar and replying-to handle. Timeline and post-detail reply actions use the same page. Photo comments retain their timeline sheet. Word posts and replies have a 280-character counter, overflow highlighting and a publishing guard, plus an Everyone/Followers audience selector. Gallery captions and long-form articles are exempt from the 280-character rule. Back returns through posting subpages while preserving content and attachments.

Short and long videos retain their original frame proportions. Fullscreen playback contains the entire frame with black space around it; seek controls and the five social actions remain. Saved opens a square gallery with photo/video thumbnails and text previews for word posts. A word post's attached image appears after opening the post.

Profiles now persist location and website, show their real joined month/year, update canonical follow counts in the sidebar, and use a plain Share profile label. Feed refresh works through the header button or by pulling down at the top of Home.

Startup uses one connection screen, a working Retry that cancels a stalled attempt, and background loading of secondary data after authentication. Request deadlines cover response bodies and refresh attempts. Account changes discard old requests; expired sessions preserve unsent posts as account-specific drafts before showing sign-in. Existing legacy drafts migrate once into the active account's store.

Inbox long-press offers Open chat / Create chathead. Floating avatar heads display unread badges and open a mini chat using the same conversation, input and send pipeline. Long-pressing an actual message opens Remember / Create event / Create community / Ask about this for that message. Post and other object menus retain their existing actions.

Ticker headlines add NBC News, MS NOW and NPR, plus the approved sports publishers and official leagues. Real ESPN scores cover NFL, NCAA football, men's/women's NCAA basketball, NBA, NHL and MLB. Headlines refresh every two hours and scores every minute, with stale live scores omitted. Markets have a smaller allocation; unavailable data is omitted. External articles and quotes use direct native links, and stock rows omit "last known".

The source archive includes all migrations and regression tests. See RELEASE_0.53.2_CHECKS.md for verification and device limits. Rollback restores the prior four files; leave the additive database migrations in place.
