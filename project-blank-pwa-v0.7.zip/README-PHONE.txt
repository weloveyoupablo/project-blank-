PROJECT BLANK — PWA v0.7

This is the installable mobile-web version of v0.6.

WHAT IT ADDS
- Full-screen standalone mode when added to the Home Screen
- iPhone safe-area support
- Home Screen icon
- Offline caching after first successful load
- Same v0.6 feed, Pulse, ticker, post types, composer, video view and long-form view

IMPORTANT
A PWA must be served from an HTTPS website for installation/service-worker features. Opening index.html as a local file is enough to preview it, but not enough for full PWA installation.

iPHONE INSTALL AFTER HOSTING
1. Open the HTTPS site in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Open the new icon from your Home Screen.
