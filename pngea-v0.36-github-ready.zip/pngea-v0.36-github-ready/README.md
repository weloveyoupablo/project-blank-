# PNGEA v0.36 — Market + News Intelligence

v0.36 connects the Home ticker to a real backend ranking system instead of static market/news copy.

### Added
- real-time market-data worker
- real-time financial-news worker
- Alpaca WebSocket + snapshot adapter
- market quote canonical store
- external-news canonical store
- source/URL/timestamp/feed provenance
- delayed/stale labeling
- news verification states
- per-user ticker symbols/topics/categories
- ticker relevance + freshness + diversity ranker
- live `ticker.updated` events over PNGEA realtime
- dynamic frontend ticker
- secure ingest endpoint for future licensed general-news sources
- no fake market/news fallback in authenticated live mode

### Run
See `backend/README.md` and `.env.example`.
