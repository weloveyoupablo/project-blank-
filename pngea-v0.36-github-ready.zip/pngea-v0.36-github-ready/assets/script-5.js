/* PNGEA OBJECT / INTENT SUBSTRATE v0.33
   Fixed shell, fluid center. Search icon remains untouched; one field infers Search / Ask / Go. */
(() => {
  const api=window.PNGEA;if(!api)return;const state=api.state;
  state.memory=Array.isArray(state.memory)?state.memory:[];
  state.tasks=Array.isArray(state.tasks)?state.tasks:[];
  state.agent={permission:'confirm',...(state.agent||{})};
  state.intelligence={activeProvider:'local-prototype',router:'pngea-auto',providerSwap:true,...(state.intelligence||{})};
  state.privacyConsents={smartMemory:false,personalMemoryTraining:false,commercialSharing:false,...(state.privacyConsents||{})};
  state.intelligenceAudit=Array.isArray(state.intelligenceAudit)?state.intelligenceAudit:[];
  state.nowEvents=Array.isArray(state.nowEvents)&&state.nowEvents.length?state.nowEvents:[
    {id:'now-friends',kind:'social',title:'3 friends at an event',meta:'nearby · live',detail:'Friends are active around an event right now.'},
    {id:'now-live',kind:'live',title:'Jordan is LIVE',meta:'8 friends watching',detail:'A live broadcast is pulling in people from your graph.'},
    {id:'now-game',kind:'sports',title:'Game · 4Q 2:13',meta:'97–94',detail:'A game followed by people in your network is close.'}
  ];
  api.save();

  const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const nowDock=$('#pnNowDock'),nowDockText=$('#pnNowDockText'),taskDock=$('#pnTaskDock'),taskDockTitle=$('#pnTaskDockTitle'),taskDockMeta=$('#pnTaskDockMeta');
  const sheet=$('#pnActionSheet'),sheetShade=$('#pnSheetShade'),sheetActions=$('#pnSheetActions'),sheetTitle=$('#pnActionTitle'),sheetSubtitle=$('#pnActionSubtitle');
  const nowLayer=$('#pnNowLayer'),nowLayerBody=$('#pnNowLayerBody'),spaceLayer=$('#pnSpaceLayer'),spaceBody=$('#pnSpaceBody');
  const intentResult=$('#pnIntentResult'),searchInput=$('#globalSearchInput'),searchRecent=$('#searchRecent'),searchTabs=$('#Search .xTabs'),searchScroll=$('#searchScroll');
  let currentObject=null;

  function fmtTime(ts){try{return new Date(ts).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}catch{return ''}}
  function taskStatusLabel(s){return s==='waiting_for_user'?'Needs you':s==='running'?'Working':s==='completed'?'Complete':s==='failed'?'Failed':'Queued'}
  function makeTask(title,{detail='',sensitive=false,kind='general'}={}){
    const permission=state.agent.permission||'confirm';
    const wait=sensitive&&permission!=='autonomous';
    const task={id:'t'+Date.now()+Math.random().toString(36).slice(2,5),title,detail,kind,status:wait?'waiting_for_user':'queued',createdAt:Date.now()};
    state.tasks.unshift(task);api.save();renderTasks();renderTaskDock();
    if(!wait) runTask(task.id);
    return task;
  }
  function runTask(id){const t=state.tasks.find(x=>x.id===id);if(!t)return;t.status='running';t.startedAt=Date.now();api.save();renderTasks();renderTaskDock();setTimeout(()=>{const x=state.tasks.find(q=>q.id===id);if(!x||x.status!=='running')return;x.status='completed';x.completedAt=Date.now();api.save();renderTasks();renderTaskDock();api.toast('Task complete')},1400)}
  function confirmTask(id){const t=state.tasks.find(x=>x.id===id);if(!t)return;runTask(id)}
  function dismissTask(id){state.tasks=state.tasks.filter(x=>x.id!==id);api.state.tasks=state.tasks;api.save();renderTasks();renderTaskDock()}
  function renderTaskDock(){const active=state.tasks.find(t=>['queued','running','waiting_for_user'].includes(t.status));const latest=active||state.tasks.find(t=>t.status==='completed'&&Date.now()-(t.completedAt||0)<7000);if(!latest){taskDock.classList.remove('show','complete');return}taskDock.classList.add('show');taskDock.classList.toggle('complete',latest.status==='completed');taskDockTitle.textContent=latest.title;taskDockMeta.textContent=taskStatusLabel(latest.status)+(latest.status==='waiting_for_user'?' · tap to review':'')}
  taskDock.onclick=()=>{api.navigate('AIBot');selectAssistantTab('tasks')};

  function memoryTitle(o){return o.title||o.text||o.name||({post:'Post',message:'Message',conversation:'Conversation',place:'Place',event:'Event',community:'Community',product:'Product',media:'Media'}[o.type]||'PNGEA object')}
  function remember(o){if(!o)return;const key=o.id||o.key||memoryTitle(o);if(state.memory.some(m=>m.key===key)){api.toast('Already remembered');return}state.memory.unshift({key,type:o.type||'object',title:memoryTitle(o),context:o.context||o.subtitle||'',savedAt:Date.now()});api.save();renderMemory();api.toast('Remembered')}

  function renderTasks(){const host=$('#assistantTasks');if(!host)return;host.innerHTML='<div class="assistantIntro"><b>Tasks</b><p>PNGEA can keep working while you use the rest of the app. Actions that need approval pause here.</p></div>'+(state.tasks.length?state.tasks.map(t=>`<div class="taskRow"><div class="taskState">${t.status==='completed'?'✓':t.status==='waiting_for_user'?'!':'○'}</div><div class="taskCopy"><b>${esc(t.title)}</b><small>${esc(t.detail||taskStatusLabel(t.status))} · ${esc(taskStatusLabel(t.status))}</small>${t.status==='waiting_for_user'?`<div class="taskControls"><button class="primary" data-task-confirm="${esc(t.id)}">Confirm</button><button data-task-dismiss="${esc(t.id)}">Cancel</button></div>`:''}</div></div>`).join(''):'<div class="taskEmpty"><b>No active tasks</b>Ask PNGEA to do something and it will appear here.</div>')}
  function renderMemory(){const host=$('#assistantMemory');if(!host)return;host.innerHTML='<div class="assistantIntro"><b>Memory</b><p>Only things you explicitly Remember are stored in this prototype. Automatic personal memory is not enabled.</p></div>'+(state.memory.length?state.memory.map(m=>`<div class="memoryRow"><div class="memoryGlyph">⌁</div><div class="memoryCopy"><b>${esc(m.title)}</b><small>${esc(m.type)}${m.context?' · '+esc(m.context):''} · ${esc(fmtTime(m.savedAt))}</small></div></div>`).join(''):'<div class="memoryEmpty"><b>Nothing remembered yet</b>Hold a post, message, place, product, or profile and choose Remember.</div>')}
  function renderPermissions(){
    const host=$('#assistantPermissions');if(!host)return;
    const levels=[['read','Read'],['suggest','Suggest'],['prepare','Prepare'],['confirm','Confirm'],['autonomous','Autonomous']];
    const c=state.privacyConsents;
    host.innerHTML=`<div class="assistantIntro"><b>Permissions</b><p>PNGEA's assistant is infrastructure, not a separate room. These controls separate what it may know, what it may do, and what may be used to improve models.</p></div>
      <div class="permissionBlock"><b>Default action level</b><p>High-risk actions such as payments, public posting, destructive actions, and account changes still stop for explicit confirmation.</p><div class="permissionSet">${levels.map(([v,l])=>`<button class="permissionChoice ${state.agent.permission===v?'active':''}" data-agent-permission="${v}">${l}</button>`).join('')}</div></div>
      <div class="permissionBlock"><b>Memory & data use</b><p>Manual Remember works now. The other categories remain independently permissioned.</p>
        <div class="consentRow"><div class="consentCopy"><b>Smart Memory</b><small>Automatically remember useful permitted context.</small></div><div class="miniToggle ${c.smartMemory?'on':''}" data-privacy-toggle="smartMemory"></div></div>
        <div class="consentRow"><div class="consentCopy"><b>Use personal Memory to improve models</b><small>Separate opt-in from normal personalization and retrieval.</small></div><div class="miniToggle ${c.personalMemoryTraining?'on':''}" data-privacy-toggle="personalMemoryTraining"></div></div>
        <div class="consentRow"><div class="consentCopy"><b>Commercial data sharing</b><small>Separate permission for any future third-party commercial sharing.</small></div><div class="miniToggle ${c.commercialSharing?'on':''}" data-privacy-toggle="commercialSharing"></div></div>
      </div>`
  }

  // PNGEA Intelligence Layer: model-provider independence, tools, permissions and audit.
  const intelligence=window.PNGEAIntelligence=window.PNGEAIntelligence||(()=>{
    const providers=new Map(),tools=new Map();
    function audit(type,detail={}){state.intelligenceAudit.unshift({type,detail,at:Date.now()});state.intelligenceAudit=state.intelligenceAudit.slice(0,50);api.save()}
    function registerProvider(id,provider){providers.set(id,{id,...provider});return id}
    function registerTool(id,tool){tools.set(id,{id,risk:'low',...tool});return id}
    function activeProvider(){return providers.get(state.intelligence.activeProvider)||providers.get('local-prototype')}
    function setProvider(id){if(!providers.has(id))return false;state.intelligence.activeProvider=id;api.save();audit('provider_changed',{id});renderSystem();return true}
    function canRun(tool){const order={read:0,suggest:1,prepare:2,confirm:3,autonomous:4};const needed={low:0,medium:2,high:3,critical:3}[tool.risk]??3;return (order[state.agent.permission]??3)>=needed}
    async function callTool(id,args={}){const tool=tools.get(id);if(!tool)throw new Error('Unknown tool');audit('tool_requested',{id});if(!canRun(tool))return{status:'needs_confirmation',tool:id,args};const result=await tool.execute(args);audit('tool_completed',{id});return{status:'completed',result}}
    async function plan(input,context={}){const p=activeProvider();if(!p)throw new Error('No intelligence provider');audit('plan_requested',{provider:p.id});return p.plan(input,context)}
    return{providers,tools,registerProvider,registerTool,activeProvider,setProvider,callTool,plan,audit}
  })();

  intelligence.registerProvider('local-prototype',{
    label:'PNGEA Local Prototype',kind:'local',status:'ready',
    async plan(input,context={}){return{mode:inferIntent(input),input,context,provider:'local-prototype'}}
  });
  // Production adapters plug in here later: self-hosted/open-weight, OpenAI-compatible, Anthropic-compatible, etc.
  intelligence.registerTool('search',{label:'Search PNGEA',risk:'low',execute:async({query})=>({query})});
  intelligence.registerTool('remember',{label:'Remember object',risk:'low',execute:async({object})=>{remember(object);return true}});
  intelligence.registerTool('navigate',{label:'Navigate PNGEA',risk:'low',execute:async({screen})=>{api.navigate(screen);return screen}});
  intelligence.registerTool('create_task',{label:'Create task',risk:'medium',execute:async({title,detail='',kind='agent',sensitive=false})=>makeTask(title,{detail,kind,sensitive})});
  intelligence.registerTool('send',{label:'Send or share',risk:'high',execute:async(args)=>makeTask(args.title||'Send item',{detail:'Prepared by PNGEA',sensitive:true,kind:'share'})});
  intelligence.registerTool('commerce',{label:'Purchase or reservation',risk:'critical',execute:async(args)=>makeTask(args.title||'Commerce action',{detail:'Requires confirmation',sensitive:true,kind:'commerce'})});

  function renderSystem(){
    const host=$('#assistantSystem');if(!host)return;
    const p=intelligence.activeProvider();const audit=state.intelligenceAudit.slice(0,5);
    host.innerHTML=`<div class="assistantIntro"><b>PNGEA Intelligence</b><p>The assistant is a model-agnostic orchestration layer. PNGEA owns the memory, tools, permissions, tasks, and routing; model providers can be replaced underneath it.</p></div>
      <div class="intelGrid">
        <div class="intelCard"><small>Router</small><b>PNGEA Auto</b><p>Infers Search / Ask / Go without a mode switch.</p></div>
        <div class="intelCard"><small>Runtime</small><b>${esc(p?.label||'None')}</b><p>${intelligence.providers.size} provider adapter${intelligence.providers.size===1?'':'s'} registered.</p></div>
        <div class="intelCard"><small>Tools</small><b>${intelligence.tools.size} registered</b><p>Actions are gated by PNGEA permissions, not model preference.</p></div>
        <div class="intelCard"><small>Provider lock-in</small><b>None by design</b><p>Self-hosted and external models can share the same PNGEA tool layer.</p></div>
      </div>
      <div class="intelSection"><b>Provider architecture</b><p>No API keys belong in this client. Production providers will be selected server-side through PNGEA's model router.</p>
        <div class="intelProvider"><span class="intelDot on"></span><div><b>PNGEA Local Prototype</b><small>Current heuristic runtime · development only</small></div></div>
        <div class="intelProvider"><span class="intelDot"></span><div><b>PNGEA self-hosted models</b><small>Planned primary independent runtime</small></div></div>
        <div class="intelProvider"><span class="intelDot"></span><div><b>External model adapters</b><small>Optional providers behind the same interface</small></div></div>
      </div>
      <div class="intelSection"><b>Recent intelligence audit</b><p>Every provider change and tool action can be traced independently of the model.</p>${audit.length?audit.map(a=>`<div class="auditRow"><b>${esc(a.type.replaceAll('_',' '))}</b><small>${esc(fmtTime(a.at))}</small></div>`).join(''):'<div class="auditRow"><b>No activity yet</b><small>Actions will appear here.</small></div>'}</div>`
  }

  function selectAssistantTab(tab){$$('[data-assistant-tab]').forEach(x=>x.classList.toggle('active',x.dataset.assistantTab===tab));$$('.assistantPanel').forEach(x=>x.classList.toggle('active',x.id==='assistant'+tab[0].toUpperCase()+tab.slice(1)));if(tab==='tasks')renderTasks();if(tab==='memory')renderMemory();if(tab==='permissions')renderPermissions();if(tab==='system')renderSystem()}
  $('#assistantTabs')?.addEventListener('click',e=>{const t=e.target.closest('[data-assistant-tab]');if(t)selectAssistantTab(t.dataset.assistantTab)});
  $('#AIBot')?.addEventListener('click',e=>{const c=e.target.closest('[data-task-confirm]');if(c){confirmTask(c.dataset.taskConfirm);return}const d=e.target.closest('[data-task-dismiss]');if(d){dismissTask(d.dataset.taskDismiss);return}const p=e.target.closest('[data-agent-permission]');if(p){state.agent.permission=p.dataset.agentPermission;api.save();intelligence.audit('permission_changed',{level:state.agent.permission});renderPermissions();api.toast('Assistant permission updated');return}const pt=e.target.closest('[data-privacy-toggle]');if(pt){const k=pt.dataset.privacyToggle;state.privacyConsents[k]=!state.privacyConsents[k];api.save();intelligence.audit('privacy_consent_changed',{category:k,value:state.privacyConsents[k]});renderPermissions();return}});
  renderTasks();renderMemory();renderPermissions();renderSystem();renderTaskDock();

  function renderAdaptive(){const h=new Date().getHours();let title='RIGHT NOW',subtitle='the center adapts; the shell does not',cards=[];if(h>=18||h<4){title='TONIGHT';cards=[['Friends out','social','Now'],['What’s live','NOW','Now'],['Dating','nearby','Dating']]}else if(h<12){title='THIS MORNING';cards=[['News','what moved','Now'],['Communities','your circles','Communities'],['Messages','pick up here','Inbox']]}else{title='AROUND YOU';cards=[['Communities','active now','Communities'],['Friends','social graph','Profile'],['NOW','live layer','Now']]};const host=$('#pnAdaptive');if(!host)return;host.classList.add('show');host.innerHTML=`<div class="pnAdaptiveHead"><b>${title}</b><span>${subtitle}</span></div><div class="pnAdaptiveGrid">${cards.map(([a,b,s])=>`<div class="pnAdaptiveCard" data-adaptive-screen="${s}"><strong>${a}</strong><small>${b}</small></div>`).join('')}</div>`}
  $('#pnAdaptive')?.addEventListener('click',e=>{const c=e.target.closest('[data-adaptive-screen]');if(c)api.navigate(c.dataset.adaptiveScreen)});renderAdaptive();

  function renderNowDock(){const ev=state.nowEvents[0];if(!ev){nowDock.classList.remove('show');return}nowDockText.textContent=ev.title;nowDock.classList.add('show')}
  function renderNowLayer(){const evs=state.nowEvents;nowLayerBody.innerHTML=`<div class="pnNowHero"><small>LIVE SOCIAL CONTEXT</small><h2>What matters this second.</h2><p>NOW turns realtime events from your graph, places, media, games, and communities into temporary interface objects.</p></div>${evs.map(e=>`<div class="pnNowItem" data-now-id="${esc(e.id)}"><i></i><div><b>${esc(e.title)}</b><small>${esc(e.meta)}</small></div><span>›</span></div>`).join('')}`}
  nowDock.onclick=()=>{renderNowLayer();nowLayer.classList.add('show')};$('#pnNowBack').onclick=()=>nowLayer.classList.remove('show');
  nowLayer.addEventListener('click',e=>{const row=e.target.closest('[data-now-id]');if(!row)return;const ev=state.nowEvents.find(x=>x.id===row.dataset.nowId);if(ev){openSpace({type:ev.kind==='social'?'event':'live',title:ev.title,context:ev.meta,detail:ev.detail})}});renderNowDock();

  function objectFromElement(el){const article=el.closest('article');if(article){const title=(article.querySelector('.breakTitle,.longTitle,.liveTitle,.caption,.body')?.textContent||'Post').trim();const type=article.classList.contains('longVideo')?'media':article.querySelector('.livePreview')?'live':article.classList.contains('breaking')?'post':'post';return{id:article.dataset.localPost||article.dataset.postId||('obj-'+title.slice(0,30)),type,title,context:article.querySelector('.meta')?.textContent||''}}const dm=el.closest('.dmRow');if(dm)return{id:'dm-'+(dm.dataset.dm||'conversation'),type:'conversation',title:dm.querySelector('.dmLine b')?.textContent||'Conversation',context:dm.querySelector('.dmPreview')?.textContent||''};const comm=el.closest('.communityCard');if(comm)return{id:'community-'+(comm.querySelector('.communityTitle')?.textContent||''),type:'community',title:comm.querySelector('.communityTitle')?.textContent||'Community',context:comm.querySelector('.communityDesc')?.textContent||''};const story=el.closest('.story');if(story)return{id:'now-'+(story.querySelector('b')?.textContent||''),type:'event',title:story.querySelector('b')?.textContent||'NOW event',context:story.querySelector('small')?.textContent||''};return{id:'generic-'+Date.now(),type:'object',title:'PNGEA object',context:''}}
  const ACTIONS={
    post:[['⌁','Remember','Find it later','remember'],['✦','Ask PNGEA','Use this as context','ask'],['↗','Send','Share it socially','send'],['◇','Open Space','Turn it interactive','space'],['◷','Turn into event','Create a plan around it','event']],
    media:[['⌁','Remember','Find it later','remember'],['⌕','Search visual','Use media as search input','ask'],['▷','Watch party','Turn watching social','watch'],['↗','Send','Share it socially','send']],
    live:[['⌁','Remember','Save the live object','remember'],['◎','Watch party','Invite people into it','watch'],['↗','Send','Share the live object','send']],
    conversation:[['⌁','Remember','Save this conversation reference','remember'],['◷','Create event','Turn chat into a plan','event'],['◎','Create community','Promote the group','community'],['✦','Ask about this','Use conversation context','ask']],
    community:[['⌁','Remember','Save this community','remember'],['◷','Create event','Plan with the community','event'],['↗','Send','Share the community','send']],
    event:[['⌁','Remember','Save this event','remember'],['◇','Open Space','Interactive event view','space'],['↗','Invite','Send to friends','send']],
    object:[['⌁','Remember','Find it later','remember'],['✦','Ask PNGEA','Use it as context','ask'],['↗','Send','Share it socially','send']]
  };
  function openActionSheet(o){currentObject=o;sheetTitle.textContent=memoryTitle(o);sheetSubtitle.textContent=(o.type||'object').toUpperCase()+' · what should this become?';const acts=ACTIONS[o.type]||ACTIONS.object;sheetActions.innerHTML=acts.map(([g,t,s,a])=>`<div class="pnActionRow" data-object-action="${a}"><span class="pnActionGlyph">${g}</span><div><b>${t}</b><small>${s}</small></div></div>`).join('');sheetShade.classList.add('show');sheet.classList.add('show')}
  function closeSheet(){sheetShade.classList.remove('show');sheet.classList.remove('show');currentObject=null}
  sheetShade.onclick=closeSheet;$('#pnActionClose').onclick=closeSheet;
  sheetActions.onclick=e=>{const row=e.target.closest('[data-object-action]');if(!row||!currentObject)return;const a=row.dataset.objectAction,o=currentObject;closeSheet();if(a==='remember'){remember(o);return}if(a==='ask'){api.navigate('Search');setTimeout(()=>{if(searchInput){searchInput.value=`Tell me about ${memoryTitle(o)}`;searchInput.focus();executeIntent(searchInput.value,'ask',o)}},40);return}if(a==='space'){openSpace(o);return}if(a==='send'){makeTask(`Send ${memoryTitle(o)}`,{detail:'Preparing share object',sensitive:true,kind:'share'});return}if(a==='event'){makeTask(`Create event from ${memoryTitle(o)}`,{detail:'Building event details',sensitive:true,kind:'event'});return}if(a==='community'){makeTask(`Create community from ${memoryTitle(o)}`,{detail:'Preparing community',sensitive:true,kind:'community'});return}if(a==='watch'){makeTask(`Start watch party`,{detail:memoryTitle(o),sensitive:true,kind:'watch'});return}};

  document.addEventListener('click',e=>{const m=e.target.closest('#feed .more');if(m){e.preventDefault();e.stopPropagation();openActionSheet(objectFromElement(m));}});
  let lpTimer=null,lpEl=null;document.addEventListener('touchstart',e=>{const el=e.target.closest('#feed article,.dmRow,.communityCard,.story');if(!el)return;lpEl=el;lpTimer=setTimeout(()=>openActionSheet(objectFromElement(el)),580)},{passive:true});document.addEventListener('touchend',()=>{clearTimeout(lpTimer);lpTimer=null;lpEl=null},{passive:true});document.addEventListener('touchmove',()=>{clearTimeout(lpTimer);lpTimer=null},{passive:true});

  function openSpace(o){spaceLayer.classList.add('show');spaceBody.innerHTML=`<div class="spaceHero"><small>PNGEA SPACE · ${esc((o.type||'object').toUpperCase())}</small><h2>${esc(memoryTitle(o))}</h2></div><div class="spaceBody"><div class="spaceMeta"><span>interactive</span><span>social</span><span>inside PNGEA</span></div><div class="spaceSection"><b>PEOPLE YOU KNOW</b><div class="spaceFriends"><span class="spaceFriend">MK</span><span class="spaceFriend">AR</span><span class="spaceFriend">JB</span></div></div><div class="spaceSection"><b>ABOUT</b><p style="font-size:12px;line-height:18px;color:#8a8a8a">${esc(o.detail||o.context||'This object can expose approved interactive capabilities without sending you to another app.')}</p></div><div class="spaceActions"><button class="primary" data-space-action="reserve">Reserve / act</button><button data-space-action="invite">Invite friends</button><button data-space-action="pay">Pay</button><button data-space-action="remember">Remember</button></div></div>`;spaceLayer.dataset.object=JSON.stringify(o)}
  $('#pnSpaceBack').onclick=()=>spaceLayer.classList.remove('show');$('#pnSpaceSend').onclick=()=>makeTask('Send Space',{detail:'Sharing interactive object',sensitive:true,kind:'share'});spaceBody.onclick=e=>{const b=e.target.closest('[data-space-action]');if(!b)return;let o={type:'object',title:'Space'};try{o=JSON.parse(spaceLayer.dataset.object||'{}')}catch{}const a=b.dataset.spaceAction;if(a==='remember')return remember(o);if(a==='reserve')return makeTask(`Reserve from ${memoryTitle(o)}`,{detail:'Reservation prepared',sensitive:true,kind:'commerce'});if(a==='invite')return makeTask(`Invite friends to ${memoryTitle(o)}`,{detail:'3 suggested friends',sensitive:true,kind:'social'});if(a==='pay')return makeTask(`Pay in ${memoryTitle(o)}`,{detail:'Payment requires confirmation',sensitive:true,kind:'payment'})};

  function inferIntent(q){const s=q.trim().toLowerCase();if(/^(send|book|reserve|create|make|invite|upload|post|pay|buy|start|turn|open|go to|set up|schedule)\b/.test(s)||/\b(and (send|book|reserve|invite|pay|create))\b/.test(s))return'go';if(/[?]$/.test(s)||/^(what|why|how|who|when|where|which|can|could|should|tell me|explain|summarize|show me|find me)\b/.test(s))return'ask';return'search'}
  function setIntentMode(mode){if(!intentResult)return;const labels={ask:'ASK',go:'GO'};if(!labels[mode]){intentResult.classList.remove('show');if(searchRecent)searchRecent.style.display='';if(searchTabs)searchTabs.style.display='';if(searchScroll)searchScroll.style.display='';return}intentResult.classList.add('show');if(searchRecent)searchRecent.style.display='none';if(searchTabs)searchTabs.style.display='none';if(searchScroll)searchScroll.style.display='none'}
  function friendTonightCards(){return `<div class="intentCards"><div class="intentCard" data-intent-card="now"><b>Friends & NOW</b><small>Live social context appears here when available</small></div><div class="intentCard" data-intent-card="messages"><b>Messages</b><small>Search recent conversations</small></div><div class="intentCard" data-intent-card="event"><b>Build a plan</b><small>Turn available context into an event</small></div><div class="intentCard" data-intent-card="space"><b>Open a Space</b><small>Use it without leaving PNGEA</small></div></div>`}
  function executeIntent(q,forced=null,context=null){const mode=forced||inferIntent(q);intelligence.audit('intent',{mode,query:q.slice(0,120)});if(mode==='search'){setIntentMode('search');return}setIntentMode(mode);if(mode==='ask'){const mem=state.memory.filter(m=>q.toLowerCase().split(/\s+/).some(w=>w.length>3&&(`${m.title} ${m.context}`).toLowerCase().includes(w))).slice(0,2);intentResult.innerHTML=`<div class="intentHead"><b>ASK</b><span>generated from your PNGEA context</span></div><div class="intentBody"><p>${q.toLowerCase().includes('friends')?`Here's a temporary view assembled from your social graph and live context.`:`PNGEA can answer this using the objects and context you have permission to access.`}</p>${q.toLowerCase().includes('friends')?friendTonightCards():mem.length?`<div class="intentCards">${mem.map(m=>`<div class="intentCard"><b>${esc(m.title)}</b><small>Remembered ${esc(m.type)}</small></div>`).join('')}</div>`:`<div class="intentCards"><div class="intentCard"><b>Search public PNGEA</b><small>Posts, people, communities, media</small></div><div class="intentCard"><b>Use personal context</b><small>Messages and Remembered objects you allow</small></div></div>`}</div>`;return}
    const sensitive=/\b(send|pay|buy|book|reserve|invite|post|message)\b/i.test(q);const task=makeTask(q,{detail:'PNGEA translated this into a multi-step action',sensitive,kind:'agent'});intentResult.innerHTML=`<div class="intentHead"><b>GO</b><span>multi-step task</span></div><div class="intentBody"><p>I turned this into a task instead of sending you through several pages.</p><div class="intentCards"><div class="intentCard"><b>${esc(task.title)}</b><small>${esc(taskStatusLabel(task.status))}</small></div><div class="intentCard"><b>Keep using PNGEA</b><small>The task persists while you move around the app.</small></div></div>${task.status==='waiting_for_user'?`<div class="intentConfirm"><button data-intent-cancel="${esc(task.id)}">Cancel</button><button class="primary" data-intent-confirm="${esc(task.id)}">Confirm</button></div>`:''}</div>`}

  searchInput?.addEventListener('keydown',e=>{if(e.key!=='Enter')return;const q=searchInput.value.trim();if(!q)return;const mode=inferIntent(q);if(mode==='search')return;e.preventDefault();e.stopImmediatePropagation();state.search=state.search||{history:[]};state.search.history=[q,...(state.search.history||[]).filter(x=>x!==q)].slice(0,8);api.save();executeIntent(q,mode)},true);
  searchInput?.addEventListener('input',()=>{if(!searchInput.value.trim())setIntentMode('search')});
  $('#searchPill span')?.addEventListener('click',()=>{searchInput.placeholder='Search, Ask, or Go…';searchInput.focus()});
  $$('.searchBtn[data-screen="Search"]').forEach(btn=>btn.addEventListener('click',()=>setTimeout(()=>{if(searchInput){searchInput.placeholder='Search, Ask, or Go…';searchInput.focus()}},40)));
  intentResult?.addEventListener('click',e=>{const c=e.target.closest('[data-intent-confirm]');if(c){confirmTask(c.dataset.intentConfirm);executeIntent(searchInput.value,'go');return}const x=e.target.closest('[data-intent-cancel]');if(x){dismissTask(x.dataset.intentCancel);setIntentMode('search');return}const card=e.target.closest('[data-intent-card]');if(!card)return;const k=card.dataset.intentCard;if(k==='now')nowDock.click();else if(k==='messages')api.navigate('Inbox');else if(k==='event')makeTask('Create tonight plan',{detail:'Using friends and event context',sensitive:true,kind:'event'});else if(k==='space')openSpace({type:'event',title:'Tonight with friends',context:'Generated from social context'})});

  // Keep assistant rendered whenever route opens.
  const oldApply=api.renderSettingsRoute;window.addEventListener('hashchange',()=>{if(api.parseRoute().screen==='AIBot'){renderTasks();renderMemory();renderPermissions();renderTaskDock()}});
})();
