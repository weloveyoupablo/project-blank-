(() => {
  const storedBase = localStorage.getItem('pngea:apiBase');
  const defaultBase = (location.hostname === 'localhost' || location.hostname === '127.0.0.1')
    ? 'http://localhost:8787'
    : '/api';
  const API_BASE = storedBase || defaultBase;
  const tokenKey = 'pngea:accessToken';
  let refreshPromise = null;

  async function raw(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (!headers.has('Content-Type') && options.body && !(options.body instanceof FormData)) headers.set('Content-Type','application/json');
    const token = localStorage.getItem(tokenKey);
    if (token && options.auth !== false) headers.set('Authorization',`Bearer ${token}`);
    return fetch(`${API_BASE}${path}`, { credentials:'include', ...options, headers });
  }

  async function refreshAccess() {
    if (refreshPromise) return refreshPromise;
    refreshPromise = (async()=>{
      const response = await raw('/v1/auth/refresh',{method:'POST',auth:false});
      if (!response.ok) { localStorage.removeItem(tokenKey); throw new Error('Session expired'); }
      const payload=await response.json();
      if (payload?.accessToken) localStorage.setItem(tokenKey,payload.accessToken);
      return payload;
    })().finally(()=>{refreshPromise=null});
    return refreshPromise;
  }

  async function request(path, options = {}, retry = true) {
    let response = await raw(path,options);
    if (response.status===401 && retry && !path.startsWith('/v1/auth/')) {
      try { await refreshAccess(); response=await raw(path,options); } catch {}
    }
    const payload = response.status===204 ? null : await response.json().catch(()=>null);
    if (!response.ok) {
      const err=new Error(payload?.error?.message || `PNGEA API ${response.status}`);
      err.code=payload?.error?.code || 'API_ERROR'; err.status=response.status; err.details=payload?.error?.details;
      throw err;
    }
    return payload;
  }

  async function authenticate(path,body) {
    const payload=await request(path,{method:'POST',body:JSON.stringify(body),auth:false},false);
    if(payload?.accessToken) localStorage.setItem(tokenKey,payload.accessToken);
    return payload;
  }

  const api = {
    base:API_BASE,
    request,
    setAccessToken(token){token?localStorage.setItem(tokenKey,token):localStorage.removeItem(tokenKey)},
    getAccessToken(){return localStorage.getItem(tokenKey)},
    health:()=>request('/health',{auth:false},false),
    signup:(body)=>authenticate('/v1/auth/signup',body),
    login:(body)=>authenticate('/v1/auth/login',body),
    refresh:()=>refreshAccess(),
    logout:async()=>{try{await request('/v1/auth/logout',{method:'POST'})}finally{localStorage.removeItem(tokenKey)}},
    me:()=>request('/v1/me'),
    myPosts:()=>request('/v1/me/posts'),
    updateProfile:(body)=>request('/v1/me/profile',{method:'PATCH',body:JSON.stringify(body)}),
    getUser:(handle)=>request(`/v1/users/${encodeURIComponent(handle)}`),
    follow:(userId)=>request(`/v1/users/${encodeURIComponent(userId)}/follow`,{method:'POST'}),
    unfollow:(userId)=>request(`/v1/users/${encodeURIComponent(userId)}/follow`,{method:'DELETE'}),
    feed:(params={})=>request(`/v1/feed?${new URLSearchParams(params)}`),
    createPost:(body)=>request('/v1/posts',{method:'POST',body:JSON.stringify(body)}),
    post:(id)=>request(`/v1/posts/${encodeURIComponent(id)}`),
    deletePost:(id)=>request(`/v1/posts/${encodeURIComponent(id)}`,{method:'DELETE'}),
    likePost:(id)=>request(`/v1/posts/${encodeURIComponent(id)}/like`,{method:'PUT'}),
    unlikePost:(id)=>request(`/v1/posts/${encodeURIComponent(id)}/like`,{method:'DELETE'}),
    repost:(id)=>request(`/v1/posts/${encodeURIComponent(id)}/repost`,{method:'PUT'}),
    unrepost:(id)=>request(`/v1/posts/${encodeURIComponent(id)}/repost`,{method:'DELETE'}),
    search:(q)=>request(`/v1/search?q=${encodeURIComponent(q)}`),
    conversations:()=>request('/v1/conversations'),
    createConversation:(body)=>request('/v1/conversations',{method:'POST',body:JSON.stringify(body)}),
    messages:(id)=>request(`/v1/conversations/${encodeURIComponent(id)}/messages`),
    sendMessage:(id,body)=>request(`/v1/conversations/${encodeURIComponent(id)}/messages`,{method:'POST',body:JSON.stringify(body)}),
    markConversationRead:(id)=>request(`/v1/conversations/${encodeURIComponent(id)}/read`,{method:'POST'}),
    notifications:()=>request('/v1/notifications'),
    markNotificationsRead:()=>request('/v1/notifications/read-all',{method:'POST'}),
    markNotificationRead:(id)=>request(`/v1/notifications/${encodeURIComponent(id)}/read`,{method:'POST'}),
    settings:()=>request('/v1/me/settings'),
    updateSettings:(body)=>request('/v1/me/settings',{method:'PATCH',body:JSON.stringify(body)}),
    setPermissions:(body)=>request('/v1/me/permissions',{method:'PATCH',body:JSON.stringify(body)}),
    memories:()=>request('/v1/memory'),
    remember:(body)=>request('/v1/memory',{method:'POST',body:JSON.stringify(body)}),
    forget:(id)=>request(`/v1/memory/${encodeURIComponent(id)}`,{method:'DELETE'}),
    tasks:()=>request('/v1/tasks'),
    createTask:(body)=>request('/v1/tasks',{method:'POST',body:JSON.stringify(body)}),
    confirmTask:(id)=>request(`/v1/tasks/${encodeURIComponent(id)}/confirm`,{method:'POST'}),
    cancelTask:(id)=>request(`/v1/tasks/${encodeURIComponent(id)}/cancel`,{method:'POST'}),
    now:()=>request('/v1/now'),
    ticker:()=>request('/v1/ticker'),
    tickerPreferences:()=>request('/v1/ticker/preferences'),
    updateTickerPreferences:(body)=>request('/v1/ticker/preferences',{method:'PATCH',body:JSON.stringify(body)}),
    report:(body)=>request('/v1/reports',{method:'POST',body:JSON.stringify(body)}),
    createMediaUpload:(body)=>request('/v1/media/uploads',{method:'POST',body:JSON.stringify(body)}),
    completeMedia:(id,body={})=>request(`/v1/media/${encodeURIComponent(id)}/complete`,{method:'POST',body:JSON.stringify(body)}),
    media:(id)=>request(`/v1/media/${encodeURIComponent(id)}`),
    mediaAccess:(id,variant='original')=>request(`/v1/media/${encodeURIComponent(id)}/access?variant=${encodeURIComponent(variant)}`),
    realtimeTicket:()=>request('/v1/realtime/ticket',{method:'POST'})
  };

  window.PNGEA_API=api;
  window.PNGEA_CONFIG=Object.freeze({apiBase:API_BASE,dataMode:localStorage.getItem('pngea:dataMode')||'demo'});

  const mark=(state)=>{
    document.documentElement.dataset.backend=state;
    window.dispatchEvent(new CustomEvent('pngea:backend',{detail:{state,apiBase:API_BASE}}));
  };
  mark('checking');
  api.health().then(()=>mark('ready')).catch(()=>mark('offline'));
})();
