/* PNGEA FOUNDATION v1.1
   Product core is protected; conventional app infrastructure can be replaced/extended freely. */
const screens=[...document.querySelectorAll('.screen')];
const bottom=document.getElementById('bottom');
const sidebar=document.getElementById('sidebar');
const sidebarShade=document.getElementById('sidebarShade');
const youButton=document.getElementById('youButton');
const uiToast=document.getElementById('uiToast');

const PNGEA_ROUTES={
  Home:'home', Search:'search', Inbox:'messages', Notifications:'notifications', Profile:'profile',
  History:'history', Communities:'communities', CloseFriends:'close-friends', Wallet:'wallet', Shop:'shop',
  Now:'now', Dating:'dating', AI:'ai', Settings:'settings', Activity:'activity', Video:'video', Article:'article'
};
const ROUTE_TO_SCREEN=Object.fromEntries(Object.entries(PNGEA_ROUTES).map(([k,v])=>[v,k]));
const STORAGE_KEY='pngea.appState.v1';
const DEFAULT_STATE={
  version:1,
  user:{id:'you',name:'You',handle:'@you'},
  settings:{appearance:'dark',notifications:true,messageNotifications:true,mentionNotifications:true,followNotifications:true,autoplay:true,reducedMotion:false,compactUI:false,feedMode:'balanced',personalizedFeed:true,privateAccount:false,readReceipts:true,discoverability:true},
  social:{following:[],likedPosts:[]},
  search:{history:[]},
  posts:[],
  messages:{
    alex:[{from:'them',text:'That PNGEA message icon finally looks right.'},{from:'me',text:'Finally. Keeping the globe.'},{from:'them',text:'Good. Don’t touch it again.'}],
    maya:[{from:'them',text:'Send me the film review when you post it.'}],
    crew:[{from:'them',text:'Jordan: the sidebar is ready for another pass'}],
    news:[{from:'me',text:'sounds good, I’ll check it tonight'}]
  }
};
function cloneDefault(){return JSON.parse(JSON.stringify(DEFAULT_STATE))}
function loadState(){
  const base=cloneDefault();
  try{
    const raw=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
    if(!raw||typeof raw!=='object') return base;
    return {
      ...base,...raw,
      user:{...base.user,...(raw.user||{})},
      settings:{...base.settings,...(raw.settings||{})},
      social:{...base.social,...(raw.social||{})},
      search:{...base.search,...(raw.search||{})},
      messages:{...base.messages,...(raw.messages||{})},
      posts:Array.isArray(raw.posts)?raw.posts:[]
    };
  }catch{return base}
}
const appState=loadState();
function saveState(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(appState))}catch{}}
function toast(text){if(!uiToast)return;uiToast.textContent=text;uiToast.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>uiToast.classList.remove('show'),1500)}

function routeFor(screen,detail){
  const base=PNGEA_ROUTES[screen]||'home';
  return '#/'+base+(detail?'/'+encodeURIComponent(detail):'');
}
function parseRoute(){
  const raw=(location.hash||'#/home').replace(/^#\/?/,'');
  const parts=raw.split('/').filter(Boolean).map(decodeURIComponent);
  return {screen:ROUTE_TO_SCREEN[parts[0]]||'Home',detail:parts[1]||null};
}
function renderScreen(id,{resetHomeScroll=false}={}){
  if(!document.getElementById(id)) id='Home';
  screens.forEach(s=>s.classList.toggle('active',s.id===id));
  bottom.style.display=['Home','Inbox','Notifications'].includes(id)?'flex':'none';
  document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.screen===id));
  if(id==='Home'&&resetHomeScroll){const f=document.getElementById('feed');if(f)f.scrollTop=0}
}
function navigate(screen,detail=null,{replace=false}={}){
  const hash=routeFor(screen,detail);
  if(location.hash===hash){applyRoute();return}
  if(replace) history.replaceState(null,'',hash); else history.pushState(null,'',hash);
  applyRoute();
}
function openScreen(id,opts={}){navigate(id,null,opts)}
function applyRoute(){
  const route=parseRoute();
  renderScreen(route.screen);
  closeSidebar();
  if(window.PNGEA?.renderThreadRoute) window.PNGEA.renderThreadRoute(route);
  if(window.PNGEA?.renderSettingsRoute) window.PNGEA.renderSettingsRoute(route);
}
window.addEventListener('popstate',applyRoute);
window.addEventListener('hashchange',applyRoute);

document.querySelectorAll('[data-screen]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault();navigate(el.dataset.screen)}));
function openSidebar(){sidebar.classList.add('show');sidebarShade.classList.add('show')}
function closeSidebar(){sidebar.classList.remove('show');sidebarShade.classList.remove('show')}
youButton.addEventListener('click',openSidebar);
document.getElementById('sideClose').addEventListener('click',closeSidebar);
sidebarShade.addEventListener('click',closeSidebar);
document.querySelectorAll('[data-side-screen]').forEach(el=>el.addEventListener('click',()=>navigate(el.dataset.sideScreen)));
let sideTouchX=null;
sidebar.addEventListener('touchstart',e=>{sideTouchX=e.touches[0].clientX},{passive:true});
sidebar.addEventListener('touchend',e=>{if(sideTouchX!==null&&e.changedTouches[0].clientX-sideTouchX<-65)closeSidebar();sideTouchX=null},{passive:true});

function tick(){
  const d=new Date(),date=d.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'}).toUpperCase(),time=d.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'});
  document.querySelectorAll('.tickerTime').forEach(x=>x.textContent=`${date} · ${time}`);
  document.querySelectorAll('.clock').forEach(x=>x.textContent=time)
}
tick();setInterval(tick,1000);

document.addEventListener('click',e=>{
  const x=e.target.closest('.like');
  if(x){x.classList.toggle('activeAction');x.textContent=x.classList.contains('activeAction')?'♥ liked':'♡ like'}
});

// Core composer: posts now persist locally so backend wiring can replace storage later without changing UI.
const layer=document.getElementById('composerLayer'),textarea=document.getElementById('postText'),detected=document.getElementById('detected'),send=document.getElementById('send'),preview=document.getElementById('attachPreview'),ptype=document.getElementById('previewType'),ptitle=document.getElementById('previewTitle');
let attachment=null;
document.getElementById('compose').onclick=()=>{layer.classList.add('show');setTimeout(()=>textarea.focus(),80)};
function detect(){const t=textarea.value.trim();let d='ANYTHING';if(attachment==='photo')d='PHOTO READY';else if(attachment==='video')d='VIDEO READY';else if(attachment==='voice')d='VOICE NOTE READY';else if(attachment==='link'||/https?:\/\//i.test(t))d='LINK PREVIEW READY';else if(t.length>420)d='LONG FORM';else if(t)d='TEXT';detected.textContent=d;send.disabled=!t&&!attachment}
function resetComposer(){layer.classList.remove('show');textarea.value='';attachment=null;preview.classList.remove('show');detect()}
document.getElementById('closeComposer').onclick=resetComposer;
document.getElementById('removeAttach').onclick=()=>{attachment=null;preview.classList.remove('show');detect()};
textarea.addEventListener('input',detect);
document.querySelectorAll('[data-attach]').forEach(el=>el.onclick=()=>{attachment=el.dataset.attach;preview.classList.add('show');ptype.textContent=attachment.toUpperCase();ptitle.textContent=attachment==='photo'?'Photo attached':attachment==='video'?'Video attached':attachment==='voice'?'Voice note attached':'Link preview generated';detect()});
function localPostElement(post){
  const art=document.createElement('article');art.className='bubble';art.dataset.localPost=post.id;
  art.innerHTML=`<div class="authorRow"><div class="avatar">YOU</div><div class="authorCopy"><div class="authorNameLine"><span class="authorName">You</span></div><span class="meta">@you · ${post.createdLabel||'now'}</span></div><span class="more">•••</span></div><div class="body"></div><div class="actions"><span>◯ 0</span><span>⇄ 0</span><span class="action like">♡ 0</span><span>↗</span></div>`;
  art.querySelector('.body').textContent=post.text||({photo:'Shared a photo',video:'Shared a video',voice:'Shared a voice note',link:'Shared a link'}[post.attachment]||'New post');
  return art;
}
function renderLocalPosts(){
  document.querySelectorAll('[data-local-post]').forEach(n=>n.remove());
  const feed=document.getElementById('feed'),anchor=document.querySelector('.streamLabel')?.nextSibling;
  if(!feed)return;
  [...appState.posts].reverse().forEach(post=>feed.insertBefore(localPostElement(post),anchor||feed.firstChild));
}
send.onclick=()=>{
  const t=textarea.value.trim();if(!t&&!attachment)return;
  appState.posts.push({id:'p'+Date.now(),text:t,attachment,createdAt:Date.now(),createdLabel:'now'});saveState();renderLocalPosts();resetComposer();navigate('Home');toast('Posted');
};

function setScreenState(screenId,state,message=''){
  const screen=document.getElementById(screenId);if(!screen)return;
  screen.dataset.uiState=state;
  if(message) screen.dataset.uiMessage=message;
}

window.PNGEA={
  state:appState,save:saveState,navigate,openScreen,routeFor,parseRoute,toast,setScreenState,
  routes:PNGEA_ROUTES,renderThreadRoute:null,renderSettingsRoute:null
};
renderLocalPosts();
if(!location.hash) history.replaceState(null,'',routeFor('Home'));
applyRoute();
