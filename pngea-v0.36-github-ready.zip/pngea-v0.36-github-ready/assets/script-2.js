(() => {
  const canvas = document.querySelector('.messageGlobeCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const cx = W / 2, cy = H / 2, R = 26, cam = 120;
  const longitudes = 16, latitudes = [-70,-45,-20,0,20,45,70];
  const axisTilt = 23.5 * Math.PI / 180;
  const perspectiveTilt = -10 * Math.PI / 180;
  const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const nav = canvas.closest('.nav');
  let startTime = performance.now();

  function rotY(x,y,z,a){ return [x*Math.cos(a)+z*Math.sin(a), y, -x*Math.sin(a)+z*Math.cos(a)]; }
  function rotZ(x,y,z,a){ return [x*Math.cos(a)-y*Math.sin(a), x*Math.sin(a)+y*Math.cos(a), z]; }
  function rotX(x,y,z,a){ return [x, y*Math.cos(a)-z*Math.sin(a), y*Math.sin(a)+z*Math.cos(a)]; }
  function orient(x,y,z,spin){ [x,y,z]=rotY(x,y,z,spin); [x,y,z]=rotZ(x,y,z,-axisTilt); [x,y,z]=rotX(x,y,z,perspectiveTilt); return [x,y,z]; }
  function project(x,y,z){ const s = cam/(cam-z); return [cx+x*s, cy+y*s, z]; }
  function ink(alpha){ return (nav && nav.classList.contains('active')) ? `rgba(8,8,8,${alpha})` : `rgba(255,255,255,${alpha})`; }
  function drawPath(points, dashed=false){
    if(points.length<2) return;
    ctx.beginPath();
    ctx.setLineDash(dashed ? [1.8,2.2] : []);
    ctx.moveTo(points[0][0], points[0][1]);
    for(let i=1;i<points.length;i++) ctx.lineTo(points[i][0], points[i][1]);
    const avgz = points.reduce((a,p)=>a+p[2],0)/points.length;
    const depth = (avgz + R)/(2*R);
    ctx.lineWidth = dashed ? 0.95 : 1.15;
    ctx.strokeStyle = ink(dashed ? (.16 + .20*depth) : (.42 + .56*depth));
    ctx.stroke();
  }

  function traceMeridian(lambda, spin, front){
    let seg=[];
    for(let i=0;i<=120;i++){
      const phi = -Math.PI/2 + (i/120)*Math.PI;
      let p = orient(R*Math.cos(phi)*Math.cos(lambda), R*Math.sin(phi), R*Math.cos(phi)*Math.sin(lambda), spin);
      p = project(p[0],p[1],p[2]);
      const visible = front ? p[2] >= 0 : p[2] < 0;
      if(visible) seg.push(p); else { if(seg.length>1) drawPath(seg,!front); seg=[]; }
    }
    if(seg.length>1) drawPath(seg,!front);
  }
  function traceLatitude(deg, spin, front){
    const rr = R*Math.cos(deg*Math.PI/180), yy = R*Math.sin(deg*Math.PI/180);
    let seg=[];
    for(let i=0;i<=140;i++){
      const th=(i/140)*Math.PI*2;
      let p = orient(rr*Math.cos(th), yy, rr*Math.sin(th), spin);
      p = project(p[0],p[1],p[2]);
      const visible = front ? p[2] >= 0 : p[2] < 0;
      if(visible) seg.push(p); else { if(seg.length>1) drawPath(seg,!front); seg=[]; }
    }
    if(seg.length>1) drawPath(seg,!front);
  }

  function render(t){
    const spin = reduced ? 0.82 : ((t-startTime)/22000)*Math.PI*2;
    const active = nav && nav.classList.contains('active');
    ctx.clearRect(0,0,W,H);

    if(!active){
      const glow = ctx.createRadialGradient(cx,cy,4,cx,cy,R+8);
      glow.addColorStop(0,'rgba(255,255,255,.10)');
      glow.addColorStop(.65,'rgba(255,255,255,.035)');
      glow.addColorStop(1,'rgba(255,255,255,0)');
      ctx.fillStyle = glow;
      ctx.beginPath(); ctx.arc(cx,cy,R+7,0,Math.PI*2); ctx.fill();
    }

    // rear grid, faint but continuous so lines don't vanish halfway
    for(let j=0;j<longitudes;j++) traceMeridian((j/longitudes)*Math.PI*2, spin, false);
    for(const deg of latitudes) traceLatitude(deg, spin, false);

    // front grid
    for(let j=0;j<longitudes;j++) traceMeridian((j/longitudes)*Math.PI*2, spin, true);
    for(const deg of latitudes) traceLatitude(deg, spin, true);

    ctx.beginPath();
    ctx.setLineDash([]);
    ctx.arc(cx,cy,R,0,Math.PI*2);
    ctx.lineWidth = 1.15;
    ctx.strokeStyle = active ? 'rgba(8,8,8,.84)' : 'rgba(255,255,255,.80)';
    ctx.stroke();

    if(!reduced) requestAnimationFrame(render);
  }
  requestAnimationFrame(render);
})();
