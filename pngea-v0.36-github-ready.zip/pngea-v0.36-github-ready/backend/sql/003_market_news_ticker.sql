begin;

create table if not exists market_quotes(
  symbol text primary key,
  asset_type text not null default 'equity',
  currency text not null default 'USD',
  last_price numeric,
  previous_close numeric,
  change_amount numeric,
  change_percent numeric,
  feed text not null,
  delayed boolean not null default false,
  source text not null,
  as_of timestamptz not null,
  raw jsonb not null default '{}',
  updated_at timestamptz not null default now()
);
create index if not exists market_quotes_asof_idx on market_quotes(as_of desc);

create table if not exists external_news_articles(
  id text primary key,
  provider text not null,
  provider_item_id text not null,
  source_name text not null,
  headline text not null,
  summary text not null default '',
  url text,
  author text,
  symbols text[] not null default '{}',
  topics text[] not null default '{}',
  story_key text not null,
  importance smallint not null default 50 check(importance between 0 and 100),
  verification_status text not null default 'single_source' check(verification_status in('single_source','corroborated','official')),
  source_weight numeric(4,3) not null default 0.700 check(source_weight between 0 and 1),
  status text not null default 'active' check(status in('active','corrected','retracted')),
  correction_note text,
  published_at timestamptz not null,
  updated_at timestamptz,
  raw jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique(provider,provider_item_id)
);
create index if not exists external_news_published_idx on external_news_articles(published_at desc);
create index if not exists external_news_story_idx on external_news_articles(story_key,published_at desc);
create index if not exists external_news_symbols_idx on external_news_articles using gin(symbols);
create index if not exists external_news_topics_idx on external_news_articles using gin(topics);

create table if not exists user_ticker_preferences(
  user_id text primary key references users(id) on delete cascade,
  enabled boolean not null default true,
  categories text[] not null default array['you','news','markets','live']::text[],
  symbols text[] not null default array['SPY','QQQ','DIA','IWM']::text[],
  topics text[] not null default '{}',
  max_items smallint not null default 8 check(max_items between 3 and 20),
  updated_at timestamptz not null default now()
);

create table if not exists news_ingest_audit(
  id bigserial primary key,
  provider text not null,
  source_name text not null,
  provider_item_id text,
  accepted boolean not null,
  reason text,
  received_at timestamptz not null default now()
);
create index if not exists news_ingest_audit_time_idx on news_ingest_audit(received_at desc);

commit;
