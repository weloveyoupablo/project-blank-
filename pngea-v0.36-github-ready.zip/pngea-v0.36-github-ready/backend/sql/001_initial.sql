begin;
create extension if not exists pgcrypto;

create table if not exists users(
  id text primary key,
  email text not null unique,
  password_hash text not null,
  status text not null check(status in('active','suspended','disabled','deleted')) default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists profiles(
  user_id text primary key references users(id) on delete cascade,
  handle text not null unique check(handle ~ '^[a-z0-9_]{3,30}$'),
  display_name text not null,
  bio text not null default '',
  avatar_url text,
  banner_url text,
  search_document tsvector generated always as (to_tsvector('simple',coalesce(handle,'')||' '||coalesce(display_name,'')||' '||coalesce(bio,''))) stored,
  updated_at timestamptz not null default now()
);
create index if not exists profiles_search_idx on profiles using gin(search_document);

create table if not exists sessions(
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  refresh_token_hash text not null unique,
  user_agent text,
  ip_address inet,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  revoked_at timestamptz
);
create index if not exists sessions_user_idx on sessions(user_id,created_at desc);

create table if not exists user_settings(
  user_id text primary key references users(id) on delete cascade,
  private_account boolean not null default false,
  allow_message_requests boolean not null default true,
  show_activity_status boolean not null default true,
  feed_order text not null default 'recommended',
  reduced_motion boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists user_permissions(
  user_id text not null references users(id) on delete cascade,
  permission_key text not null check(permission_key in('smart_memory','memory_training','commercial_sharing','personalization')),
  value boolean not null,
  policy_version text not null,
  updated_at timestamptz not null default now(),
  primary key(user_id,permission_key)
);

create table if not exists follows(
  follower_id text not null references users(id) on delete cascade,
  followee_id text not null references users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id,followee_id),
  check(follower_id<>followee_id)
);
create index if not exists follows_followee_idx on follows(followee_id,created_at desc);

create table if not exists blocks(
  blocker_id text not null references users(id) on delete cascade,
  blocked_id text not null references users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id,blocked_id),
  check(blocker_id<>blocked_id)
);

create table if not exists posts(
  id text primary key,
  author_id text not null references users(id) on delete cascade,
  text text not null default '',
  visibility text not null check(visibility in('public','followers','close_friends','private')) default 'public',
  reply_to_id text references posts(id) on delete set null,
  quote_post_id text references posts(id) on delete set null,
  search_document tsvector generated always as (to_tsvector('simple',coalesce(text,''))) stored,
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz
);
create index if not exists posts_author_time_idx on posts(author_id,created_at desc) where deleted_at is null;
create index if not exists posts_time_idx on posts(created_at desc) where deleted_at is null;
create index if not exists posts_search_idx on posts using gin(search_document);

create table if not exists post_reactions(
  user_id text not null references users(id) on delete cascade,
  post_id text not null references posts(id) on delete cascade,
  reaction text not null check(reaction in('like')),
  created_at timestamptz not null default now(),
  primary key(user_id,post_id,reaction)
);
create table if not exists reposts(
  user_id text not null references users(id) on delete cascade,
  post_id text not null references posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,post_id)
);

create table if not exists media(
  id text primary key,
  owner_user_id text not null references users(id) on delete cascade,
  post_id text references posts(id) on delete set null,
  object_key text not null unique,
  mime_type text not null,
  byte_size bigint not null,
  width int,
  height int,
  duration_ms int,
  status text not null check(status in('pending','ready','blocked','failed')) default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists conversations(
  id text primary key,
  title text,
  created_by text references users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists conversation_members(
  conversation_id text not null references conversations(id) on delete cascade,
  user_id text not null references users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  left_at timestamptz,
  last_read_at timestamptz,
  primary key(conversation_id,user_id)
);
create index if not exists conversation_members_user_idx on conversation_members(user_id,conversation_id) where left_at is null;
create table if not exists messages(
  id text primary key,
  conversation_id text not null references conversations(id) on delete cascade,
  sender_id text not null references users(id) on delete cascade,
  text text not null default '',
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz
);
create index if not exists messages_conv_time_idx on messages(conversation_id,created_at);

create table if not exists notifications(
  id bigserial primary key,
  user_id text not null references users(id) on delete cascade,
  actor_user_id text references users(id) on delete cascade,
  kind text not null,
  object_type text,
  object_id text,
  payload jsonb not null default '{}',
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index if not exists notifications_user_time_idx on notifications(user_id,created_at desc);
create index if not exists notifications_unread_idx on notifications(user_id) where read_at is null;

create table if not exists memories(
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  source_object_type text not null,
  source_object_id text not null,
  permission_scope text not null default 'private',
  reason_saved text not null check(reason_saved in('explicit','smart_memory')),
  summary text,
  embedding jsonb,
  created_at timestamptz not null default now(),
  forgotten_at timestamptz,
  unique(user_id,source_object_type,source_object_id)
);
-- Upgrade embedding to pgvector when the memory retrieval service is introduced.

create table if not exists tasks(
  id text primary key,
  user_id text not null references users(id) on delete cascade,
  kind text not null,
  title text not null,
  payload jsonb not null default '{}',
  status text not null check(status in('queued','running','waiting_for_user','completed','failed','cancelled')),
  requires_confirmation boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz
);
create index if not exists tasks_user_idx on tasks(user_id,created_at desc);

create table if not exists now_events(
  id bigserial primary key,
  user_id text references users(id) on delete cascade,
  kind text not null,
  title text not null,
  payload jsonb not null default '{}',
  priority int not null default 0,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists now_events_live_idx on now_events(expires_at,priority desc);

create table if not exists reports(
  id text primary key,
  reporter_user_id text not null references users(id) on delete cascade,
  object_type text not null,
  object_id text not null,
  reason text not null,
  details text,
  status text not null check(status in('open','reviewing','resolved','dismissed','appealed')) default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists reports_queue_idx on reports(status,created_at);

create table if not exists moderation_actions(
  id bigserial primary key,
  moderator_user_id text references users(id) on delete set null,
  object_type text not null,
  object_id text not null,
  action text not null,
  reason text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists audit_log(
  id bigserial primary key,
  actor_user_id text references users(id) on delete set null,
  action text not null,
  object_type text,
  object_id text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists audit_actor_idx on audit_log(actor_user_id,created_at desc);

commit;
