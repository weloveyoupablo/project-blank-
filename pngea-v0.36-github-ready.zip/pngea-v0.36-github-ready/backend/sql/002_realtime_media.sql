begin;

create table if not exists close_friends(
  user_id text not null references users(id) on delete cascade,
  friend_user_id text not null references users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,friend_user_id),
  check(user_id<>friend_user_id)
);
create index if not exists close_friends_friend_idx on close_friends(friend_user_id,user_id);

alter table media add column if not exists original_filename text;
alter table media add column if not exists sha256 text;
alter table media add column if not exists updated_at timestamptz not null default now();
alter table media add column if not exists moderation_state text not null default 'unchecked';
alter table media drop constraint if exists media_status_check;
alter table media add constraint media_status_check check(status in('pending','uploading','processing','ready','blocked','failed'));

create table if not exists media_variants(
  id text primary key,
  media_id text not null references media(id) on delete cascade,
  kind text not null,
  object_key text not null unique,
  mime_type text not null,
  byte_size bigint,
  width int,
  height int,
  bitrate int,
  created_at timestamptz not null default now(),
  unique(media_id,kind)
);
create index if not exists media_variants_media_idx on media_variants(media_id);

create table if not exists media_jobs(
  id bigserial primary key,
  media_id text not null references media(id) on delete cascade,
  kind text not null,
  status text not null check(status in('queued','running','completed','failed')) default 'queued',
  attempts int not null default 0,
  last_error text,
  available_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists media_jobs_queue_idx on media_jobs(status,available_at,id);

create table if not exists message_media(
  message_id text not null references messages(id) on delete cascade,
  media_id text not null references media(id) on delete cascade,
  position int not null default 0,
  primary key(message_id,media_id)
);
create index if not exists message_media_media_idx on message_media(media_id,message_id);

create index if not exists media_post_idx on media(post_id) where post_id is not null;
create index if not exists media_owner_idx on media(owner_user_id,created_at desc);

commit;
