import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from '../src/lib/db.js';

const here=path.dirname(fileURLToPath(import.meta.url));
const dir=path.resolve(here,'../sql');
const files=(await fs.readdir(dir)).filter(f=>/^\d+.*\.sql$/.test(f)).sort();

try {
  await db.query(`create table if not exists schema_migrations(filename text primary key,applied_at timestamptz not null default now())`);
  for (const file of files) {
    const exists=await db.query(`select 1 from schema_migrations where filename=$1`,[file]);
    if (exists.rowCount) { console.log(`skip ${file}`); continue; }
    const sql=await fs.readFile(path.join(dir,file),'utf8');
    await db.query(sql);
    await db.query(`insert into schema_migrations(filename) values($1) on conflict do nothing`,[file]);
    console.log(`applied ${file}`);
  }
  console.log('migrations complete');
} finally { await db.end(); }
