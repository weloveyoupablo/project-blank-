import test from 'node:test';
import assert from 'node:assert/strict';
import { diversify, estimateImportance, inferTopics, marketScore, newsScore } from '../src/lib/ticker-ranker.js';

test('diversify avoids long same-kind runs',()=>{
  const out=diversify([
    {key:'n1',kind:'news',score:10},{key:'n2',kind:'news',score:9},{key:'n3',kind:'news',score:8},
    {key:'m1',kind:'markets',score:7},{key:'l1',kind:'live',score:6}
  ],5);
  assert.equal(out.length,5);
  assert.notEqual(out.slice(0,3).every(x=>x.kind==='news'),true);
});

test('important macro headlines outrank routine headlines',()=>{
  assert.ok(estimateImportance('Federal Reserve announces emergency rate cut')>estimateImportance('Company opens a new office'));
});

test('topic inference catches economy and technology',()=>{
  const t=inferTopics('AI chip company reacts to inflation report','Federal Reserve rates remain unchanged');
  assert.ok(t.includes('technology'));
  assert.ok(t.includes('economy'));
});

test('watched fresh market quote gets a useful score',()=>{
  const score=marketScore({symbol:'SPY',change_percent:1.2,as_of:new Date().toISOString()},{symbols:['SPY']});
  assert.ok(score>.5);
});

test('personal relevance lifts news',()=>{
  const a={importance:55,published_at:new Date().toISOString(),verification_status:'single_source',symbols:['AAPL'],topics:[]};
  assert.ok(newsScore(a,{symbols:['AAPL']})>newsScore(a,{symbols:['MSFT']}));
});
