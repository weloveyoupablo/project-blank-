import { startAlpacaStreams } from './providers/alpaca-stream.js';

process.on('unhandledRejection',err=>{console.error(err);process.exitCode=1});
process.on('SIGTERM',()=>process.exit(0));
process.on('SIGINT',()=>process.exit(0));

await startAlpacaStreams();
