import crypto from 'node:crypto';
import WebSocket from 'ws';
import { db } from '../lib/db.js';
import { publishGlobal } from '../lib/events.js';
import { config } from '../config.js';
import { estimateImportance,inferTopics } from '../lib/ticker-ranker.js';

const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const normalized=s=>String(s).toLowerCase().replace(/[^a-z0-9\s]/g,' ').replace(/\b(update|breaking|exclusive|live)\b/g,' ').replace(/\s+/g,' ').trim();
const storyKey=s=>crypto.createHash('sha1').update(normalized(s)).digest('hex');
const symbols=()=>config.marketSymbols.filter(Boolean);
let lastBroadcast=0,broadcastTimer=null;

async function broadcastNow(){
  lastBroadcast=Date.now();broadcastTimer=null;
  try{await publishGlobal('ticker.updated',{at:new Date().toISOString()})}catch(err){console.error('ticker broadcast failed',err.message)}
}
function broadcastSoon(){
  const wait=Math.max(0,5000-(Date.now()-lastBroadcast));
  if(wait===0){void broadcastNow();return}
  if(!broadcastTimer)broadcastTimer=setTimeout(()=>void broadcastNow(),wait);
}

async function seedSnapshots(){
  if(!config.alpacaKey||!config.alpacaSecret||!symbols().length)return;
  const u=new URL('https://data.alpaca.markets/v2/stocks/snapshots');
  u.searchParams.set('symbols',symbols().join(','));u.searchParams.set('feed',config.alpacaFeed);
  const res=await fetch(u,{headers:{'APCA-API-KEY-ID':config.alpacaKey,'APCA-API-SECRET-KEY':config.alpacaSecret}});
  if(!res.ok)throw new Error(`Alpaca snapshots ${res.status}: ${await res.text()}`);
  const data=await res.json();
  for(const [symbol,s] of Object.entries(data||{})){
    const last=s.latestTrade?.p??s.minuteBar?.c??s.dailyBar?.c??null,prev=s.prevDailyBar?.c??null;
    const change=last!=null&&prev!=null?Number(last)-Number(prev):null;
    const pct=change!=null&&Number(prev)!==0?change/Number(prev)*100:null;
    const asOf=s.latestTrade?.t||s.minuteBar?.t||s.dailyBar?.t||new Date().toISOString();
    await db.query(`insert into market_quotes(symbol,last_price,previous_close,change_amount,change_percent,feed,delayed,source,as_of,raw)
      values($1,$2,$3,$4,$5,$6,$7,'alpaca',$8,$9::jsonb)
      on conflict(symbol) do update set last_price=excluded.last_price,previous_close=excluded.previous_close,change_amount=excluded.change_amount,change_percent=excluded.change_percent,feed=excluded.feed,delayed=excluded.delayed,source=excluded.source,as_of=excluded.as_of,raw=excluded.raw,updated_at=now()`,[symbol,last,prev,change,pct,config.alpacaFeed,config.alpacaFeed==='delayed_sip',asOf,JSON.stringify(s)]);
  }
  broadcastSoon();
}

async function handleTrade(m){
  if(m.T!=='t'||!m.S||m.p==null)return;
  const {rows}=await db.query(`select previous_close from market_quotes where symbol=$1`,[m.S]);
  const prev=rows[0]?.previous_close??null,change=prev==null?null:Number(m.p)-Number(prev),pct=change==null||Number(prev)===0?null:change/Number(prev)*100;
  await db.query(`insert into market_quotes(symbol,last_price,previous_close,change_amount,change_percent,feed,delayed,source,as_of,raw)
    values($1,$2,$3,$4,$5,$6,$7,'alpaca',$8,$9::jsonb)
    on conflict(symbol) do update set last_price=excluded.last_price,change_amount=excluded.change_amount,change_percent=excluded.change_percent,feed=excluded.feed,delayed=excluded.delayed,source=excluded.source,as_of=excluded.as_of,raw=excluded.raw,updated_at=now()`,[m.S,m.p,prev,change,pct,config.alpacaFeed,config.alpacaFeed==='delayed_sip',m.t||new Date().toISOString(),JSON.stringify(m)]);
  broadcastSoon();
}

async function handleNews(m){
  if(m.T!=='n'||!m.id||!m.headline)return;
  const key=storyKey(m.headline),topics=inferTopics(m.headline,m.summary||''),importance=estimateImportance(m.headline);
  const id=`alpaca_${m.id}`;
  await db.query(`insert into external_news_articles(id,provider,provider_item_id,source_name,headline,summary,url,author,symbols,topics,story_key,importance,verification_status,source_weight,status,published_at,updated_at,raw)
    values($1,'alpaca',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'single_source',0.700,'active',$12,$13,$14::jsonb)
    on conflict(provider,provider_item_id) do update set headline=excluded.headline,summary=excluded.summary,url=excluded.url,author=excluded.author,symbols=excluded.symbols,topics=excluded.topics,importance=excluded.importance,updated_at=excluded.updated_at,raw=excluded.raw`,[id,String(m.id),m.source||'market news',m.headline,m.summary||'',m.url||null,m.author||null,(m.symbols||[]).map(x=>String(x).toUpperCase()),topics,key,importance,m.created_at||new Date().toISOString(),m.updated_at||null,JSON.stringify(m)]);
  await db.query(`update external_news_articles set verification_status='corroborated' where story_key=$1 and verification_status<>'official' and (select count(distinct source_name) from external_news_articles where story_key=$1 and published_at>now()-interval '24 hours')>1`,[key]);
  broadcastSoon();
}

function connect(url,onData,subscribe){
  return new Promise((resolve,reject)=>{
    const ws=new WebSocket(url);
    let authed=false;
    ws.on('open',()=>ws.send(JSON.stringify({action:'auth',key:config.alpacaKey,secret:config.alpacaSecret})));
    ws.on('message',async raw=>{
      let list;try{list=JSON.parse(raw.toString())}catch{return}
      if(!Array.isArray(list))list=[list];
      for(const m of list){
        if(m.T==='success'&&m.msg==='authenticated'&&!authed){authed=true;ws.send(JSON.stringify(subscribe));continue}
        if(m.T==='error'){ws.close();reject(new Error(`Alpaca stream error ${m.code||''}: ${m.msg||'unknown'}`));return}
        try{await onData(m)}catch(err){console.error('stream message error',err)}
      }
    });
    ws.on('close',()=>resolve());ws.on('error',reject);
  });
}

async function runForever(name,url,onData,subscribe){
  let backoff=1500;
  for(;;){
    try{console.log(`[${name}] connecting ${url}`);await connect(url,onData,subscribe);backoff=1500;await sleep(1000)}
    catch(err){console.error(`[${name}]`,err.message);await sleep(backoff);backoff=Math.min(backoff*1.8,30000)}
  }
}

export async function startAlpacaStreams(){
  if(config.marketProvider!=='alpaca'){console.warn(`MARKET_DATA_PROVIDER=${config.marketProvider} has no worker adapter yet; worker idle.`);return new Promise(()=>{})}
  if(!config.alpacaKey||!config.alpacaSecret){console.warn('ALPACA credentials missing; market/news worker idle.');return new Promise(()=>{})}
  await seedSnapshots().catch(err=>console.error('snapshot seed failed',err.message));
  setInterval(()=>seedSnapshots().catch(err=>console.error('snapshot refresh failed',err.message)),60_000).unref();
  const syms=symbols();
  await Promise.all([
    runForever('markets',`wss://stream.data.alpaca.markets/v2/${config.alpacaFeed}`,handleTrade,{action:'subscribe',trades:syms}),
    runForever('market-news','wss://stream.data.alpaca.markets/v1beta1/news',handleNews,{action:'subscribe',news:['*']})
  ]);
}
