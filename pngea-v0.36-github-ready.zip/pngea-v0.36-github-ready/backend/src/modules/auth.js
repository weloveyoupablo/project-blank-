import argon2 from 'argon2';
import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { ApiError } from '../lib/errors.js';
import { opaqueId, randomToken, sha256 } from '../lib/security.js';
import { audit } from '../lib/audit.js';
import { config } from '../config.js';

const signupSchema = z.object({
  email: z.string().email().max(320),
  password: z.string().min(10).max(256),
  handle: z.string().regex(/^[A-Za-z0-9_]{3,30}$/),
  displayName: z.string().trim().min(1).max(80)
});
const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });

function cookieOptions() {
  return {
    path:'/v1/auth',
    httpOnly:true,
    secure:config.cookieSecure,
    sameSite:config.cookieSameSite,
    domain:config.cookieDomain,
    maxAge:config.refreshTokenDays * 24 * 60 * 60
  };
}

async function createSession(app, userId, meta = {}) {
  const refresh = randomToken(48);
  const sessionId = opaqueId('sess');
  await db.query(
    `insert into sessions(id,user_id,refresh_token_hash,user_agent,ip_address,expires_at)
     values($1,$2,$3,$4,$5,now()+($6||' days')::interval)`,
    [sessionId,userId,sha256(refresh),meta.userAgent||null,meta.ip||null,String(config.refreshTokenDays)]
  );
  return { accessToken:app.jwt.sign({ sub:userId,sid:sessionId }), refreshToken:refresh, sessionId };
}

async function rotateSession(app, refreshToken) {
  if (!refreshToken) throw new ApiError(401,'REFRESH_REQUIRED','Session refresh required.');
  const hash=sha256(refreshToken);
  const {rows}=await db.query(
    `select s.id,s.user_id,u.status from sessions s join users u on u.id=s.user_id
     where s.refresh_token_hash=$1 and s.revoked_at is null and s.expires_at>now()`,[hash]
  );
  const session=rows[0];
  if (!session || session.status!=='active') throw new ApiError(401,'SESSION_EXPIRED','Session is no longer valid.');
  const next=randomToken(48);
  await db.query(
    `update sessions set refresh_token_hash=$2,expires_at=now()+($3||' days')::interval where id=$1`,
    [session.id,sha256(next),String(config.refreshTokenDays)]
  );
  return { accessToken:app.jwt.sign({ sub:session.user_id,sid:session.id }), refreshToken:next, userId:session.user_id };
}

function setRefreshCookie(reply,token) {
  reply.setCookie(config.refreshCookieName,token,cookieOptions());
}
function clearRefreshCookie(reply) {
  reply.clearCookie(config.refreshCookieName,cookieOptions());
}

export async function registerAuth(app) {
  app.post('/v1/auth/signup', { config:{ rateLimit:{ max:8,timeWindow:'1 minute' } } }, async (req,reply)=>{
    const body=signupSchema.parse(req.body);
    const email=body.email.toLowerCase(),handle=body.handle.toLowerCase();
    const passwordHash=await argon2.hash(body.password,{type:argon2.argon2id});
    const userId=opaqueId('usr');
    try {
      await tx(async client=>{
        await client.query(`insert into users(id,email,password_hash,status) values($1,$2,$3,'active')`,[userId,email,passwordHash]);
        await client.query(`insert into profiles(user_id,handle,display_name) values($1,$2,$3)`,[userId,handle,body.displayName]);
        await client.query(`insert into user_settings(user_id) values($1)`,[userId]);
      });
    } catch (e) {
      if (e.code==='23505') throw new ApiError(409,'ACCOUNT_EXISTS','Email or handle is already in use.');
      throw e;
    }
    await audit({actorUserId:userId,action:'account.created',objectType:'user',objectId:userId});
    const session=await createSession(app,userId,{userAgent:req.headers['user-agent'],ip:req.ip});
    setRefreshCookie(reply,session.refreshToken);
    reply.code(201).send({userId,accessToken:session.accessToken,expiresIn:config.accessTokenTtl});
  });

  app.post('/v1/auth/login',{config:{rateLimit:{max:12,timeWindow:'1 minute'}}},async (req,reply)=>{
    const body=loginSchema.parse(req.body);
    const {rows}=await db.query(`select id,password_hash,status from users where email=$1`,[body.email.toLowerCase()]);
    const user=rows[0];
    if (!user || !(await argon2.verify(user.password_hash,body.password))) throw new ApiError(401,'INVALID_CREDENTIALS','Invalid email or password.');
    if (user.status!=='active') throw new ApiError(403,'ACCOUNT_UNAVAILABLE','This account is not currently active.');
    await audit({actorUserId:user.id,action:'auth.login'});
    const session=await createSession(app,user.id,{userAgent:req.headers['user-agent'],ip:req.ip});
    setRefreshCookie(reply,session.refreshToken);
    return {accessToken:session.accessToken,expiresIn:config.accessTokenTtl};
  });

  app.post('/v1/auth/refresh',{config:{rateLimit:{max:30,timeWindow:'1 minute'}}},async (req,reply)=>{
    const rotated=await rotateSession(app,req.cookies?.[config.refreshCookieName]);
    setRefreshCookie(reply,rotated.refreshToken);
    return {accessToken:rotated.accessToken,expiresIn:config.accessTokenTtl};
  });

  app.post('/v1/auth/logout',{preHandler:[app.authenticate]},async (req,reply)=>{
    await db.query(`update sessions set revoked_at=now() where id=$1 and user_id=$2`,[req.user.sid,req.user.sub]);
    clearRefreshCookie(reply);
    await audit({actorUserId:req.user.sub,action:'auth.logout'});
    return {ok:true};
  });

  app.get('/v1/me',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select u.id,u.email,u.created_at,p.handle,p.display_name,p.bio,p.avatar_url,p.banner_url
       from users u join profiles p on p.user_id=u.id where u.id=$1`,[req.user.sub]
    );
    if (!rows[0]) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    return rows[0];
  });
}
