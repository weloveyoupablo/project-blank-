import { db } from '../lib/db.js';

const postSelect=`
  select p.id,p.author_id,p.text,p.visibility,p.reply_to_id,p.quote_post_id,p.created_at,p.edited_at,
    pr.handle,pr.display_name,pr.avatar_url,
    exists(select 1 from post_reactions vr where vr.post_id=p.id and vr.user_id=$1 and vr.reaction='like') as viewer_liked,
    exists(select 1 from reposts vrp where vrp.post_id=p.id and vrp.user_id=$1) as viewer_reposted,
    (select count(*)::int from post_reactions r where r.post_id=p.id and r.reaction='like') likes,
    (select count(*)::int from reposts rp where rp.post_id=p.id) reposts,
    (select count(*)::int from posts rr where rr.reply_to_id=p.id and rr.deleted_at is null) replies,
    coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'mimeType',m.mime_type,'width',m.width,'height',m.height,'durationMs',m.duration_ms,'status',m.status) order by m.created_at)
      from media m where m.post_id=p.id and m.status='ready'),'[]'::jsonb) media
  from posts p join profiles pr on pr.user_id=p.author_id`;

export async function registerFeed(app) {
  app.get('/v1/feed',{preHandler:[app.authenticate]},async req=>{
    const limit=Math.min(Math.max(Number(req.query.limit||30),1),100);
    const before=req.query.before||null;
    const {rows}=await db.query(
      `${postSelect}
       where p.deleted_at is null
         and not exists(select 1 from blocks b where (b.blocker_id=$1 and b.blocked_id=p.author_id) or (b.blocker_id=p.author_id and b.blocked_id=$1))
         and (
           p.author_id=$1 or p.visibility='public' or
           (p.visibility='followers' and exists(select 1 from follows f where f.follower_id=$1 and f.followee_id=p.author_id)) or
           (p.visibility='close_friends' and exists(select 1 from close_friends cf where cf.user_id=p.author_id and cf.friend_user_id=$1))
         )
         and ($2::timestamptz is null or p.created_at<$2)
       order by p.created_at desc limit $3`,
      [req.user.sub,before,limit]
    );
    return {items:rows,nextCursor:rows.at(-1)?.created_at??null};
  });
}
