import { z } from 'zod';
import { db } from '../lib/db.js';
import { ApiError } from '../lib/errors.js';
import { audit } from '../lib/audit.js';
import { notify } from '../lib/notify.js';
import { publishToUsers } from '../lib/events.js';

const updateProfile=z.object({displayName:z.string().trim().min(1).max(80).optional(),bio:z.string().max(300).optional(),avatarUrl:z.string().url().nullable().optional(),bannerUrl:z.string().url().nullable().optional()});

export async function registerUsers(app) {
  app.get('/v1/users/:handle',{preHandler:[app.optionalAuth]},async req=>{
    const {rows}=await db.query(
      `select p.user_id id,p.handle,p.display_name,p.bio,p.avatar_url,p.banner_url,
       (select count(*)::int from follows where followee_id=p.user_id) followers,
       (select count(*)::int from follows where follower_id=p.user_id) following,
       case when $2::text is null then false else exists(select 1 from follows f where f.follower_id=$2 and f.followee_id=p.user_id) end viewer_following
       from profiles p where p.handle=$1`,[String(req.params.handle).toLowerCase(),req.user?.sub||null]
    );
    if (!rows[0]) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    return rows[0];
  });

  app.patch('/v1/me/profile',{preHandler:[app.authenticate]},async req=>{
    const b=updateProfile.parse(req.body);
    const {rows}=await db.query(
      `update profiles set display_name=coalesce($2,display_name),bio=coalesce($3,bio),
       avatar_url=case when $4::boolean then $5 else avatar_url end,banner_url=case when $6::boolean then $7 else banner_url end,updated_at=now()
       where user_id=$1 returning *`,
      [req.user.sub,b.displayName??null,b.bio??null,'avatarUrl' in b,b.avatarUrl??null,'bannerUrl' in b,b.bannerUrl??null]
    );
    await audit({actorUserId:req.user.sub,action:'profile.updated',objectType:'user',objectId:req.user.sub});
    await publishToUsers([req.user.sub],'profile.updated',{userId:req.user.sub});
    return rows[0];
  });

  app.post('/v1/users/:userId/follow',{preHandler:[app.authenticate]},async req=>{
    const target=String(req.params.userId);
    if(target===req.user.sub) throw new ApiError(400,'SELF_FOLLOW','You cannot follow yourself.');
    const exists=await db.query(`select 1 from users where id=$1 and status='active'`,[target]);
    if(!exists.rowCount) throw new ApiError(404,'USER_NOT_FOUND','User not found.');
    const inserted=await db.query(`insert into follows(follower_id,followee_id) values($1,$2) on conflict do nothing returning followee_id`,[req.user.sub,target]);
    if(inserted.rowCount) await notify({userId:target,actorUserId:req.user.sub,kind:'follow',objectType:'user',objectId:req.user.sub});
    await audit({actorUserId:req.user.sub,action:'follow.created',objectType:'user',objectId:target});
    return {following:true};
  });

  app.delete('/v1/users/:userId/follow',{preHandler:[app.authenticate]},async req=>{
    await db.query(`delete from follows where follower_id=$1 and followee_id=$2`,[req.user.sub,String(req.params.userId)]);
    return {following:false};
  });
}
