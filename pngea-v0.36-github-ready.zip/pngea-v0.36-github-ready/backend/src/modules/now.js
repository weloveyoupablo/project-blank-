import { z } from 'zod';
import { db } from '../lib/db.js';
import { publishGlobal, publishToUsers } from '../lib/events.js';
import { ApiError } from '../lib/errors.js';

const createNow=z.object({userId:z.string().nullable().optional(),kind:z.string().min(1).max(80),title:z.string().min(1).max(240),payload:z.record(z.any()).default({}),priority:z.number().int().min(-100).max(100).default(0),expiresAt:z.string().datetime()});

export async function registerNow(app){
  app.get('/v1/now',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(`select * from now_events where (user_id=$1 or user_id is null) and expires_at>now() order by priority desc,created_at desc limit 25`,[req.user.sub]);
    return {items:rows};
  });
  app.post('/v1/now',{preHandler:[app.authenticate]},async req=>{
    if(req.user.sub!==process.env.PNGEA_ADMIN_USER_ID) throw new ApiError(403,'FORBIDDEN','Admin access required.');
    const b=createNow.parse(req.body);
    const {rows}=await db.query(
      `insert into now_events(user_id,kind,title,payload,priority,expires_at) values($1,$2,$3,$4::jsonb,$5,$6) returning *`,
      [b.userId??null,b.kind,b.title,JSON.stringify(b.payload),b.priority,b.expiresAt]
    );
    const event=rows[0];
    if(event.user_id) await publishToUsers([event.user_id],'now.created',{event});
    else await publishGlobal('now.created',{event});
    return event;
  });
}
