import { z } from 'zod';
import { db } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { audit } from '../lib/audit.js';

const reportSchema=z.object({objectType:z.enum(['user','post','message','community','space']),objectId:z.string().min(1),reason:z.string().min(1).max(80),details:z.string().max(2000).nullable().optional()});

export async function registerModeration(app){
  app.post('/v1/reports',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=reportSchema.parse(req.body); const id=opaqueId('rpt');
    await db.query(`insert into reports(id,reporter_user_id,object_type,object_id,reason,details) values($1,$2,$3,$4,$5,$6)`,[id,req.user.sub,b.objectType,b.objectId,b.reason,b.details??null]);
    await audit({actorUserId:req.user.sub,action:'report.created',objectType:b.objectType,objectId:b.objectId,metadata:{reportId:id,reason:b.reason}});
    reply.code(201).send({id});
  });
}
