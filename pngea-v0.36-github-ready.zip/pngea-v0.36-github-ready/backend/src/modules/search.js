import { db } from '../lib/db.js';

export async function registerSearch(app){
  app.get('/v1/search',{preHandler:[app.optionalAuth]},async req=>{
    const q=String(req.query.q||'').trim();
    if(!q) return {query:q,people:[],posts:[]};
    const people=await db.query(
      `select user_id as id,handle,display_name,bio,avatar_url from profiles
       where search_document @@ websearch_to_tsquery('simple',$1) or handle ilike $2 order by ts_rank(search_document,websearch_to_tsquery('simple',$1)) desc limit 20`,[q,`%${q}%`]);
    const posts=await db.query(
      `select p.id,p.text,p.created_at,p.author_id,pr.handle,pr.display_name from posts p join profiles pr on pr.user_id=p.author_id
       where p.deleted_at is null and p.visibility='public' and p.search_document @@ websearch_to_tsquery('simple',$1)
       order by ts_rank(p.search_document,websearch_to_tsquery('simple',$1)) desc,p.created_at desc limit 40`,[q]);
    return {query:q,people:people.rows,posts:posts.rows};
  });
}
