import { z } from 'zod';
import { db } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { ApiError } from '../lib/errors.js';
import { publishToUsers } from '../lib/events.js';

const createTask=z.object({kind:z.string().min(1).max(80),title:z.string().min(1).max(240),payload:z.record(z.any()).default({}),requiresConfirmation:z.boolean().default(false)});

export async function registerTasks(app){
  app.get('/v1/tasks',{preHandler:[app.authenticate]},async req=>({items:(await db.query(`select * from tasks where user_id=$1 order by created_at desc limit 100`,[req.user.sub])).rows}));
  app.post('/v1/tasks',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=createTask.parse(req.body); const id=opaqueId('tsk');
    const status=b.requiresConfirmation?'waiting_for_user':'queued';
    const {rows}=await db.query(
      `insert into tasks(id,user_id,kind,title,payload,status,requires_confirmation) values($1,$2,$3,$4,$5::jsonb,$6,$7) returning *`,
      [id,req.user.sub,b.kind,b.title,JSON.stringify(b.payload),status,b.requiresConfirmation]
    );
    await publishToUsers([req.user.sub],'task.created',{task:rows[0]});
    reply.code(201).send(rows[0]);
  });
  app.post('/v1/tasks/:id/confirm',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `update tasks set status='queued',updated_at=now() where id=$1 and user_id=$2 and status='waiting_for_user' returning *`,
      [req.params.id,req.user.sub]
    );
    if(!rows[0]) throw new ApiError(404,'TASK_NOT_CONFIRMABLE','Task not found or does not require confirmation.');
    await publishToUsers([req.user.sub],'task.updated',{task:rows[0]});
    return rows[0];
  });
  app.post('/v1/tasks/:id/cancel',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `update tasks set status='cancelled',updated_at=now() where id=$1 and user_id=$2 and status not in('completed','failed','cancelled') returning *`,
      [req.params.id,req.user.sub]
    );
    if(!rows[0]) throw new ApiError(404,'TASK_NOT_CANCELLABLE','Task not found or already finished.');
    await publishToUsers([req.user.sub],'task.updated',{task:rows[0]});
    return rows[0];
  });
}
