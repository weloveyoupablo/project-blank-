import { z } from 'zod';
import { db } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { ApiError } from '../lib/errors.js';

const rememberSchema=z.object({sourceObjectType:z.string().min(1).max(50),sourceObjectId:z.string().min(1),summary:z.string().max(1000).nullable().optional()});

export async function registerMemory(app){
  app.get('/v1/memory',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(`select * from memories where user_id=$1 and forgotten_at is null order by created_at desc`,[req.user.sub]);
    return {items:rows};
  });
  app.post('/v1/memory',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=rememberSchema.parse(req.body); const id=opaqueId('mem');
    await db.query(`insert into memories(id,user_id,source_object_type,source_object_id,summary,reason_saved) values($1,$2,$3,$4,$5,'explicit')`,[id,req.user.sub,b.sourceObjectType,b.sourceObjectId,b.summary??null]);
    reply.code(201).send({id});
  });
  app.delete('/v1/memory/:id',{preHandler:[app.authenticate]},async req=>{
    const {rowCount}=await db.query(`update memories set forgotten_at=now(),embedding=null,summary=null where id=$1 and user_id=$2 and forgotten_at is null`,[req.params.id,req.user.sub]);
    if(!rowCount) throw new ApiError(404,'MEMORY_NOT_FOUND','Memory not found.');
    return {ok:true};
  });
}
