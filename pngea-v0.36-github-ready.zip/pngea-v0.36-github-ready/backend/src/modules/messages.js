import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { ApiError } from '../lib/errors.js';
import { publishToUsers } from '../lib/events.js';

const createConversation=z.object({memberIds:z.array(z.string()).min(1).max(99),title:z.string().max(120).nullable().optional()});
const sendMessage=z.object({text:z.string().max(10000).default(''),mediaIds:z.array(z.string()).max(10).default([])}).refine(v=>v.text.trim()||v.mediaIds.length,'Message cannot be empty.');

async function assertMember(userId,conversationId) {
  const {rowCount}=await db.query(`select 1 from conversation_members where conversation_id=$1 and user_id=$2 and left_at is null`,[conversationId,userId]);
  if (!rowCount) throw new ApiError(403,'NOT_A_MEMBER','You are not a member of this conversation.');
}
async function members(conversationId){return (await db.query(`select user_id from conversation_members where conversation_id=$1 and left_at is null`,[conversationId])).rows.map(r=>r.user_id)}

export async function registerMessages(app) {
  app.get('/v1/conversations',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select c.id,c.title,c.updated_at,
       (select text from messages m where m.conversation_id=c.id and m.deleted_at is null order by m.created_at desc limit 1) last_message,
       (select created_at from messages m where m.conversation_id=c.id and m.deleted_at is null order by m.created_at desc limit 1) last_message_at,
       (select count(*)::int from messages m where m.conversation_id=c.id and m.sender_id<>$1 and m.created_at>coalesce(cm.last_read_at,'epoch')) unread,
       coalesce((select jsonb_agg(jsonb_build_object('id',p.user_id,'handle',p.handle,'displayName',p.display_name,'avatarUrl',p.avatar_url) order by p.display_name)
         from conversation_members cm2 join profiles p on p.user_id=cm2.user_id
         where cm2.conversation_id=c.id and cm2.left_at is null and cm2.user_id<>$1),'[]'::jsonb) members
       from conversations c join conversation_members cm on cm.conversation_id=c.id
       where cm.user_id=$1 and cm.left_at is null order by c.updated_at desc`,[req.user.sub]
    );
    return {items:rows};
  });

  app.post('/v1/conversations',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=createConversation.parse(req.body); const id=opaqueId('cnv');
    const memberIds=[...new Set([req.user.sub,...b.memberIds])];
    const valid=await db.query(`select id from users where id=any($1::text[]) and status='active'`,[memberIds]);
    if (valid.rowCount!==memberIds.length) throw new ApiError(400,'INVALID_MEMBERS','One or more conversation members are unavailable.');
    await tx(async c=>{
      await c.query(`insert into conversations(id,title,created_by) values($1,$2,$3)`,[id,b.title??null,req.user.sub]);
      for(const uid of memberIds) await c.query(`insert into conversation_members(conversation_id,user_id,last_read_at) values($1,$2,case when $2=$3 then now() else null end)`,[id,uid,req.user.sub]);
    });
    await publishToUsers(memberIds,'conversation.created',{conversationId:id});
    reply.code(201).send({id});
  });

  app.get('/v1/conversations/:id/messages',{preHandler:[app.authenticate]},async req=>{
    await assertMember(req.user.sub,req.params.id);
    const {rows}=await db.query(
      `select m.*,
       coalesce((select jsonb_agg(jsonb_build_object('id',med.id,'mimeType',med.mime_type,'status',med.status) order by mm.position)
         from message_media mm join media med on med.id=mm.media_id where mm.message_id=m.id),'[]'::jsonb) media
       from messages m where m.conversation_id=$1 and m.deleted_at is null order by m.created_at asc limit 500`,[req.params.id]
    );
    return {items:rows};
  });

  app.post('/v1/conversations/:id/messages',{preHandler:[app.authenticate]},async (req,reply)=>{
    await assertMember(req.user.sub,req.params.id); const b=sendMessage.parse(req.body); const id=opaqueId('msg');
    await tx(async c=>{
      await c.query(`insert into messages(id,conversation_id,sender_id,text) values($1,$2,$3,$4)`,[id,req.params.id,req.user.sub,b.text]);
      if (b.mediaIds.length) {
        const q=await c.query(`select id from media where owner_user_id=$1 and id=any($2::text[]) and status='ready'`,[req.user.sub,b.mediaIds]);
        if(q.rowCount!==b.mediaIds.length) throw new ApiError(409,'MEDIA_NOT_READY','One or more attachments are unavailable.');
        for(let i=0;i<b.mediaIds.length;i++) await c.query(`insert into message_media(message_id,media_id,position) values($1,$2,$3)`,[id,b.mediaIds[i],i]);
      }
      await c.query(`update conversations set updated_at=now() where id=$1`,[req.params.id]);
      await c.query(`update conversation_members set last_read_at=now() where conversation_id=$1 and user_id=$2`,[req.params.id,req.user.sub]);
    });
    const recipients=await members(req.params.id);
    await publishToUsers(recipients,'message.created',{conversationId:req.params.id,messageId:id,senderId:req.user.sub});
    reply.code(201).send({id});
  });

  app.post('/v1/conversations/:id/read',{preHandler:[app.authenticate]},async req=>{
    await assertMember(req.user.sub,req.params.id);
    await db.query(`update conversation_members set last_read_at=now() where conversation_id=$1 and user_id=$2`,[req.params.id,req.user.sub]);
    await publishToUsers(await members(req.params.id),'conversation.read',{conversationId:req.params.id,userId:req.user.sub,at:new Date().toISOString()});
    return {ok:true};
  });
}
