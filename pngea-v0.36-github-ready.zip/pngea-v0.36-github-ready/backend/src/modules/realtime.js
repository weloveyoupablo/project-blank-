import { opaqueId } from '../lib/security.js';
import { redis, ensureRedis } from '../lib/redis.js';
import { registerRealtimeSocket, realtimeStats } from '../lib/events.js';
import { ApiError } from '../lib/errors.js';

const localTickets = new Map();

async function issueTicket(userId) {
  const ticket=opaqueId('rt');
  try {
    await ensureRedis();
    await redis.set(`realtime:ticket:${ticket}`,userId,'EX',60,'NX');
  } catch {
    localTickets.set(ticket,{userId,expiresAt:Date.now()+60_000});
  }
  return ticket;
}

async function consumeTicket(ticket) {
  if (!ticket) return null;
  try {
    await ensureRedis();
    const key=`realtime:ticket:${ticket}`;
    let value;
    try { value = await redis.call('GETDEL',key); }
    catch {
      value=await redis.get(key);
      if (value) await redis.del(key);
    }
    if (value) return value;
  } catch {}
  const local=localTickets.get(ticket);
  localTickets.delete(ticket);
  if (!local || local.expiresAt<Date.now()) return null;
  return local.userId;
}

export async function registerRealtime(app) {
  app.post('/v1/realtime/ticket',{preHandler:[app.authenticate]},async req=>({
    ticket:await issueTicket(req.user.sub),expiresIn:60
  }));

  app.get('/v1/realtime/stats',{preHandler:[app.authenticate]},async req=>{
    if (req.user.sub !== process.env.PNGEA_ADMIN_USER_ID) throw new ApiError(403,'FORBIDDEN','Admin access required.');
    return realtimeStats();
  });

  app.get('/v1/realtime',{websocket:true},async (socket,req)=>{
    const ticket=String(req.query?.ticket||'');
    const userId=await consumeTicket(ticket);
    if (!userId) {
      socket.close(4401,'Invalid realtime ticket');
      return;
    }
    registerRealtimeSocket(userId,socket);
    socket.send(JSON.stringify({ type:'realtime.ready', data:{ userId }, at:new Date().toISOString() }));
    socket.isAlive=true;
    socket.on('pong',()=>{socket.isAlive=true});
  });

  const heartbeat=setInterval(()=>{
    for (const client of app.websocketServer.clients) {
      if (client.isAlive === false) { client.terminate(); continue; }
      client.isAlive=false;
      try { client.ping(); } catch {}
    }
  },25_000);
  app.addHook('onClose',async()=>clearInterval(heartbeat));
}
