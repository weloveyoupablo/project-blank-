import { z } from 'zod';
import { db, tx } from '../lib/db.js';
import { opaqueId } from '../lib/security.js';
import { ApiError } from '../lib/errors.js';
import { audit } from '../lib/audit.js';
import { notify } from '../lib/notify.js';
import { publishGlobal, publishToUsers } from '../lib/events.js';

const createPost=z.object({
  text:z.string().max(20000).default(''),
  visibility:z.enum(['public','followers','close_friends','private']).default('public'),
  replyToId:z.string().nullable().optional(),
  quotePostId:z.string().nullable().optional(),
  mediaIds:z.array(z.string()).max(10).default([])
}).refine(v=>v.text.trim()||v.mediaIds.length,'Post cannot be empty.');

async function postAudience(authorId,visibility) {
  if (visibility==='public') return null;
  if (visibility==='private') return [authorId];
  const table=visibility==='close_friends'
    ? `select friend_user_id as id from close_friends where user_id=$1`
    : `select follower_id as id from follows where followee_id=$1`;
  const {rows}=await db.query(table,[authorId]);
  return [authorId,...rows.map(r=>r.id)];
}

async function fetchVisiblePost(id,viewerId) {
  const {rows}=await db.query(
    `select p.*,pr.handle,pr.display_name,pr.avatar_url,
      exists(select 1 from post_reactions r where r.post_id=p.id and r.user_id=$2 and r.reaction='like') viewer_liked,
      exists(select 1 from reposts rp where rp.post_id=p.id and rp.user_id=$2) viewer_reposted,
      (select count(*)::int from post_reactions r where r.post_id=p.id and r.reaction='like') likes,
      (select count(*)::int from reposts rp where rp.post_id=p.id) reposts,
      (select count(*)::int from posts rr where rr.reply_to_id=p.id and rr.deleted_at is null) replies,
      coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'mimeType',m.mime_type,'width',m.width,'height',m.height,'durationMs',m.duration_ms,'status',m.status) order by m.created_at)
        from media m where m.post_id=p.id and m.status='ready'),'[]'::jsonb) media
     from posts p join profiles pr on pr.user_id=p.author_id
     where p.id=$1 and p.deleted_at is null
       and not exists(select 1 from blocks b where $2 is not null and ((b.blocker_id=$2 and b.blocked_id=p.author_id) or (b.blocker_id=p.author_id and b.blocked_id=$2)))
       and (
         p.visibility='public' or p.author_id=$2 or
         (p.visibility='followers' and exists(select 1 from follows f where f.follower_id=$2 and f.followee_id=p.author_id)) or
         (p.visibility='close_friends' and exists(select 1 from close_friends cf where cf.user_id=p.author_id and cf.friend_user_id=$2))
       )`,[id,viewerId||null]
  );
  return rows[0]||null;
}

export async function registerPosts(app) {
  app.get('/v1/me/posts',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select p.id,p.author_id,p.text,p.visibility,p.reply_to_id,p.quote_post_id,p.created_at,p.edited_at,pr.handle,pr.display_name,pr.avatar_url,
       exists(select 1 from post_reactions r where r.post_id=p.id and r.user_id=$1 and r.reaction='like') viewer_liked,
       exists(select 1 from reposts rp where rp.post_id=p.id and rp.user_id=$1) viewer_reposted,
       (select count(*)::int from post_reactions r where r.post_id=p.id and r.reaction='like') likes,
       (select count(*)::int from reposts rp where rp.post_id=p.id) reposts,
       (select count(*)::int from posts rr where rr.reply_to_id=p.id and rr.deleted_at is null) replies,
       coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'mimeType',m.mime_type,'width',m.width,'height',m.height,'durationMs',m.duration_ms,'status',m.status) order by m.created_at) from media m where m.post_id=p.id and m.status='ready'),'[]'::jsonb) media
       from posts p join profiles pr on pr.user_id=p.author_id where p.author_id=$1 and p.deleted_at is null order by p.created_at desc limit 200`,[req.user.sub]
    );
    return {items:rows};
  });

  app.post('/v1/posts',{preHandler:[app.authenticate]},async (req,reply)=>{
    const b=createPost.parse(req.body); const id=opaqueId('pst');
    let parentAuthor=null;
    await tx(async c=>{
      if (b.replyToId) {
        const r=await c.query(`select author_id from posts where id=$1 and deleted_at is null`,[b.replyToId]);
        if (!r.rows[0]) throw new ApiError(404,'REPLY_TARGET_NOT_FOUND','Reply target not found.');
        parentAuthor=r.rows[0].author_id;
      }
      if (b.quotePostId) {
        const r=await c.query(`select 1 from posts where id=$1 and deleted_at is null`,[b.quotePostId]);
        if (!r.rows[0]) throw new ApiError(404,'QUOTE_TARGET_NOT_FOUND','Quoted post not found.');
      }
      await c.query(`insert into posts(id,author_id,text,visibility,reply_to_id,quote_post_id) values($1,$2,$3,$4,$5,$6)`,[id,req.user.sub,b.text,b.visibility,b.replyToId??null,b.quotePostId??null]);
      if (b.mediaIds.length) {
        const attached=await c.query(
          `update media set post_id=$1,updated_at=now() where owner_user_id=$2 and id=any($3::text[]) and status='ready' and post_id is null returning id`,
          [id,req.user.sub,b.mediaIds]
        );
        if (attached.rowCount!==b.mediaIds.length) throw new ApiError(409,'MEDIA_NOT_READY','One or more media objects are unavailable or still processing.');
      }
    });
    await audit({actorUserId:req.user.sub,action:'post.created',objectType:'post',objectId:id});
    if (parentAuthor) await notify({userId:parentAuthor,actorUserId:req.user.sub,kind:'reply',objectType:'post',objectId:id,payload:{parentPostId:b.replyToId}});
    const audience=await postAudience(req.user.sub,b.visibility);
    if (audience) await publishToUsers(audience,'post.created',{postId:id,authorId:req.user.sub});
    else await publishGlobal('post.created',{postId:id,authorId:req.user.sub});
    reply.code(201).send({id});
  });

  app.get('/v1/posts/:id',{preHandler:[app.optionalAuth]},async req=>{
    const post=await fetchVisiblePost(req.params.id,req.user?.sub||null);
    if (!post) throw new ApiError(404,'POST_NOT_FOUND','Post not found.');
    return post;
  });

  app.delete('/v1/posts/:id',{preHandler:[app.authenticate]},async req=>{
    const {rowCount}=await db.query(`update posts set deleted_at=now() where id=$1 and author_id=$2 and deleted_at is null`,[req.params.id,req.user.sub]);
    if (!rowCount) throw new ApiError(404,'POST_NOT_FOUND','Post not found.');
    await audit({actorUserId:req.user.sub,action:'post.deleted',objectType:'post',objectId:req.params.id});
    await publishGlobal('post.deleted',{postId:req.params.id,authorId:req.user.sub});
    return {ok:true};
  });

  app.put('/v1/posts/:id/like',{preHandler:[app.authenticate]},async req=>{
    const target=await db.query(`select author_id from posts where id=$1 and deleted_at is null`,[req.params.id]);
    if (!target.rows[0]) throw new ApiError(404,'POST_NOT_FOUND','Post not found.');
    const inserted=await db.query(`insert into post_reactions(user_id,post_id,reaction) values($1,$2,'like') on conflict do nothing returning post_id`,[req.user.sub,req.params.id]);
    if (inserted.rowCount) await notify({userId:target.rows[0].author_id,actorUserId:req.user.sub,kind:'like',objectType:'post',objectId:req.params.id});
    await publishToUsers([target.rows[0].author_id,req.user.sub],'post.reaction.changed',{postId:req.params.id,kind:'like',active:true,userId:req.user.sub});
    return {liked:true};
  });

  app.delete('/v1/posts/:id/like',{preHandler:[app.authenticate]},async req=>{
    await db.query(`delete from post_reactions where user_id=$1 and post_id=$2 and reaction='like'`,[req.user.sub,req.params.id]);
    await publishToUsers([req.user.sub],'post.reaction.changed',{postId:req.params.id,kind:'like',active:false,userId:req.user.sub});
    return {liked:false};
  });

  app.put('/v1/posts/:id/repost',{preHandler:[app.authenticate]},async req=>{
    const target=await db.query(`select author_id from posts where id=$1 and deleted_at is null`,[req.params.id]);
    if (!target.rows[0]) throw new ApiError(404,'POST_NOT_FOUND','Post not found.');
    const inserted=await db.query(`insert into reposts(user_id,post_id) values($1,$2) on conflict do nothing returning post_id`,[req.user.sub,req.params.id]);
    if (inserted.rowCount) await notify({userId:target.rows[0].author_id,actorUserId:req.user.sub,kind:'repost',objectType:'post',objectId:req.params.id});
    await publishToUsers([target.rows[0].author_id,req.user.sub],'post.reaction.changed',{postId:req.params.id,kind:'repost',active:true,userId:req.user.sub});
    return {reposted:true};
  });

  app.delete('/v1/posts/:id/repost',{preHandler:[app.authenticate]},async req=>{
    await db.query(`delete from reposts where user_id=$1 and post_id=$2`,[req.user.sub,req.params.id]);
    await publishToUsers([req.user.sub],'post.reaction.changed',{postId:req.params.id,kind:'repost',active:false,userId:req.user.sub});
    return {reposted:false};
  });
}
