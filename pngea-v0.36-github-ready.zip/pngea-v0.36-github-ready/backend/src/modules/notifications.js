import { db } from '../lib/db.js';

export async function registerNotifications(app){
  app.get('/v1/notifications',{preHandler:[app.authenticate]},async req=>{
    const {rows}=await db.query(
      `select n.*,p.handle actor_handle,p.display_name actor_display_name,p.avatar_url actor_avatar_url
       from notifications n left join profiles p on p.user_id=n.actor_user_id
       where n.user_id=$1 order by n.created_at desc limit 100`,[req.user.sub]
    );
    return {items:rows};
  });
  app.post('/v1/notifications/read-all',{preHandler:[app.authenticate]},async req=>{
    await db.query(`update notifications set read_at=coalesce(read_at,now()) where user_id=$1`,[req.user.sub]);
    return {ok:true};
  });
  app.post('/v1/notifications/:id/read',{preHandler:[app.authenticate]},async req=>{
    await db.query(`update notifications set read_at=coalesce(read_at,now()) where id=$1 and user_id=$2`,[req.params.id,req.user.sub]);
    return {ok:true};
  });
}
