import { db, tx } from './lib/db.js';
import { headMediaObject } from './lib/object-storage.js';
import { opaqueId } from './lib/security.js';
import { publishToUsers } from './lib/events.js';
import { startEventBus } from './lib/events.js';

const sleep=ms=>new Promise(r=>setTimeout(r,ms));

async function claimJob() {
  return tx(async c=>{
    const {rows}=await c.query(
      `select j.id,j.media_id,j.kind,m.owner_user_id,m.object_key,m.mime_type,m.byte_size
       from media_jobs j join media m on m.id=j.media_id
       where j.status='queued' and j.available_at<=now()
       order by j.id
       for update skip locked limit 1`
    );
    const job=rows[0];
    if (!job) return null;
    await c.query(`update media_jobs set status='running',attempts=attempts+1,started_at=now() where id=$1`,[job.id]);
    return job;
  });
}

async function processJob(job) {
  try {
    if (job.kind!=='inspect') throw new Error(`unsupported job kind ${job.kind}`);
    const head=await headMediaObject(job.object_key);
    if (Number(head.ContentLength||0)!==Number(job.byte_size)) throw new Error('object size changed after upload');
    await tx(async c=>{
      await c.query(
        `insert into media_variants(id,media_id,kind,object_key,mime_type,byte_size)
         values($1,$2,'original',$3,$4,$5)
         on conflict(media_id,kind) do update set object_key=excluded.object_key,mime_type=excluded.mime_type,byte_size=excluded.byte_size`,
        [opaqueId('var'),job.media_id,job.object_key,job.mime_type,job.byte_size]
      );
      await c.query(`update media set status='ready',updated_at=now() where id=$1`,[job.media_id]);
      await c.query(`update media_jobs set status='completed',completed_at=now() where id=$1`,[job.id]);
    });
    await publishToUsers([job.owner_user_id],'media.ready',{mediaId:job.media_id});
  } catch (error) {
    const retry=(await db.query(`select attempts from media_jobs where id=$1`,[job.id])).rows[0]?.attempts<5;
    await db.query(
      `update media_jobs set status=$2,last_error=$3,available_at=case when $2='queued' then now()+interval '15 seconds' else available_at end,
       completed_at=case when $2='failed' then now() else completed_at end where id=$1`,
      [job.id,retry?'queued':'failed',String(error.message||error).slice(0,1000)]
    );
    if (!retry) {
      await db.query(`update media set status='failed',updated_at=now() where id=$1`,[job.media_id]);
      await publishToUsers([job.owner_user_id],'media.failed',{mediaId:job.media_id});
    }
  }
}

await startEventBus(console);
console.log('PNGEA media worker online');
for (;;) {
  const job=await claimJob();
  if (!job) { await sleep(750); continue; }
  await processJob(job);
}
